
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = [-865879.4747004735];
FuzzerInjectionPoint(2);
v2.pop();
FuzzerInjectionPoint(3);
v2[1] = 6.483025321840426;
FuzzerInjectionPoint(4);
v2.unshift(4294967296);
FuzzerInjectionPoint(5);