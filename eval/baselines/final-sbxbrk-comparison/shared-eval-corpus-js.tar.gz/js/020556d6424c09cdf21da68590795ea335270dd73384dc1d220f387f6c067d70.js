
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    for (let v2 = 0; v2 < 5; v2++) {
FuzzerInjectionPoint(3);
        let v3 = v2 >>> 255;
FuzzerInjectionPoint(4);
        v3--;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    return f1;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f1();
FuzzerInjectionPoint(9);
const v6 = f1();
FuzzerInjectionPoint(10);
%OptimizeMaglevOnNextCall(v6);
FuzzerInjectionPoint(11);
v6();
FuzzerInjectionPoint(12);