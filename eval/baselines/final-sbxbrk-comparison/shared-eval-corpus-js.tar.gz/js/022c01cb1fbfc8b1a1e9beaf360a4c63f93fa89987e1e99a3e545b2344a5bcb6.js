
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    Symbol.matchAll == Symbol.for(a3);
FuzzerInjectionPoint(3);
    return f0;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v8 = f0(f0, f0, f0);
FuzzerInjectionPoint(6);
const v9 = f0();
FuzzerInjectionPoint(7);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(8);
f0(v8, v9, f0);
FuzzerInjectionPoint(9);