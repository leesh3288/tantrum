
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    class C5 {

    }
FuzzerInjectionPoint(4);
    class C6 extends a4 {

    }
FuzzerInjectionPoint(6);
    C6.of(C5, Float32Array, C5, Float32Array);
FuzzerInjectionPoint(7);
    function f8(a9, a10, a11) {
FuzzerInjectionPoint(8);
        try { a9.caller(Float32Array, a9, a10); } catch (e) {}
FuzzerInjectionPoint(9);
        return a3;
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    f8(f8, C5);
FuzzerInjectionPoint(12);
    return f8();
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
const v15 = f1(Float32Array, Float32Array, Float32Array);
FuzzerInjectionPoint(15);
f1(v15, v15, v15);
FuzzerInjectionPoint(16);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(17);
f1(Float32Array, Float32Array, v15);