
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v5 = new SharedArrayBuffer(21, { maxByteLength: 21 });
FuzzerInjectionPoint(2);
const v7 = new Float32Array(v5);
FuzzerInjectionPoint(3);
v7.constructor = Uint32Array;
FuzzerInjectionPoint(4);
v7.slice();
FuzzerInjectionPoint(5);