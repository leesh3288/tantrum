
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = /abc?/musg;
FuzzerInjectionPoint(2);
const v1 = /W/dsgi;
FuzzerInjectionPoint(3);
const v2 = /ab\b\d\bcd/mvsgi;
FuzzerInjectionPoint(4);
function f3(a4, a5) {
FuzzerInjectionPoint(5);
    a4.flags;
FuzzerInjectionPoint(6);
    a4.dotAll = a4;
FuzzerInjectionPoint(7);
    const v10 = {

        105: a4,

        ...v1,

        __proto__: v1,

        p(a8) {
FuzzerInjectionPoint(12);
            super.d ||= a8;
FuzzerInjectionPoint(13);
            return a4;
FuzzerInjectionPoint(14);
        },

    };
FuzzerInjectionPoint(16);
    v10[105] = v10;
FuzzerInjectionPoint(17);
    function F11(a13, a14, a15) {
FuzzerInjectionPoint(18);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(19);
        a14.dotAll;
FuzzerInjectionPoint(20);
        this.f = a13;
FuzzerInjectionPoint(21);
    }
FuzzerInjectionPoint(22);
    new F11(v1, v1);
FuzzerInjectionPoint(23);
    const v18 = new F11(v0, a5, v0);
FuzzerInjectionPoint(24);
    v18.f;
FuzzerInjectionPoint(25);
}
FuzzerInjectionPoint(26);
f3(v1, v1);
FuzzerInjectionPoint(27);
const v21 = v0.__proto__;
FuzzerInjectionPoint(28);
v21.c = v21;
FuzzerInjectionPoint(29);
f3(v21, f3);
FuzzerInjectionPoint(30);
const v23 = f3(v21, f3);
FuzzerInjectionPoint(31);
try { v23.p(); } catch (e) {}
FuzzerInjectionPoint(32);
%OptimizeMaglevOnNextCall(f3);
FuzzerInjectionPoint(33);
f3(v2, v0);
FuzzerInjectionPoint(34);
let v26 = "string";
FuzzerInjectionPoint(35);
v26--;
FuzzerInjectionPoint(36);
try { v2.slice(); } catch (e) {}
FuzzerInjectionPoint(37);
1 !== 1;