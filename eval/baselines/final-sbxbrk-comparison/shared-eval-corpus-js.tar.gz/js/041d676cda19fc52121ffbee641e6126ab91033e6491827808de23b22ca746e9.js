
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v3 = ({}).constructor;
FuzzerInjectionPoint(3);
    v3.seal(this);
FuzzerInjectionPoint(4);
    return v3;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
f0();
FuzzerInjectionPoint(7);
f0();
FuzzerInjectionPoint(8);