
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Date();
FuzzerInjectionPoint(2);
const v2 = { __proto__: v1 };
FuzzerInjectionPoint(3);
try { v2.toJSON(); } catch (e) {}
FuzzerInjectionPoint(4);