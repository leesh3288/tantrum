
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[-28994n];

const v4 = [-1n,37159n];

[v4,v4];

const v6 = [1000000000.0,-496.28683539288176];

[115.58979678758874,365479.4521195844,-6.780173695172127,1e-15,-2.2250738585072014e-308,-5.0,9.679360682165707e+307,-7.071799116630139e+307,108.08405914304262,-Infinity];

[v6,[1000000000.0,1.5414656894816112e+308,871.2708558965132,5.8448405311547305,1.1076302637531453e+308,-136150.89045135526,1000000000.0,-1000000000.0],-28994n];

[];

const v11 = [];

class C12 {

    #e = v11;

    get b() {

        class C14 {

            constructor(a16) {

                function f17() {

                    ("HJm").startsWith();

                    return f17;

                }

                const t17 = f17();

                t17();

                %OptimizeFunctionOnNextCall(f17);

                f17();

            }

        }

        new C14();

        new BigInt64Array();

        const v28 = {};

        ([-4.128891060620081e+307,0.0,0.3070916009376544,5.0,-3.2651724036569434e+307,1000000000000.0,-1000000000000.0]).__proto__;

        class C31 {

        }

        new Int16Array(3670);

        new BigInt64Array(9);

        return -1n;

    }

    h;

    static 10;

}

new C12();

new C12();

new C12();

new Map();

new Set();

new Uint8Array(127);

new Uint8Array(129);

const v55 = new Int8Array(4);

class C58 {

    constructor(a60) {

        function f61() {

            function f63(a64) {

                a64.pow(a64, -1474665012);

            }

            this.onmessage = f63;

            const v66 = %WasmArray();

        }

        function f68(a69) {

            return this.console.trace(a69, a69, f68, a69);

        }

        %VerifyType(a60);

        a60?.["getInt16"];

        const v74 = %WasmArray();

        v55[5] = a60;

        let v76 = -1;

        Math.cosh(4);

        const v79 = ++v76;

        const v80 = ++v76;

        function f82() {

            return Uint8ClampedArray;

        }

        try { f82.bind(Uint8ClampedArray); } catch (e) {}

        [f82];

        4 << v79;

        Math.sin(v80);

        new Worker(f61, { type: "function" });

    }

}

new C58();

new C58("atan2");

new Int8Array();

([-209.58378861523784,3.9229025617971978,1.7853477203613435e+308,-1000000000000.0,-Infinity,-528.872283168871]).toLocaleString();

const v98 = [2,5,-13,1,13,-4294967295,268435440,4294967297];

const v100 = new Uint32Array();

for (let v102 = 0; v102 < 10; v102++) {

    v102 < 5;

    v98.__proto__ = v100.__proto__;

    v102++;

}

function f107() {

    [536870912,4];

    return Symbol;

    /a(?!bbb|bb)c*/vgiy;

    const t88 = 257;

    t88(129, 1409203643);

    class C115 {

    }

    return f107;

}