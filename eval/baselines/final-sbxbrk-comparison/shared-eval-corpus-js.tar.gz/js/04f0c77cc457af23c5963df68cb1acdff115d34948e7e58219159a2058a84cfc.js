
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v5 = new SharedArrayBuffer(0, { maxByteLength: 1446 });
FuzzerInjectionPoint(2);
const v6 = new Float64Array(v5);
FuzzerInjectionPoint(3);
Object.values(v6);
FuzzerInjectionPoint(4);