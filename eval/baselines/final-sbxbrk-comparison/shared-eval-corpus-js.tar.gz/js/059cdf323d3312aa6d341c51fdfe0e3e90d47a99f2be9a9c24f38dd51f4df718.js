
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    for (let v4 = 0; v4 < 5; v4++) {

        const v6 = {};

        for (let i9 = 0, i10 = 10;

            (() => {

                class C11 {

                }

                return i9;

            })();

            (() => {

                const v14 = i10 >>> v4;

                v14 & v14;

            })()) {

        }

        const v19 = typeof v6.e;

        try { v19(); } catch (e) {}

        v19 === "number";

        Math.ceil(v4);

        try {

            using v25 = {};

        } catch(e26) {

        }

    }

}

const v30 = new Worker(f0, { type: "function" });

v30.getMessage();