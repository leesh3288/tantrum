
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    function f4(a5, a6) {

        return a5;

    }

    async function f8(a9, a10, a11) {

        function f12(a13, a14) {

            return a9;

        }

        a9.then = f12;

        return a11;

    }

    const v15 = f8();

    v15.then(undefined, f4);

    f8(v15);

    return undefined;

}

const v21 = new Worker(f0, { type: "function" });

v21.getMessage(f0, v21);