
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-7.079658797381108e+307,-411072.92969109665,1.6880648296298849e+308,6.305711554081372e+307,2.8249759734703694,Infinity,-2.0,1e-15,5.0,4.0];
FuzzerInjectionPoint(2);
v1[53] = 144;
FuzzerInjectionPoint(3);
for (let v2 = 0; v2 < 5; v2++) {
FuzzerInjectionPoint(4);
    delete v1[v2];
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);