
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    function f4(a5, a6, a7) {
FuzzerInjectionPoint(3);
        function f8() {
FuzzerInjectionPoint(4);
            for (let v9 = 0; v9 < 5; v9++) {
FuzzerInjectionPoint(5);
                new Int16Array();
FuzzerInjectionPoint(6);
                Int16Array <<= Int16Array;
FuzzerInjectionPoint(7);
                function F12(a14, a15) {
FuzzerInjectionPoint(8);
                    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(9);
                }
FuzzerInjectionPoint(10);
                new F12();
FuzzerInjectionPoint(11);
            }
FuzzerInjectionPoint(12);
            return a3;
FuzzerInjectionPoint(13);
        }
FuzzerInjectionPoint(14);
        Object.defineProperty(f8, "toString", { writable: true, enumerable: true, value: f8 });
FuzzerInjectionPoint(15);
        f8.toString();
FuzzerInjectionPoint(16);
        return f0;
FuzzerInjectionPoint(17);
    }
FuzzerInjectionPoint(18);
    try { f4(); } catch (e) {}
FuzzerInjectionPoint(19);
    return f4;
FuzzerInjectionPoint(20);
}
FuzzerInjectionPoint(21);
const v19 = f0(f0, f0, f0);
FuzzerInjectionPoint(22);
f0(v19, v19, v19);
FuzzerInjectionPoint(23);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(24);
f0();
FuzzerInjectionPoint(25);