
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Uint8Array(3397);
FuzzerInjectionPoint(2);
1571 | 1571;
FuzzerInjectionPoint(3);
const v6 = new Float64Array(1571);
FuzzerInjectionPoint(4);
new Uint16Array(8);
FuzzerInjectionPoint(5);
[-63829];
FuzzerInjectionPoint(6);
[1073741825,2147483647,8,-1355701431,5];
FuzzerInjectionPoint(7);
const v12 = [268435440,-5488,-2147483649,536870889,-1246036791,-11,-350,20024,1000];
FuzzerInjectionPoint(8);
v12[5] = v12;
FuzzerInjectionPoint(9);
/gpy7QS?/udgiy;
FuzzerInjectionPoint(10);
!true;
FuzzerInjectionPoint(11);
function F16(a18, a19) {
FuzzerInjectionPoint(12);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(13);
    this.a = a19;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
try { new F16(v6, v6); } catch (e) {}
FuzzerInjectionPoint(16);
[5.0,1.086302118340775e+308,-4.0,1000000000.0,NaN,-8.028061503276937e+307];
FuzzerInjectionPoint(17);
const v27 = new Int8Array(1293);
FuzzerInjectionPoint(18);
5 >>> 5;
FuzzerInjectionPoint(19);
for (let i = 0; i < 100; i++) {
FuzzerInjectionPoint(20);
    const t19 = 3;
FuzzerInjectionPoint(21);
    t19.valueOf = 10;
FuzzerInjectionPoint(22);
    try { ("undefined").fontsize(v27); } catch (e) {}
FuzzerInjectionPoint(23);
    v27.join();
FuzzerInjectionPoint(24);
}
FuzzerInjectionPoint(25);