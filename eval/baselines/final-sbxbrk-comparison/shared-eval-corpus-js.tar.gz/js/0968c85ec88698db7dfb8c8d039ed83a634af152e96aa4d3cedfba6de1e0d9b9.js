
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    function f3() {
FuzzerInjectionPoint(3);
        return f3;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    function f4(a5) {
FuzzerInjectionPoint(6);
        a5 >>> a5;
FuzzerInjectionPoint(7);
        return a5;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    ([-4.0,f3]).some(f4);
FuzzerInjectionPoint(10);
    return a2;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
f1();
FuzzerInjectionPoint(13);
f1(-4.0);
FuzzerInjectionPoint(14);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(15);
f1(-4.0);
FuzzerInjectionPoint(16);