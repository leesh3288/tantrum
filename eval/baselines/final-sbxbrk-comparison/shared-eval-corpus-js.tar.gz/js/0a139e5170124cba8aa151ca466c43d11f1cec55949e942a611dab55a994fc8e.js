
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = this.DisposableStack;

const v2 = new v1(v1, v1, this, v1, v1);

try { v2.defer(v2, this, v2, v2); } catch (e) {}