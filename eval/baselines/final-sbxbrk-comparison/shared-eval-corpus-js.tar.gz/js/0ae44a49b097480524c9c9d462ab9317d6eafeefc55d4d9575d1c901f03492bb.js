
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = { h: "boolean" };
FuzzerInjectionPoint(2);
let v2 = "ceil";
FuzzerInjectionPoint(3);
function f3() {
FuzzerInjectionPoint(4);
    let v4 = -163530867;
FuzzerInjectionPoint(5);
    for (let v5 = 0; v5 < 5; v5++) {
FuzzerInjectionPoint(6);
        v4 >> v4;
FuzzerInjectionPoint(7);
        v5 << v5;
FuzzerInjectionPoint(8);
        class C9 extends Set {

            [v4];

        }
FuzzerInjectionPoint(11);
        ({"f":v4,"g":v2,"h":v5,} = v1);
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    return v4;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
f3();
FuzzerInjectionPoint(16);
f3();
FuzzerInjectionPoint(17);
%OptimizeMaglevOnNextCall(f3);
FuzzerInjectionPoint(18);
f3();