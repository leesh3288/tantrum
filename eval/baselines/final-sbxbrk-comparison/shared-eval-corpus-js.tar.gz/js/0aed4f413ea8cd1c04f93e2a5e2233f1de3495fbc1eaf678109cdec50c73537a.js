
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f6(a7, a8, a9) {
FuzzerInjectionPoint(2);
    function f10() {
FuzzerInjectionPoint(3);
        return "NL";
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    const v11 = f10();
FuzzerInjectionPoint(6);
    f10();
FuzzerInjectionPoint(7);
    const v13 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(8);
    for (let v14 = 0; v14 < 5; v14++) {
FuzzerInjectionPoint(9);
        const v15 = v13[v14];
FuzzerInjectionPoint(10);
        v15 != v15;
FuzzerInjectionPoint(11);
        function f17(a18, a19, a20) {
FuzzerInjectionPoint(12);
            return a19;
FuzzerInjectionPoint(13);
        }
FuzzerInjectionPoint(14);
        f17();
FuzzerInjectionPoint(15);
        f17();
FuzzerInjectionPoint(16);
    }
FuzzerInjectionPoint(17);
    const t16 = "byteOffset";
FuzzerInjectionPoint(18);
    t16[9] = "byteOffset";
FuzzerInjectionPoint(19);
    const v25 = a7();
FuzzerInjectionPoint(20);
    function f26() {
FuzzerInjectionPoint(21);
        return -8.23833159526733;
FuzzerInjectionPoint(22);
    }
FuzzerInjectionPoint(23);
    const v27 = f26();
FuzzerInjectionPoint(24);
    v27.f = v27;
FuzzerInjectionPoint(25);
    const v28 = f26();
FuzzerInjectionPoint(26);
    v28.b = v28;
FuzzerInjectionPoint(27);
    const v30 = v25()[3];
FuzzerInjectionPoint(28);
    v30[0] = v30;
FuzzerInjectionPoint(29);
    const t28 = ([3,13,-536870912,6,512,-268435456]).keys;
FuzzerInjectionPoint(30);
    const v33 = t28();
FuzzerInjectionPoint(31);
    [1073741823,1073741825,-46433,-1981471400,8,150907829,6];
FuzzerInjectionPoint(32);
    const t29 = 65535;
FuzzerInjectionPoint(33);
    t29.d = 65535;
FuzzerInjectionPoint(34);
    const v37 = f6(f6, /\u0060/mdvs, v30);
FuzzerInjectionPoint(35);
    v37.h = v37;
FuzzerInjectionPoint(36);
    const v40 = Float32Array().constructor;
FuzzerInjectionPoint(37);
    v40(f6, v40, v11);
FuzzerInjectionPoint(38);
    const v43 = Uint16Array();
FuzzerInjectionPoint(39);
    const t38 = v43.findLastIndex;
FuzzerInjectionPoint(40);
    t38();
FuzzerInjectionPoint(41);
    let v46 = 4096;
FuzzerInjectionPoint(42);
    v46--;
FuzzerInjectionPoint(43);
    const v48 = v46 % v46;
FuzzerInjectionPoint(44);
    v48 * v48;
FuzzerInjectionPoint(45);
    const v51 = Uint8Array.length;
FuzzerInjectionPoint(46);
    v51 ^ v51;
FuzzerInjectionPoint(47);
    -9973n ^ -9973n;
FuzzerInjectionPoint(48);
    Float32Array();
FuzzerInjectionPoint(49);
    Int16Array();
FuzzerInjectionPoint(50);
    const v69 = Math.cos(v33);
FuzzerInjectionPoint(51);
    class C71 {

        h = "1073741823";

    }
FuzzerInjectionPoint(54);
    const v72 = C71();
FuzzerInjectionPoint(55);
    const v73 = { 2147483649: v69, f: v69 };
FuzzerInjectionPoint(56);
    (256).BYTES_PER_ELEMENT;
FuzzerInjectionPoint(57);
    let v77 = 0;
FuzzerInjectionPoint(58);
    v77++;
FuzzerInjectionPoint(59);
    v77 < 10;
FuzzerInjectionPoint(60);
    Uint32Array().BYTES_PER_ELEMENT;
FuzzerInjectionPoint(61);
    const v86 = -2455;
FuzzerInjectionPoint(62);
    v86 >> v86;
FuzzerInjectionPoint(63);
    BigInt64Array(9, -256, 3127);
FuzzerInjectionPoint(64);
    function f90() {
FuzzerInjectionPoint(65);
        return 268435456;
FuzzerInjectionPoint(66);
    }
FuzzerInjectionPoint(67);
    function f91(a92, a93, a94, a95) {
FuzzerInjectionPoint(68);
        return f91;
FuzzerInjectionPoint(69);
    }
FuzzerInjectionPoint(70);
    /[x]*/mudsg;
FuzzerInjectionPoint(71);
    class C97 {

    }
FuzzerInjectionPoint(73);
    class C98 extends C97 {

    }
FuzzerInjectionPoint(75);
    const v99 = C98();
FuzzerInjectionPoint(76);
    f91(Float32Array, v73, 268435456, Uint16Array);
FuzzerInjectionPoint(77);
    const v102 = f90();
FuzzerInjectionPoint(78);
    f90().toString(v43, 1024, -256);
FuzzerInjectionPoint(79);
    const v105 = f90();
FuzzerInjectionPoint(80);
    let v106 = f90();
FuzzerInjectionPoint(81);
    [f91,v106,...BigInt64Array] = v102;
FuzzerInjectionPoint(82);
    const v107 = Uint32Array(v105);
FuzzerInjectionPoint(83);
    v107[69] = v107;
FuzzerInjectionPoint(84);
    Date();
FuzzerInjectionPoint(85);
    v99.length = Date;
FuzzerInjectionPoint(86);
    Date(v46);
FuzzerInjectionPoint(87);
    Date++;
FuzzerInjectionPoint(88);
    WeakMap("NL");
FuzzerInjectionPoint(89);
    [-16,331888118,52077,536870912,-2147483649,536870887,-1565868922,0,-21341,7];
FuzzerInjectionPoint(90);
    [8,1000,-128,-2147483648,245275931,-14];
FuzzerInjectionPoint(91);
    ([536870888,697999288,4,-16,1000,6,127]).reduceRight(v72);
FuzzerInjectionPoint(92);
    [4096,-25476,-1845216104,747368961,536870888,10,1754060307];
FuzzerInjectionPoint(93);
    for (let v119 = 0; v119 < 5; v119++) {
FuzzerInjectionPoint(94);
        "p" == "p";
FuzzerInjectionPoint(95);
        const v122 = "p" + v119;
FuzzerInjectionPoint(96);
        v122 == v122;
FuzzerInjectionPoint(97);
    }
FuzzerInjectionPoint(98);
    [512,-2147483647,-65535,65535,7];
FuzzerInjectionPoint(99);
    ("exec").trimEnd();
FuzzerInjectionPoint(100);
    function f128(a129, a130, a131) {
FuzzerInjectionPoint(101);
        return "NL";
FuzzerInjectionPoint(102);
    }
FuzzerInjectionPoint(103);
    f128();
FuzzerInjectionPoint(104);
    /()7/dvsgi;
FuzzerInjectionPoint(105);
    const v134 = [65537,5115,2147483647,64,-256,-9223372036854775807,-268435456,0];
FuzzerInjectionPoint(106);
    const v136 = 4294967295n ^ 4294967295n;
FuzzerInjectionPoint(107);
    v136 ^ v136;
FuzzerInjectionPoint(108);
    [536870912,1979792005,-1024];
FuzzerInjectionPoint(109);
    const v140 = [43680,-536870912,4294967297,9332,9223372036854775807,-9223372036854775808,-9,43727,1175231882];
FuzzerInjectionPoint(110);
    const v141 = [-58284,14,-1073741824,7947,-1,255];
FuzzerInjectionPoint(111);
    class C142 {

        2981 = v134;

        static 9 = v141;

    }
FuzzerInjectionPoint(115);
    const v143 = %WasmArray();
FuzzerInjectionPoint(116);
    while ((() => {
FuzzerInjectionPoint(117);
            for (let v147 = 0; v147 < 32; v147++) {
FuzzerInjectionPoint(118);
            }
FuzzerInjectionPoint(119);
            return 0;
FuzzerInjectionPoint(120);
        })()) {
FuzzerInjectionPoint(121);
        let v149;
FuzzerInjectionPoint(122);
        try { v149 = v141.toSpliced(C142, ...v140, ...4294967295n, v143); } catch (e) {}
FuzzerInjectionPoint(123);
        function F152(a154, a155, a156) {
FuzzerInjectionPoint(124);
            if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(125);
        }
FuzzerInjectionPoint(126);
        try { Array.constructor("7u0", Array); } catch (e) {}
FuzzerInjectionPoint(127);
        new F152(Array, 4294967295n, v149);
FuzzerInjectionPoint(128);
    }
FuzzerInjectionPoint(129);
    class C161 {

    }
FuzzerInjectionPoint(131);
    return 1024;
FuzzerInjectionPoint(132);
}