
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v7 = Math.sign(a4 ^ Int32Array);
FuzzerInjectionPoint(3);
    const v8 = v7 - v7;
FuzzerInjectionPoint(4);
    for (let v9 = 0; v9 < 5; v9++) {
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    const v10 = Math.cbrt(v8);
FuzzerInjectionPoint(7);
    return v10 - v10;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f1(f1(f1, f1, f1), f1, Int32Array);
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(11);
f1();
FuzzerInjectionPoint(12);