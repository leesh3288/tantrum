
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    return f0;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
class C1 extends f0 {

    constructor(a3, a4) {
FuzzerInjectionPoint(6);
        super();
FuzzerInjectionPoint(7);
        function F5() {
FuzzerInjectionPoint(8);
            if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(9);
        }
FuzzerInjectionPoint(10);
        class C7 extends F5 {

        }
FuzzerInjectionPoint(12);
        const v8 = new C7();
FuzzerInjectionPoint(13);
        JSON.MIN_VALUE = v8;
FuzzerInjectionPoint(14);
        JSON.parse(JSON.stringify(JSON));
FuzzerInjectionPoint(15);
    }

}
FuzzerInjectionPoint(17);
const v12 = new C1();
FuzzerInjectionPoint(18);
new C1(v12, v12);