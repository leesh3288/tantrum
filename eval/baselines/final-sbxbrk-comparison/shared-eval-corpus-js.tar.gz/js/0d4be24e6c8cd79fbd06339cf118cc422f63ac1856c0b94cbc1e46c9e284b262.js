
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = constructor();
FuzzerInjectionPoint(2);
function f5() {
FuzzerInjectionPoint(3);
    return 59;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f5.minimumFractionDigits = 13;
FuzzerInjectionPoint(6);
v4.constructor = f5;
FuzzerInjectionPoint(7);
const v6 = v4.Intl;
FuzzerInjectionPoint(8);
const t7 = v6.NumberFormat;
FuzzerInjectionPoint(9);
t7(v6, constructor).formatRangeToParts(-40722, 59);
FuzzerInjectionPoint(10);