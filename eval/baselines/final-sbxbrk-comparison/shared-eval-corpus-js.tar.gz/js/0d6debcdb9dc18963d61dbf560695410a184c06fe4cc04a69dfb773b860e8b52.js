
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v5 = {

        get h() {
FuzzerInjectionPoint(4);
            this.toString = 936091.3029627262;
FuzzerInjectionPoint(5);
        },

        125: 936091.3029627262,

        769409271: "h",

        [-2]: "h",

        d: 936091.3029627262,

        c: 936091.3029627262,

        __proto__: "h",

        h: "h",

        a: -0.98786881964784,

        ..."h",

    };
FuzzerInjectionPoint(16);
    return v5;
FuzzerInjectionPoint(17);
}
FuzzerInjectionPoint(18);
f0();
FuzzerInjectionPoint(19);
const v7 = [];
FuzzerInjectionPoint(20);
[];
FuzzerInjectionPoint(21);
[];
FuzzerInjectionPoint(22);
class C10 {

    static #n(a12, a13, a14) {
FuzzerInjectionPoint(24);
        try { v7.slice(); } catch (e) {}
FuzzerInjectionPoint(25);
    }

    #m(a18, a19, a20) {
FuzzerInjectionPoint(27);
        [a19,this];
FuzzerInjectionPoint(28);
    }

}
FuzzerInjectionPoint(30);
new C10();
FuzzerInjectionPoint(31);
new C10();
FuzzerInjectionPoint(32);
class C27 {

}
FuzzerInjectionPoint(34);
try { C27.call(); } catch (e) {}
FuzzerInjectionPoint(35);
const v30 = {};
FuzzerInjectionPoint(36);
v30.g = v30;
FuzzerInjectionPoint(37);
function f31() {
FuzzerInjectionPoint(38);
    const v32 = { g: v30, c: f0, __proto__: "number" };
FuzzerInjectionPoint(39);
}
FuzzerInjectionPoint(40);
function f36() {
FuzzerInjectionPoint(41);
    const v38 = Symbol.dispose;
FuzzerInjectionPoint(42);
    const v40 = {

        [v38]() {
FuzzerInjectionPoint(44);
        },

    };
FuzzerInjectionPoint(46);
    v40.b = v40;
FuzzerInjectionPoint(47);
    function f42(a43, a44, a45, a46) {
FuzzerInjectionPoint(48);
        a43 / a43;
FuzzerInjectionPoint(49);
    }
FuzzerInjectionPoint(50);
    f42(-2.0, f31, 512, -7.934380451229542e+307);
FuzzerInjectionPoint(51);
    const v49 = { a: -4294967295 };
FuzzerInjectionPoint(52);
    v49.a;
FuzzerInjectionPoint(53);
    const v52 = v49.a;
FuzzerInjectionPoint(54);
    v52 | v52;
FuzzerInjectionPoint(55);
    v49.b = v49;
FuzzerInjectionPoint(56);
}
FuzzerInjectionPoint(57);
f36();
FuzzerInjectionPoint(58);
f36();
FuzzerInjectionPoint(59);
%OptimizeMaglevOnNextCall(f36);
FuzzerInjectionPoint(60);
f36();