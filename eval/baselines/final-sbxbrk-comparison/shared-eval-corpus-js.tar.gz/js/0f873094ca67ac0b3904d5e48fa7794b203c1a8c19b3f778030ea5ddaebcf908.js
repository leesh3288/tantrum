
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    let v3 = Math.min(a1, a1);
FuzzerInjectionPoint(3);
    return v3--;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f0(f0);
FuzzerInjectionPoint(6);
const v6 = f0();
FuzzerInjectionPoint(7);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(8);
f0(v6);
FuzzerInjectionPoint(9);