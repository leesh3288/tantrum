
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[-1.53887860253347e+308,-669.4665747969964,1.7852609516165556e+308,0.1324545233136476,-1e-15,2.0,-959938.9780722725];
FuzzerInjectionPoint(2);
const v17 = new Uint32Array();
FuzzerInjectionPoint(3);
const v18 = [268435441,31036,0,57026,-276791429,-9223372036854775808,1265019242,-1024,9,61267];
FuzzerInjectionPoint(4);
function f19(a20, a21, a22) {
FuzzerInjectionPoint(5);
    function f23(a24, a25, a26) {
FuzzerInjectionPoint(6);
        function f27() {
FuzzerInjectionPoint(7);
            for (let v28 = 0; v28 < 5; v28++) {
FuzzerInjectionPoint(8);
                ("-5").split();
FuzzerInjectionPoint(9);
                function F31(a33, a34) {
FuzzerInjectionPoint(10);
                    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(11);
                }
FuzzerInjectionPoint(12);
                this.console.trace();
FuzzerInjectionPoint(13);
                let v39 = -15;
FuzzerInjectionPoint(14);
                v39--;
FuzzerInjectionPoint(15);
                delete Float64Array[F31];
FuzzerInjectionPoint(16);
            }
FuzzerInjectionPoint(17);
            v17[a24] -= 6;
FuzzerInjectionPoint(18);
        }
FuzzerInjectionPoint(19);
        f27();
FuzzerInjectionPoint(20);
        return f23;
FuzzerInjectionPoint(21);
    }
FuzzerInjectionPoint(22);
    f23();
FuzzerInjectionPoint(23);
    Reflect.construct(f23, []);
FuzzerInjectionPoint(24);
    return f19;
FuzzerInjectionPoint(25);
}
FuzzerInjectionPoint(26);
const v47 = f19();
FuzzerInjectionPoint(27);
try { v47(Uint8ClampedArray, v18, BigInt64Array); } catch (e) {}
FuzzerInjectionPoint(28);