
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
/(x)(x)(x)\1*/msgi.constructor.$2;
FuzzerInjectionPoint(2);