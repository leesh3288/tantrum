
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
function f1() {
FuzzerInjectionPoint(4);
    class C2 {

    }
FuzzerInjectionPoint(6);
    C2.__proto__;
FuzzerInjectionPoint(7);
    C2 instanceof C0;
FuzzerInjectionPoint(8);
    return C0;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f1();
FuzzerInjectionPoint(11);
f1();
FuzzerInjectionPoint(12);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(13);
f1();