
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-4294967295,4294967295,257];
FuzzerInjectionPoint(2);
const v4 = new SharedArrayBuffer(1251);
FuzzerInjectionPoint(3);
const v6 = new Uint8ClampedArray(v4);
FuzzerInjectionPoint(4);
const v8 = new Float64Array(v1);
FuzzerInjectionPoint(5);
function f9() {
FuzzerInjectionPoint(6);
    return v6;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f9[Symbol.species] = f9;
FuzzerInjectionPoint(9);
v8.constructor = f9;
FuzzerInjectionPoint(10);
v8.slice();
FuzzerInjectionPoint(11);