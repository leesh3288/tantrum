
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-596992.2717851705,1.3656356845740762e+308];
FuzzerInjectionPoint(2);
Object.defineProperty(v0, 82, { writable: true, enumerable: true, value: v0 });
FuzzerInjectionPoint(3);
v0.concat().pop();
FuzzerInjectionPoint(4);