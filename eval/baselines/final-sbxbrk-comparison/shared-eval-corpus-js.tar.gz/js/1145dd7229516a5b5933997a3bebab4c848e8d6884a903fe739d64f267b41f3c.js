
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = "boolean" + -Infinity;
FuzzerInjectionPoint(2);
const v6 = this.Intl.Locale;
FuzzerInjectionPoint(3);
Object.defineProperty(v6, "region", { writable: true, configurable: true, enumerable: true, value: 324 });
FuzzerInjectionPoint(4);
const v7 = new v6(v4, v6);
FuzzerInjectionPoint(5);
v7.minimize();
FuzzerInjectionPoint(6);