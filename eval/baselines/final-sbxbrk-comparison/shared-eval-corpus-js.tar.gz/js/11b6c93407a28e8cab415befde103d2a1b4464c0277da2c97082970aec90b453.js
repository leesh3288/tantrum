
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    Math.abs(([536870912,4])[7]);
FuzzerInjectionPoint(3);
    return f0;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f0();
FuzzerInjectionPoint(6);
const v6 = f0();
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(8);
v6();
FuzzerInjectionPoint(9);