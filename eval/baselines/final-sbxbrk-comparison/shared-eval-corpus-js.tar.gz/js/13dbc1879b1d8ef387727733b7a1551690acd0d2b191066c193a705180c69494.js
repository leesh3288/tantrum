
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
try { new BigInt64Array(Int32Array, 2700, BigInt64Array); } catch (e) {}
FuzzerInjectionPoint(2);
new BigInt64Array(1);
FuzzerInjectionPoint(3);
try { Int32Array.map(1); } catch (e) {}
FuzzerInjectionPoint(4);
const v9 = [-965325.5737473707,Infinity,3.690227495513806,-1.7976931348623157e+308,-1000000.0,0.3751670739302494,5.341734903100526e+307,161.45646147588536,2.220446049250313e-16,119006.43655660725];
FuzzerInjectionPoint(5);
const v10 = [-0.0,-788868.535099441,0.91716152988093,2.0,2.0,600871.3279312886,-1000.0,1.1439888207523336e+308,1.6568587532314775e+308];
FuzzerInjectionPoint(6);
v10[3];
FuzzerInjectionPoint(7);
const v12 = [Infinity,-1000000.0,-1000000000000.0,-6.000695557997213,5.0,530715.3501997271,-6.5599068958448665];
FuzzerInjectionPoint(8);
function F13(a15, a16, a17, a18) {
FuzzerInjectionPoint(9);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(10);
    try { a18.reduce(BigInt64Array); } catch (e) {}
FuzzerInjectionPoint(11);
    this.a = v12;
FuzzerInjectionPoint(12);
    this.e = 129;
FuzzerInjectionPoint(13);
    this.d = Int32Array;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
new F13(1, v12, 1, v9);
FuzzerInjectionPoint(16);
function f21() {
FuzzerInjectionPoint(17);
    1.0718869673249073e+308 / 1.0718869673249073e+308;
FuzzerInjectionPoint(18);
    1.0718869673249073e+308 << 1.0718869673249073e+308;
FuzzerInjectionPoint(19);
    const v25 = [];
FuzzerInjectionPoint(20);
    4 & 4;
FuzzerInjectionPoint(21);
    try { Float64Array.apply(v10, Uint32Array); } catch (e) {}
FuzzerInjectionPoint(22);
    const v32 = new Float64Array(4);
FuzzerInjectionPoint(23);
    try { v32.toLocaleString(); } catch (e) {}
FuzzerInjectionPoint(24);
    const v35 = new BigUint64Array();
FuzzerInjectionPoint(25);
    try { new v35(); } catch (e) {}
FuzzerInjectionPoint(26);
    const t25 = /[-123]/msgiy;
FuzzerInjectionPoint(27);
    t25.__proto__ = [-0.812183441143933,985315.9155150589,2.0,-0.004237010880142833,Infinity,-1000000000000.0,-3.0];
FuzzerInjectionPoint(28);
    try { new Int16Array(v25, 1.0718869673249073e+308, Int16Array); } catch (e) {}
FuzzerInjectionPoint(29);
    const v42 = new Int16Array(2891);
FuzzerInjectionPoint(30);
    let v43 = undefined;
FuzzerInjectionPoint(31);
    const v44 = { f: Float64Array };
FuzzerInjectionPoint(32);
    const v45 = v44?.f;
FuzzerInjectionPoint(33);
    try { new v45(v44, v44, Int32Array); } catch (e) {}
FuzzerInjectionPoint(34);
    v43 = v44;
FuzzerInjectionPoint(35);
    v44.c = v44;
FuzzerInjectionPoint(36);
    function F47() {
FuzzerInjectionPoint(37);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(38);
    }
FuzzerInjectionPoint(39);
    const v49 = [268435456,-11,3];
FuzzerInjectionPoint(40);
    try { v49.unshift(1); } catch (e) {}
FuzzerInjectionPoint(41);
    const v52 = new Uint8ClampedArray();
FuzzerInjectionPoint(42);
    BigInt64Array.prototype = BigInt64Array;
FuzzerInjectionPoint(43);
    for (const v55 of v52) {
FuzzerInjectionPoint(44);
        v49[2147483648] = 1;
FuzzerInjectionPoint(45);
        BigInt64Array % BigInt64Array;
FuzzerInjectionPoint(46);
    }
FuzzerInjectionPoint(47);
    const v58 = { 9: -62202n };
FuzzerInjectionPoint(48);
    v58[9] = v58;
FuzzerInjectionPoint(49);
    for (const v59 in v42) {
FuzzerInjectionPoint(50);
        -v32;
FuzzerInjectionPoint(51);
        const v61 = [-865879.4747004735];
FuzzerInjectionPoint(52);
        v61[0];
FuzzerInjectionPoint(53);
        function f64(a65) {
FuzzerInjectionPoint(54);
            const v66 = { ...v61 };
FuzzerInjectionPoint(55);
        }
FuzzerInjectionPoint(56);
    }
FuzzerInjectionPoint(57);
    let v67 = 13486;
FuzzerInjectionPoint(58);
    let v68 = ++v67;
FuzzerInjectionPoint(59);
    v68--;
FuzzerInjectionPoint(60);
    function F70(a72) {
FuzzerInjectionPoint(61);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(62);
        try { new this(); } catch (e) {}
FuzzerInjectionPoint(63);
    }
FuzzerInjectionPoint(64);
    new F70();
FuzzerInjectionPoint(65);
    const v75 = {};
FuzzerInjectionPoint(66);
    v75.e = v75;
FuzzerInjectionPoint(67);
}
FuzzerInjectionPoint(68);
f21();
FuzzerInjectionPoint(69);