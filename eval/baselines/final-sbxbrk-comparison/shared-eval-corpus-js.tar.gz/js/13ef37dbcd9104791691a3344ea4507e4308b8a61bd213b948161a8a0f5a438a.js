
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint32Array(127);
FuzzerInjectionPoint(2);
v2[43] = 127;
FuzzerInjectionPoint(3);
v2.toSorted();
FuzzerInjectionPoint(4);