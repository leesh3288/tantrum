
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
Date();
FuzzerInjectionPoint(2);
try { Date.reduce(); } catch (e) {}
FuzzerInjectionPoint(3);
Symbol.toPrimitive;
FuzzerInjectionPoint(4);
try { Date.sort(); } catch (e) {}
FuzzerInjectionPoint(5);
const t4 = "toString";
FuzzerInjectionPoint(6);
t4.codePointAt = "toString";
FuzzerInjectionPoint(7);
1024 ^ 1024;
FuzzerInjectionPoint(8);
BigUint64Array.BYTES_PER_ELEMENT = BigUint64Array;
FuzzerInjectionPoint(9);
[];
FuzzerInjectionPoint(10);
function f18() {
FuzzerInjectionPoint(11);
    let v19 = 1e-15;
FuzzerInjectionPoint(12);
    function* f22(a23, a24, a25, a26) {
FuzzerInjectionPoint(13);
        v19 = 0.1448691127490499;
FuzzerInjectionPoint(14);
        yield 90;
FuzzerInjectionPoint(15);
        yield 8.862371043647107e+307;
FuzzerInjectionPoint(16);
    }
FuzzerInjectionPoint(17);
    f22();
FuzzerInjectionPoint(18);
    f22();
FuzzerInjectionPoint(19);
    %OptimizeFunctionOnNextCall(f22);
FuzzerInjectionPoint(20);
    f22(v19);
FuzzerInjectionPoint(21);
}
FuzzerInjectionPoint(22);
const v33 = f18();
FuzzerInjectionPoint(23);
v33 ?? v33;
FuzzerInjectionPoint(24);