
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 {

}
FuzzerInjectionPoint(3);
function f2(a3, a4) {
FuzzerInjectionPoint(4);
    return 883.0788406336233;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
C1[Symbol.toPrimitive] = f2;
FuzzerInjectionPoint(7);
constructor.valueOf = Symbol;
FuzzerInjectionPoint(8);
const t7 = constructor().Intl.NumberFormat;
FuzzerInjectionPoint(9);
const v12 = t7();
FuzzerInjectionPoint(10);
v12.formatRange(C1, C1);
FuzzerInjectionPoint(11);
try { v12.formatRangeToParts(constructor, "bigint"); } catch (e) {}