
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    class C1 {

    }
FuzzerInjectionPoint(4);
    try { C1.call(C1, C1, C1, f0); } catch (e) {}
FuzzerInjectionPoint(5);
    return f0;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v3 = f0();
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(10);
const v5 = f0();
FuzzerInjectionPoint(11);
function f8(a9, a10, a11) {
FuzzerInjectionPoint(12);
    return { [2]: 268435456 };
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
f8(v5, v3, 2);
FuzzerInjectionPoint(15);
f8();
FuzzerInjectionPoint(16);
%OptimizeMaglevOnNextCall(f8);
FuzzerInjectionPoint(17);
f8();
FuzzerInjectionPoint(18);
gc();
FuzzerInjectionPoint(19);
function f18(a19, a20) {
FuzzerInjectionPoint(20);
    return a19;
FuzzerInjectionPoint(21);
}
FuzzerInjectionPoint(22);
const v21 = f18();
FuzzerInjectionPoint(23);
f18(v21, v21);
FuzzerInjectionPoint(24);
%OptimizeMaglevOnNextCall(f18);
FuzzerInjectionPoint(25);
f18();