
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);
function f1() {
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
function f2() {
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
function f3(a4, a5, a6, a7) {
FuzzerInjectionPoint(8);
    const v18 = {

        get e() {
FuzzerInjectionPoint(10);
        },

        valueOf(a10, a11) {
FuzzerInjectionPoint(12);
            const v17 = {

                [Symbol]() {
FuzzerInjectionPoint(14);
                    const v16 = {

                        next() {
FuzzerInjectionPoint(16);
                            const v15 = {};
FuzzerInjectionPoint(17);
                        },

                    };
FuzzerInjectionPoint(19);
                },

            };
FuzzerInjectionPoint(21);
        },

    };
FuzzerInjectionPoint(23);
}
FuzzerInjectionPoint(24);
const v19 = [];
FuzzerInjectionPoint(25);
class C20 {

    static toString() {
FuzzerInjectionPoint(27);
        for (let [v22] of v19) {
FuzzerInjectionPoint(28);
        }
FuzzerInjectionPoint(29);
    }

}
FuzzerInjectionPoint(31);
function F23() {
FuzzerInjectionPoint(32);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(33);
}
FuzzerInjectionPoint(34);
class C25 {

}
FuzzerInjectionPoint(36);
function f27(a28) {
FuzzerInjectionPoint(37);
}
FuzzerInjectionPoint(38);
class C29 extends f27 {

}
FuzzerInjectionPoint(40);
function f30() {
FuzzerInjectionPoint(41);
    [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(42);
    for (let v32 = 0; v32 < 5; v32++) {
FuzzerInjectionPoint(43);
        ArrayBuffer.length;
FuzzerInjectionPoint(44);
        const v36 = {};
FuzzerInjectionPoint(45);
        v32 || v32;
FuzzerInjectionPoint(46);
    }
FuzzerInjectionPoint(47);
}
FuzzerInjectionPoint(48);
f30();
FuzzerInjectionPoint(49);
%OptimizeMaglevOnNextCall(f30);
FuzzerInjectionPoint(50);
f30();
FuzzerInjectionPoint(51);
/b/mvsy;
FuzzerInjectionPoint(52);
/9()(ab)/udsg;
FuzzerInjectionPoint(53);
/hA/sg;
FuzzerInjectionPoint(54);
let v44 = undefined;
FuzzerInjectionPoint(55);
function f45() {
FuzzerInjectionPoint(56);
    const v46 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(57);
    for (let v47 = 0; v47 < 5; v47++) {
FuzzerInjectionPoint(58);
        -v46[v47];
FuzzerInjectionPoint(59);
        v44--;
FuzzerInjectionPoint(60);
        [];
FuzzerInjectionPoint(61);
    }
FuzzerInjectionPoint(62);
    function f52(a53) {
FuzzerInjectionPoint(63);
        const v54 = { __proto__: v46 };
FuzzerInjectionPoint(64);
    }
FuzzerInjectionPoint(65);
    let v56;
FuzzerInjectionPoint(66);
    try { v56 = Symbol(f52); } catch (e) {}
FuzzerInjectionPoint(67);
    v56 ?? v56;
FuzzerInjectionPoint(68);
    /J*/mdsgy;
FuzzerInjectionPoint(69);
    /\1\2(a(?:\1(b\1\2))\2)\1/msiy;
FuzzerInjectionPoint(70);
    /cfoo[z]*/msiy;
FuzzerInjectionPoint(71);
    function f61() {
FuzzerInjectionPoint(72);
        function f62(a63) {
FuzzerInjectionPoint(73);
        }
FuzzerInjectionPoint(74);
        function f64(a65, a66, a67) {
FuzzerInjectionPoint(75);
        }
FuzzerInjectionPoint(76);
    }
FuzzerInjectionPoint(77);
    return -869939044;
FuzzerInjectionPoint(78);
}
FuzzerInjectionPoint(79);
f45();
FuzzerInjectionPoint(80);
f45();
FuzzerInjectionPoint(81);
%OptimizeMaglevOnNextCall(f45);
FuzzerInjectionPoint(82);
f45();