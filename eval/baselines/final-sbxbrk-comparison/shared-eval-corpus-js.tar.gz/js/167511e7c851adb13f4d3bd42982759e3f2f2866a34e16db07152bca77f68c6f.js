
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    class C3 {

    }
FuzzerInjectionPoint(4);
    try {
FuzzerInjectionPoint(5);
        C3.trunc();
FuzzerInjectionPoint(6);
    } catch(e5) {
FuzzerInjectionPoint(7);
        e5.name;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    return f0;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f0();
FuzzerInjectionPoint(12);
f0();
FuzzerInjectionPoint(13);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(14);
f0();