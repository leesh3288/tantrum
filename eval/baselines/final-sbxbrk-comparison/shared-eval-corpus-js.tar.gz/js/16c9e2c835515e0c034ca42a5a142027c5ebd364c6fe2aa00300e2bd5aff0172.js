
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 {

    2812 = 280.72611103907184;

}
FuzzerInjectionPoint(4);
const v2 = new C1();
FuzzerInjectionPoint(5);
const v3 = [-21603.41681207728,0.0,1.0,-4.0,-3.1704553645229616,-2.220446049250313e-16,8.539133097682312e+307,-460.6081428209417];
FuzzerInjectionPoint(6);
function f4(a5, a6) {
FuzzerInjectionPoint(7);
    const v7 = a5.constructor;
FuzzerInjectionPoint(8);
    try { v7(a5); } catch (e) {}
FuzzerInjectionPoint(9);
    a6[5];
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f4(f4, v3);
FuzzerInjectionPoint(12);
const v13 = new Proxy(v2, {});
FuzzerInjectionPoint(13);
v13[2812] = v13;