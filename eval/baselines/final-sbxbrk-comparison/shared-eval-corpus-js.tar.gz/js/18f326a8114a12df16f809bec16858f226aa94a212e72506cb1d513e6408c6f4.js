
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    class C4 {

    }
FuzzerInjectionPoint(4);
    Math.b = Math;
FuzzerInjectionPoint(5);
    a2++;
FuzzerInjectionPoint(6);
    function f7(a8) {
FuzzerInjectionPoint(7);
        return C4;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    class C9 extends f7 {

    }
FuzzerInjectionPoint(11);
    const v10 = Math.log10(Math);
FuzzerInjectionPoint(12);
    function f11(a12, a13, a14) {
FuzzerInjectionPoint(13);
        a14 ^ a14;
FuzzerInjectionPoint(14);
        -a14;
FuzzerInjectionPoint(15);
        return a13;
FuzzerInjectionPoint(16);
    }
FuzzerInjectionPoint(17);
    f11.call();
FuzzerInjectionPoint(18);
    f11(f11, C4, v10);
FuzzerInjectionPoint(19);
    return f0;
FuzzerInjectionPoint(20);
}
FuzzerInjectionPoint(21);
f0();
FuzzerInjectionPoint(22);
f0();
FuzzerInjectionPoint(23);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(24);
f0();