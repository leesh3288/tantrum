
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(2);
    const v7 = 4.0 << a3;
FuzzerInjectionPoint(3);
    for (let v8 = 0; v8 < 5; v8++) {
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    const v9 = 4 >> v7;
FuzzerInjectionPoint(6);
    const v10 = { [-65537]: v9 };
FuzzerInjectionPoint(7);
    return a5;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v11 = f2(-65537, -65537, -65537);
FuzzerInjectionPoint(10);
const v12 = f2(4, v11, 4);
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(12);
f2(v12, v11, v11);
FuzzerInjectionPoint(13);