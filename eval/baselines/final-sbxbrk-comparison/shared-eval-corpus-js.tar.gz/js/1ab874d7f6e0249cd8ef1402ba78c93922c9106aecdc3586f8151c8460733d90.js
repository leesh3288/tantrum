
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Date(Date);
FuzzerInjectionPoint(2);
const v4 = v1[Symbol.toPrimitive];
FuzzerInjectionPoint(3);
try { v4.apply(Symbol); } catch (e) {}
FuzzerInjectionPoint(4);