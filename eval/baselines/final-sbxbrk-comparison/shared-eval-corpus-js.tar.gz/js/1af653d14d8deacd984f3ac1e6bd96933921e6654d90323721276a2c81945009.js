
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v5 = ([-1000000000000.0,-367.81301734010196,-476.74454452527516,-2.6076772957175923e+306,1.7976931348623157e+308,0.11176331082589741,Infinity,1000000.0]).flat();
FuzzerInjectionPoint(3);
    let v6;
FuzzerInjectionPoint(4);
    try { v6 = v5.reduceRight(a1); } catch (e) {}
FuzzerInjectionPoint(5);
    return v6;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f0();
FuzzerInjectionPoint(8);
f0(f0, f0, f0);
FuzzerInjectionPoint(9);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(10);
f0();
FuzzerInjectionPoint(11);