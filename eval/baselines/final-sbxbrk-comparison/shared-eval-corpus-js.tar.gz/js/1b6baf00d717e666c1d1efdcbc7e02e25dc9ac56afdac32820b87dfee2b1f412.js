
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-2092293747];
FuzzerInjectionPoint(2);
function F1(a3) {
FuzzerInjectionPoint(3);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
[4.0,4.664232733965421e+307];
FuzzerInjectionPoint(6);
const v5 = [-1000000.0,0.014234501761067442,111.85240990318448,NaN,1000.0,0.8015664788631287,3.0,1.0,-3.8206199326475705];
FuzzerInjectionPoint(7);
function f6() {
FuzzerInjectionPoint(8);
    function f7(a8) {
FuzzerInjectionPoint(9);
        return F1;
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    function f9(a10) {
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    f9();
FuzzerInjectionPoint(14);
    const v13 = ("1073741823")[2];
FuzzerInjectionPoint(15);
    if (v13) {
FuzzerInjectionPoint(16);
        const v14 = {};
FuzzerInjectionPoint(17);
        function f15() {
FuzzerInjectionPoint(18);
            return v13;
FuzzerInjectionPoint(19);
        }
FuzzerInjectionPoint(20);
        function f16(a17) {
FuzzerInjectionPoint(21);
        }
FuzzerInjectionPoint(22);
        Object.defineProperty(v14, "f", { configurable: true, enumerable: true, get: f15, set: f16 });
FuzzerInjectionPoint(23);
        const v18 = {};
FuzzerInjectionPoint(24);
        const v19 = {};
FuzzerInjectionPoint(25);
    } else {
FuzzerInjectionPoint(26);
        v0 instanceof v13;
FuzzerInjectionPoint(27);
    }
FuzzerInjectionPoint(28);
    ("1073741823")[2];
FuzzerInjectionPoint(29);
    return v5;
FuzzerInjectionPoint(30);
}
FuzzerInjectionPoint(31);
f6();
FuzzerInjectionPoint(32);
f6();
FuzzerInjectionPoint(33);
%OptimizeMaglevOnNextCall(f6);
FuzzerInjectionPoint(34);
f6();
FuzzerInjectionPoint(35);