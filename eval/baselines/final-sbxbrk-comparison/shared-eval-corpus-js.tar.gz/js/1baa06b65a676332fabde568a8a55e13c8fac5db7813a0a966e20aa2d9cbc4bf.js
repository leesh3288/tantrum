
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(2);
    const v9 = !(!({})[2]);
FuzzerInjectionPoint(3);
    v9 && v9;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f2();
FuzzerInjectionPoint(6);
f2();
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(8);
f2();
FuzzerInjectionPoint(9);