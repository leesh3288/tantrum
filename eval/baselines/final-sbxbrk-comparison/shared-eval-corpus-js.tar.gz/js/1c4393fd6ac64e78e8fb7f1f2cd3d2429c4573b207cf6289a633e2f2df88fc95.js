
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = `
FuzzerInjectionPoint(2);
    const v1 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(3);
    function f2() {
FuzzerInjectionPoint(4);
        const v3 = f2.toLocaleString(v0, v0);
FuzzerInjectionPoint(5);
        const v4 = /Q0k/ug;
FuzzerInjectionPoint(6);
        /xyz{1,}^xxx$/vgy;
FuzzerInjectionPoint(7);
        v3.replace(v4, v3);
FuzzerInjectionPoint(8);
        return v1;
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
    f2();
FuzzerInjectionPoint(11);
`;
FuzzerInjectionPoint(12);
eval(v0);
FuzzerInjectionPoint(13);