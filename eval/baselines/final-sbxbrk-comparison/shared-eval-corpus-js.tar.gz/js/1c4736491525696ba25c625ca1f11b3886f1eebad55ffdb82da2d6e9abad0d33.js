
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = {};
FuzzerInjectionPoint(2);
function f2(a3, a4) {
FuzzerInjectionPoint(3);
    const v17 = {

        [a4](a6, a7) {
FuzzerInjectionPoint(5);
            while ((() => {
FuzzerInjectionPoint(6);
                    v1[1824559342] = this;
FuzzerInjectionPoint(7);
                    return 0;
FuzzerInjectionPoint(8);
                })()) {
FuzzerInjectionPoint(9);
                function f13() {
FuzzerInjectionPoint(10);
                    return -0.0;
FuzzerInjectionPoint(11);
                }
FuzzerInjectionPoint(12);
            }
FuzzerInjectionPoint(13);
        },

    };
FuzzerInjectionPoint(15);
    return a3;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
function f20() {
FuzzerInjectionPoint(18);
    const v23 = new Uint8Array(2371, -4294967295, -256);
FuzzerInjectionPoint(19);
    v23.reverse();
FuzzerInjectionPoint(20);
    Array.isArray(f2);
FuzzerInjectionPoint(21);
    return -256;
FuzzerInjectionPoint(22);
}
FuzzerInjectionPoint(23);
f20();
FuzzerInjectionPoint(24);
f20();
FuzzerInjectionPoint(25);
%OptimizeMaglevOnNextCall(f20);
FuzzerInjectionPoint(26);
f20();