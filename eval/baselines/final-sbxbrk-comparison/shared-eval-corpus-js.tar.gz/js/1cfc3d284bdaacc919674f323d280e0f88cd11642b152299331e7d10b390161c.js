
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v7 = !(!({}).isPrototypeOf());
FuzzerInjectionPoint(3);
    v7 && v7;
FuzzerInjectionPoint(4);
    return a1;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
const v9 = f0(f0, f0, f0);
FuzzerInjectionPoint(7);
const v10 = f0();
FuzzerInjectionPoint(8);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(9);
f0(v9, v10, f0);
FuzzerInjectionPoint(10);