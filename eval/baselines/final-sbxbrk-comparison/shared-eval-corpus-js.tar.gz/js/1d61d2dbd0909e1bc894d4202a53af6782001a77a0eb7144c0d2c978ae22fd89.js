
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);
class C1 extends f0 {

    static {
FuzzerInjectionPoint(5);
        this[1024] = this;
FuzzerInjectionPoint(6);
        ("63515").constructor.fromCodePoint("63515").blink().substring(6);
FuzzerInjectionPoint(7);
    }

}