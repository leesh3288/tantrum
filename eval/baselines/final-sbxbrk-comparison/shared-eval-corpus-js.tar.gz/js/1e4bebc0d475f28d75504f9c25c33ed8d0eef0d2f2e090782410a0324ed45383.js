
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
([2.0,0.0,-4.0,1.7976931348623157e+308,-Infinity,-1.7711996825261416e+308,1.7976931348623157e+308,2.2250738585072014e-308,-934187.265878425]).toLocaleString().replace(/[n\P{Decimal_Number}+]/mdviy);