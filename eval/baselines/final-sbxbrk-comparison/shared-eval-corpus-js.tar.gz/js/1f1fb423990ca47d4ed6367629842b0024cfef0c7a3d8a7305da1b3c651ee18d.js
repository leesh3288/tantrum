
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    const v2 = [9007199254740990,-9007199254740990,256];
FuzzerInjectionPoint(3);
    const v5 = new Proxy(v2, {});
FuzzerInjectionPoint(4);
    const v6 = v5.slice();
FuzzerInjectionPoint(5);
    try { v6.map(a1); } catch (e) {}
FuzzerInjectionPoint(6);
    return f0;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
const v8 = f0(f0);
FuzzerInjectionPoint(9);
v8();
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(11);
v8(f0);
FuzzerInjectionPoint(12);