
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = /W/dsgi;
FuzzerInjectionPoint(2);
function f1(a2, a3) {
FuzzerInjectionPoint(3);
    a2 ^ a2;
FuzzerInjectionPoint(4);
    const v5 = {};
FuzzerInjectionPoint(5);
    const v6 = v5.constructor;
FuzzerInjectionPoint(6);
    function F7(a9, a10, a11) {
FuzzerInjectionPoint(7);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(8);
        this(v6);
FuzzerInjectionPoint(9);
        a9.compile(v5);
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    return f1;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f1(v0, v0);
FuzzerInjectionPoint(14);
f1(v0);
FuzzerInjectionPoint(15);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(16);
f1();
FuzzerInjectionPoint(17);