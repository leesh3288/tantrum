
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = [];
FuzzerInjectionPoint(2);
const v1 = /4(QZ(?:a?)?)/mdy;
FuzzerInjectionPoint(3);
function f2(a3, a4) {
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
function f6() {
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v7 = f6();
FuzzerInjectionPoint(8);
let v8 = -1377924912;
FuzzerInjectionPoint(9);
const v11 = new Set();
FuzzerInjectionPoint(10);
function f12() {
FuzzerInjectionPoint(11);
    v11.delete();
FuzzerInjectionPoint(12);
    let [v14] = v11;
FuzzerInjectionPoint(13);
    const v31 = {

        p(a16, a17) {
FuzzerInjectionPoint(15);
            const v18 = a16.constructor;
FuzzerInjectionPoint(16);
            try { v18(v7); } catch (e) {}
FuzzerInjectionPoint(17);
            v18();
FuzzerInjectionPoint(18);
            ([]).fill();
FuzzerInjectionPoint(19);
            const v25 = new BigUint64Array(3916);
FuzzerInjectionPoint(20);
            v25[185];
FuzzerInjectionPoint(21);
            a16.e = a16;
FuzzerInjectionPoint(22);
            const v27 = a17[0];
FuzzerInjectionPoint(23);
            v27 ^ v27;
FuzzerInjectionPoint(24);
            let v29 = new WebAssembly.Global({ value: "f64", mutable: false }, 4.319357700079234e+307);
FuzzerInjectionPoint(25);
            v29.valueOf();
FuzzerInjectionPoint(26);
            return v29;
FuzzerInjectionPoint(27);
        },

    };
FuzzerInjectionPoint(29);
    v31.p(f12, 1073741824).valueOf();
FuzzerInjectionPoint(30);
    ("p").sup();
FuzzerInjectionPoint(31);
    function f36() {
FuzzerInjectionPoint(32);
    }
FuzzerInjectionPoint(33);
    -f2;
FuzzerInjectionPoint(34);
    v0--;
FuzzerInjectionPoint(35);
    const v40 = Array();
FuzzerInjectionPoint(36);
    const v41 = { __proto__: v40 };
FuzzerInjectionPoint(37);
    const v42 = %WasmArray();
FuzzerInjectionPoint(38);
    13 ** v1;
FuzzerInjectionPoint(39);
    v1 >>> v1;
FuzzerInjectionPoint(40);
    ~v1;
FuzzerInjectionPoint(41);
    v41.slice();
FuzzerInjectionPoint(42);
    %OptimizeMaglevOnNextCall(f36);
FuzzerInjectionPoint(43);
    v8 = "p";
FuzzerInjectionPoint(44);
    new Uint8Array();
FuzzerInjectionPoint(45);
    new Uint32Array();
FuzzerInjectionPoint(46);
    new BigInt64Array();
FuzzerInjectionPoint(47);
    const v54 = v31["p"]("p", "p");
FuzzerInjectionPoint(48);
    v54.valueOf();
FuzzerInjectionPoint(49);
    const v56 = v54.valueOf();
FuzzerInjectionPoint(50);
    class C57 {

    }
FuzzerInjectionPoint(52);
    BigInt64Array.from(v56);
FuzzerInjectionPoint(53);
    const v60 = new BigInt64Array(128);
FuzzerInjectionPoint(54);
    v60[7];
FuzzerInjectionPoint(55);
    function f68(a69, a70, a71) {
FuzzerInjectionPoint(56);
        const v78 = {

            [a69](a73, a74) {
FuzzerInjectionPoint(58);
            },

            p(a76, a77) {
FuzzerInjectionPoint(60);
            },

            f: 0,

            [4]: a69,

            __proto__: BigInt64Array,

            d: 85,

            ...4,

            b: a70,

            10000: 85,

            10: 1172,

            [0]: 257,

            maxByteLength: 85,

            10000: BigInt64Array,

            maxByteLength: 4,

        };
FuzzerInjectionPoint(74);
        try { v78.includes(); } catch (e) {}
FuzzerInjectionPoint(75);
    }
FuzzerInjectionPoint(76);
    f68();
FuzzerInjectionPoint(77);
    f68(BigUint64Array);
FuzzerInjectionPoint(78);
    f68();
FuzzerInjectionPoint(79);
    v54.valueOf();
FuzzerInjectionPoint(80);
    const v88 = {

        get f() {
FuzzerInjectionPoint(82);
        },

        toString(a86, a87) {
FuzzerInjectionPoint(84);
        },

        264253359: "p",

    };
FuzzerInjectionPoint(87);
    return f12;
FuzzerInjectionPoint(88);
}
FuzzerInjectionPoint(89);
const v89 = f12();
FuzzerInjectionPoint(90);
f12();
FuzzerInjectionPoint(91);
const v91 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(92);
function f92(a93, a94) {
FuzzerInjectionPoint(93);
    %OptimizeFunctionOnNextCall(v89);
FuzzerInjectionPoint(94);
    v89();
FuzzerInjectionPoint(95);
}
FuzzerInjectionPoint(96);
v91.toString = f92;
FuzzerInjectionPoint(97);
class C96 extends Set {

    [v91] = v91;

}