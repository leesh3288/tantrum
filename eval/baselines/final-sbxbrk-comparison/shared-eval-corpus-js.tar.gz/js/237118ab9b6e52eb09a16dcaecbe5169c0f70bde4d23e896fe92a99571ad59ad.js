
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    function f3() {
FuzzerInjectionPoint(3);
        return 4n > 4n;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    f3();
FuzzerInjectionPoint(6);
    %OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(7);
    return 4n;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v6 = f0();
FuzzerInjectionPoint(10);
f0();
FuzzerInjectionPoint(11);
f0(v6);
FuzzerInjectionPoint(12);