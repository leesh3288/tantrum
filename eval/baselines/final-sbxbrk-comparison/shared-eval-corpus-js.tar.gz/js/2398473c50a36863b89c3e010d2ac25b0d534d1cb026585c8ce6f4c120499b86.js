
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
function f1(a2, a3) {
FuzzerInjectionPoint(3);
    const v4 = `
FuzzerInjectionPoint(4);
        /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(5);
    `;
FuzzerInjectionPoint(6);
    return v4;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
v0.toString = f1;
FuzzerInjectionPoint(9);
constructor(constructor).encodeURI(v0);
FuzzerInjectionPoint(10);