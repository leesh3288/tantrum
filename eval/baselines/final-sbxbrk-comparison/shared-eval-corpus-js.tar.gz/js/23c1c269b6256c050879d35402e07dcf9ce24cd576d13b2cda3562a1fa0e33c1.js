
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [65536,-4,742649659,2147483649,63825,-15,52072];
FuzzerInjectionPoint(2);
const v3 = new Int8Array(2964);
FuzzerInjectionPoint(3);
v3.toSorted(v3.set(v0)).sort();
FuzzerInjectionPoint(4);