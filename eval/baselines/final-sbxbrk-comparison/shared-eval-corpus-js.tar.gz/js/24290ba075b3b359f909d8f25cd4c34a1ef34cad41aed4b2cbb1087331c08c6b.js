
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {

    return a2;

}

function f3(a4, a5) {

    for (const v7 in "toTimeString") {

        class C8 {

            static {

                try {

                    const v10 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

                        0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

                        0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00,

                        0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A,

                        0x01, 0x00,

                    ])));

                    f0(v10, v7);

                    eval();

                } catch(e14) {

                }

            }

        }

    }

    return "toTimeString";

}

const v18 = new Worker(f3, { type: "function" });

v18.getMessage();