
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    typeof "toString" === "bigint";
FuzzerInjectionPoint(3);
    return "toString";
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f1();
FuzzerInjectionPoint(6);
f1();
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(8);
f1();
FuzzerInjectionPoint(9);