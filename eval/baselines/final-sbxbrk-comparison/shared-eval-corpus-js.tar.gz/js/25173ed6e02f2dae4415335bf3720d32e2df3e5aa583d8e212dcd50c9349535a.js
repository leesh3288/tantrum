
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Map();
FuzzerInjectionPoint(2);
function f2(a3, a4) {
FuzzerInjectionPoint(3);
    a4.prototype;
FuzzerInjectionPoint(4);
    const v8 = {

        129: a3,

        m(a7) {
FuzzerInjectionPoint(7);
        },

        d: v1,

        [v1]: Map,

    };
FuzzerInjectionPoint(11);
    v8[129] = v8;
FuzzerInjectionPoint(12);
    return v8;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
const v9 = f2(f2, Map);
FuzzerInjectionPoint(15);
const v11 = f2(f2(v9, v9), f2);
FuzzerInjectionPoint(16);
const v12 = [10000,2147483648,9007199254740990,13,6844,905804865,-22996,1073741823];
FuzzerInjectionPoint(17);
const v13 = [-890820086,268435439,-2147483647];
FuzzerInjectionPoint(18);
const v14 = [-1492932138,536870887,0,536870888,2147483647,1297193314];
FuzzerInjectionPoint(19);
function f15(a16, a17, a18, a19) {
FuzzerInjectionPoint(20);
    try { a16.g(v9, v9); } catch (e) {}
FuzzerInjectionPoint(21);
    try { a19.every(f15); } catch (e) {}
FuzzerInjectionPoint(22);
    try {
FuzzerInjectionPoint(23);
        const v22 = v12.keys();
FuzzerInjectionPoint(24);
        try { v22.reduce(f2); } catch (e) {}
FuzzerInjectionPoint(25);
    } catch(e24) {
FuzzerInjectionPoint(26);
    }
FuzzerInjectionPoint(27);
    a17 = a19;
FuzzerInjectionPoint(28);
    const v33 = {

        255: a16,

        [v11](a26, a27, a28) {
FuzzerInjectionPoint(31);
            Math.exp(536870887);
FuzzerInjectionPoint(32);
            a16++;
FuzzerInjectionPoint(33);
            return v11;
FuzzerInjectionPoint(34);
        },

    };
FuzzerInjectionPoint(36);
    return v33;
FuzzerInjectionPoint(37);
}
FuzzerInjectionPoint(38);
f15(v9, v13, v9, v14);

/Aa|bc/mdi.constructor;