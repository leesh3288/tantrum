
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Uint8ClampedArray();

function f5() {

    const v7 = Symbol.dispose;

    const v9 = {

        [v7]() {

        },

    };

    using v10 = v9;

    const v12 = { a: -65536 };

    function f14() {

        const v16 = new Int16Array(7);

        v16[6];

        new Uint32Array();

        v16[6];

    }

    f14();

    %PrepareFunctionForOptimization(f14);

    %OptimizeMaglevOnNextCall(f14);

    f14();

    const v23 = v12.a;

    v23 === v23;

    v23 | v23;

}

f5();

f5();