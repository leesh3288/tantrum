
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-623021365,1,1024,1698693922,-1,-9];
FuzzerInjectionPoint(2);
const v6 = new SharedArrayBuffer(2018, { maxByteLength: 2018 });
FuzzerInjectionPoint(3);
const v7 = %WasmStruct();
FuzzerInjectionPoint(4);
v1.__proto__ = v7;
FuzzerInjectionPoint(5);
const v8 = new Int8Array(v6);
FuzzerInjectionPoint(6);
v8.set(v1);
FuzzerInjectionPoint(7);