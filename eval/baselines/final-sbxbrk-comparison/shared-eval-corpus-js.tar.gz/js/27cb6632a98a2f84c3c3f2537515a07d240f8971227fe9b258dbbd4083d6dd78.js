
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);
const v13 = new BigUint64Array();
FuzzerInjectionPoint(4);
class C16 {

    static #m(a18, a19, a20) {
FuzzerInjectionPoint(6);
        try {
FuzzerInjectionPoint(7);
            Int8Array.#m();
FuzzerInjectionPoint(8);
        } catch(e22) {
FuzzerInjectionPoint(9);
        }
FuzzerInjectionPoint(10);
    }

    valueOf(a24, a25, a26) {
FuzzerInjectionPoint(12);
        BigUint64Array === "boolean";
FuzzerInjectionPoint(13);
    }

    constructor(a30, a31) {
FuzzerInjectionPoint(15);
        v13.__proto__ = C16;
FuzzerInjectionPoint(16);
        try {
FuzzerInjectionPoint(17);
            function f32(a33, a34) {
FuzzerInjectionPoint(18);
            }
FuzzerInjectionPoint(19);
            function f35(a36) {
FuzzerInjectionPoint(20);
                const v37 = {};
FuzzerInjectionPoint(21);
            }
FuzzerInjectionPoint(22);
            try {
FuzzerInjectionPoint(23);
            } finally {
FuzzerInjectionPoint(24);
            }
FuzzerInjectionPoint(25);
        } catch(e38) {
FuzzerInjectionPoint(26);
        }
FuzzerInjectionPoint(27);
    }

}
FuzzerInjectionPoint(29);
const v39 = new C16();
FuzzerInjectionPoint(30);
const v40 = {};
FuzzerInjectionPoint(31);
function f42(a43) {
FuzzerInjectionPoint(32);
    const v54 = {

        f: a43,

        [-4294967295](a45) {
FuzzerInjectionPoint(35);
            if (51 > a45) {
FuzzerInjectionPoint(36);
                try {
FuzzerInjectionPoint(37);
                } catch(e47) {
FuzzerInjectionPoint(38);
                }
FuzzerInjectionPoint(39);
            } else {
FuzzerInjectionPoint(40);
            }
FuzzerInjectionPoint(41);
        },

        6: f0,

        e: v39,

        p(a50) {
FuzzerInjectionPoint(45);
            ("m" ^ "m") ^ -2.220446049250313e-16;
FuzzerInjectionPoint(46);
        },

        g: "m",

        127: BigUint64Array,

        10: 1024n,

    };
FuzzerInjectionPoint(51);
    v54[65536] = v54;
FuzzerInjectionPoint(52);
    function f56(a57, a58) {
FuzzerInjectionPoint(53);
        const v63 = {

            c: a57,

            p(a60, a61) {
FuzzerInjectionPoint(56);
                this[a57] = a57;
FuzzerInjectionPoint(57);
                super[a60];
FuzzerInjectionPoint(58);
            },

            e: -12,

        };
FuzzerInjectionPoint(61);
        return v63;
FuzzerInjectionPoint(62);
    }
FuzzerInjectionPoint(63);
    const v64 = f56(5, 5);
FuzzerInjectionPoint(64);
    class C65 {

        static #g = v64;

        static set d(a67) {
FuzzerInjectionPoint(67);
            const v68 = `
FuzzerInjectionPoint(68);
            `;
FuzzerInjectionPoint(69);
            eval(v68);
FuzzerInjectionPoint(70);
        }

        static set c(a72) {
FuzzerInjectionPoint(72);
        }

    }
FuzzerInjectionPoint(74);
    new C65();
FuzzerInjectionPoint(75);
    return v54;
FuzzerInjectionPoint(76);
}
FuzzerInjectionPoint(77);
f42(-4294967295);
FuzzerInjectionPoint(78);
try {
FuzzerInjectionPoint(79);
    f42();
FuzzerInjectionPoint(80);
} catch(e76) {
FuzzerInjectionPoint(81);
}
FuzzerInjectionPoint(82);
function F77(a79, a80, a81, a82) {
FuzzerInjectionPoint(83);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(84);
}
FuzzerInjectionPoint(85);
%OptimizeFunctionOnNextCall(f42);
FuzzerInjectionPoint(86);
f42();
FuzzerInjectionPoint(87);
const v84 = {};