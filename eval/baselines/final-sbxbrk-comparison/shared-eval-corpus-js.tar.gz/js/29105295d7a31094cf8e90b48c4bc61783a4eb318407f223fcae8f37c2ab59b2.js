
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Set();
FuzzerInjectionPoint(2);
new Uint16Array(1024);
FuzzerInjectionPoint(3);
new Int16Array(4);
FuzzerInjectionPoint(4);
new Float32Array(5);
FuzzerInjectionPoint(5);
new Int32Array(1024);
FuzzerInjectionPoint(6);
const v19 = BigInt64Array?.valueOf;
FuzzerInjectionPoint(7);
try { new v19(); } catch (e) {}
FuzzerInjectionPoint(8);
new BigInt64Array(129);
FuzzerInjectionPoint(9);
new Uint8Array(512);
FuzzerInjectionPoint(10);
Uint16Array.length;
FuzzerInjectionPoint(11);
new Uint16Array(3654);
FuzzerInjectionPoint(12);
6 >> Int16Array;
FuzzerInjectionPoint(13);
const v32 = new Float32Array(6);
FuzzerInjectionPoint(14);
try { v32.map(v32); } catch (e) {}
FuzzerInjectionPoint(15);
new Int16Array(3847);
FuzzerInjectionPoint(16);
const v37 = [4,129,4294967295,127,536870888,65537,-34973,-2147483648,-58606,-2147483647];
FuzzerInjectionPoint(17);
Uint16Array[9] = v37;
FuzzerInjectionPoint(18);
const v38 = [-16787,-1098236850];
FuzzerInjectionPoint(19);
const v39 = [1073741824,36407,-29042,-10,-39735];
FuzzerInjectionPoint(20);
function F40(a42, a43) {
FuzzerInjectionPoint(21);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(22);
    try { a42.toString(); } catch (e) {}
FuzzerInjectionPoint(23);
    try { a43.unshift(v38); } catch (e) {}
FuzzerInjectionPoint(24);
    this.f = a42;
FuzzerInjectionPoint(25);
    this.g = a42;
FuzzerInjectionPoint(26);
}
FuzzerInjectionPoint(27);
new F40(v38, v37);
FuzzerInjectionPoint(28);
new F40(v37, v37);
FuzzerInjectionPoint(29);
const v48 = new F40(v37, v37);
FuzzerInjectionPoint(30);
1e-15 + 1e-15;
FuzzerInjectionPoint(31);
0.7445986454425726 >> 0.7445986454425726;
FuzzerInjectionPoint(32);
([v48,v38,[v37,1e-15,0.7445986454425726,-207.33561035990272,-207.33561035990272],-207.33561035990272,v39])[4];
FuzzerInjectionPoint(33);
[-207.33561035990272,v38];
FuzzerInjectionPoint(34);
const v61 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0E,

    0x02, 0x60, 0x06, 0x7D, 0x7E, 0x7E, 0x7E, 0x7D, 0x7E, 0x00,

    0x60, 0x01, 0x7C, 0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00,

    0x05, 0x03, 0x01, 0x04, 0x07, 0x0D, 0x05, 0x02, 0x00, 0x00,

    0x00, 0x01, 0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01,

    0x00, 0x0A, 0x01, 0x00,

])));
FuzzerInjectionPoint(42);
try { v61.constructor(6); } catch (e) {}
FuzzerInjectionPoint(43);
v61.exports;
FuzzerInjectionPoint(44);
gc();