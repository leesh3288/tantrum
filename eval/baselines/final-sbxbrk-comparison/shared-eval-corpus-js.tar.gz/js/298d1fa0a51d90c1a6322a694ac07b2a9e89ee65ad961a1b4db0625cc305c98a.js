
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v6 = {

        ["h"]: "5",

        get a() {
FuzzerInjectionPoint(5);
            return -1000.0;
FuzzerInjectionPoint(6);
        },

        c: "h",

        __proto__: "h",

        7: "5",

        h: "h",

    };
FuzzerInjectionPoint(12);
    return -11;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
f0();
FuzzerInjectionPoint(15);
class C8 {

    536870888;

    constructor(a10, a11) {
FuzzerInjectionPoint(18);
        for (let v12 = 0; v12 < 100; v12++) {
FuzzerInjectionPoint(19);
            f0();
FuzzerInjectionPoint(20);
        }
FuzzerInjectionPoint(21);
    }

}
FuzzerInjectionPoint(23);
new C8();
FuzzerInjectionPoint(24);
const v15 = [0.3414395155839758,4.0,-1.5499563803483958e+307,-372.1773299268698,0.9286533336298091,-804.0865926715935,0.23542936109242774,-280.7753559071027,805.1341271798628,0.06888664429150881];
FuzzerInjectionPoint(25);
class C16 {

    static #h = v15;

    #a;

    static #f;

    static #e;

    #c;

}