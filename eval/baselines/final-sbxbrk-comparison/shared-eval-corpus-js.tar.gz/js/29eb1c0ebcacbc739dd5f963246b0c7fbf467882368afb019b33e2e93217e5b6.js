
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

    constructor(a2, a3) {
FuzzerInjectionPoint(3);
        try {
FuzzerInjectionPoint(4);
            super.asIntN();
FuzzerInjectionPoint(5);
        } catch(e5) {
FuzzerInjectionPoint(6);
            e5.name = e5;
FuzzerInjectionPoint(7);
            e5.stack;
FuzzerInjectionPoint(8);
        }
FuzzerInjectionPoint(9);
    }

}
FuzzerInjectionPoint(11);
new C0(C0, C0);