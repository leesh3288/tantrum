
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v1 = `
FuzzerInjectionPoint(3);
        /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(4);
    `;
FuzzerInjectionPoint(5);
    return v1[12];
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f0();
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(10);
f0();
FuzzerInjectionPoint(11);