
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new WeakRef(Object);
FuzzerInjectionPoint(2);
v2.constructor = Object;
FuzzerInjectionPoint(3);
gc([0.29231677705735926,-648.1197945302624,1.7976931348623157e+308,-4.0,-2.2250738585072014e-308,-2.220446049250313e-16]);
FuzzerInjectionPoint(4);
gc();
FuzzerInjectionPoint(5);