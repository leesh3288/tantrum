
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v3 = ~-65536;
FuzzerInjectionPoint(3);
    const v9 = {

        get d() {
FuzzerInjectionPoint(5);
            const t0 = "symbol";
FuzzerInjectionPoint(6);
            t0["symbol"] = "symbol" & this;
FuzzerInjectionPoint(7);
            const v6 = [-65536];
FuzzerInjectionPoint(8);
            [v6,[-65536,this,v6],v3];
FuzzerInjectionPoint(9);
            return v6;
FuzzerInjectionPoint(10);
        },

        1: "symbol",

        f: -65536,

        b: v3,

    };
FuzzerInjectionPoint(15);
    return v9;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
const v10 = f0();
FuzzerInjectionPoint(18);
f0();
FuzzerInjectionPoint(19);
const v12 = f0();
FuzzerInjectionPoint(20);
if (f0) {
FuzzerInjectionPoint(21);
    try { v10["toReversed"](f0); } catch (e) {}
FuzzerInjectionPoint(22);
} else {
FuzzerInjectionPoint(23);
    v10[2] >>>= f0;
FuzzerInjectionPoint(24);
}
FuzzerInjectionPoint(25);
const v17 = +22162;
FuzzerInjectionPoint(26);
([262640.5159308666,-2.0,8.073345327681029,-1000000000.0,-8.247373594425177,257184.63873208663,3.603210271916197,941.2525436913609,0.6125187580603855,-1.0]).length;
FuzzerInjectionPoint(27);
const v20 = [0.9616908355467151,-284056.82506999304,4.0,0.05157946318667683];
FuzzerInjectionPoint(28);
let v21;
FuzzerInjectionPoint(29);
try { v21 = v20.pop(); } catch (e) {}
FuzzerInjectionPoint(30);
const v22 = [1e-15,1e-15,-1.266741818012486e+308,-1000.0,0.8310300863458054];
FuzzerInjectionPoint(31);
const v23 = `
FuzzerInjectionPoint(32);
    function F24(a26, a27, a28, a29) {
FuzzerInjectionPoint(33);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(34);
        a29.length;
FuzzerInjectionPoint(35);
    }
FuzzerInjectionPoint(36);
    let v31;
FuzzerInjectionPoint(37);
    try { v31 = F24(v22, f0, v22, f0); } catch (e) {}
FuzzerInjectionPoint(38);
    function f32() {
FuzzerInjectionPoint(39);
        const v33 = new F24(v23, F24, v23, f32);
FuzzerInjectionPoint(40);
        const v34 = v12.constructor;
FuzzerInjectionPoint(41);
        try { v31.freeze(v31, v34, F24); } catch (e) {}
FuzzerInjectionPoint(42);
        v33[22992] = F24;
FuzzerInjectionPoint(43);
        for (let v36 = 0; v36 < 10; v36++) {
FuzzerInjectionPoint(44);
            "p" + v36;
FuzzerInjectionPoint(45);
            v10[v21] = v36;
FuzzerInjectionPoint(46);
        }
FuzzerInjectionPoint(47);
        try { new v34(v33, v33, f32, f32); } catch (e) {}
FuzzerInjectionPoint(48);
        return f32;
FuzzerInjectionPoint(49);
    }
FuzzerInjectionPoint(50);
    const v40 = f32();
FuzzerInjectionPoint(51);
    const v41 = f32();
FuzzerInjectionPoint(52);
    v41.d;
FuzzerInjectionPoint(53);
    const v43 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(54);
    function f44(a45, a46) {
FuzzerInjectionPoint(55);
        %OptimizeFunctionOnNextCall(v40);
FuzzerInjectionPoint(56);
    }
FuzzerInjectionPoint(57);
    v43.toString = f44;
FuzzerInjectionPoint(58);
    class C47 extends v41 {
FuzzerInjectionPoint(59);
    }
FuzzerInjectionPoint(60);
`;
FuzzerInjectionPoint(61);
v17 ^ v10;