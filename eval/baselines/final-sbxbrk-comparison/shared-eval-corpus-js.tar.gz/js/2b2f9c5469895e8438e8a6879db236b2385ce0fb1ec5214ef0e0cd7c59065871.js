
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = d8.test;
FuzzerInjectionPoint(2);
const v2 = v1.verifySourcePositions;
FuzzerInjectionPoint(3);
try { v2(v2, d8, v1, v1); } catch (e) {}
FuzzerInjectionPoint(4);