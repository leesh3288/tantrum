
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(2);
for (let v1 = 0; v1 < 5; v1++) {
FuzzerInjectionPoint(3);
    let v2 = v0[v1];
FuzzerInjectionPoint(4);
    v2--;
FuzzerInjectionPoint(5);
    const v4 = v2 + v2;
FuzzerInjectionPoint(6);
    Number.parseInt(v4, v4);
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);