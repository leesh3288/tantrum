
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
d = 512;
FuzzerInjectionPoint(2);
function f2(a3) {
FuzzerInjectionPoint(3);
    const v4 = {};
FuzzerInjectionPoint(4);
    v4.b = d;
FuzzerInjectionPoint(5);
    return v4;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v6 = f2(f2(f2));
FuzzerInjectionPoint(8);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(9);
f2(v6);
FuzzerInjectionPoint(10);