
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = %WasmArray();
FuzzerInjectionPoint(2);
Reflect.getOwnPropertyDescriptor(v0);
FuzzerInjectionPoint(3);