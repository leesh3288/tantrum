
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-128,1,-4294967296];
FuzzerInjectionPoint(2);
/(?=a){9,10}aH0a(?!bbb|bb)cSe90/gi;
FuzzerInjectionPoint(3);
/7Nar[a-zA-Z0-9]2[xyz]/ui;
FuzzerInjectionPoint(4);
const v8 = [-26408];
FuzzerInjectionPoint(5);
v8[0] = v8;
FuzzerInjectionPoint(6);
v8.length;
FuzzerInjectionPoint(7);
function f10() {
FuzzerInjectionPoint(8);
    let v11 = 151;
FuzzerInjectionPoint(9);
    v11++;
FuzzerInjectionPoint(10);
    const v13 = BigUint64Array.name;
FuzzerInjectionPoint(11);
    v13[1];
FuzzerInjectionPoint(12);
    v13.codePointAt();
FuzzerInjectionPoint(13);
    let v16 = -4294967295;
FuzzerInjectionPoint(14);
    let v17 = v0 % v0;
FuzzerInjectionPoint(15);
    v17++;
FuzzerInjectionPoint(16);
    -v16;
FuzzerInjectionPoint(17);
    let v20 = v16++;
FuzzerInjectionPoint(18);
    v20++;
FuzzerInjectionPoint(19);
    return Uint32Array;
FuzzerInjectionPoint(20);
}
FuzzerInjectionPoint(21);
f10();
FuzzerInjectionPoint(22);
f10();
FuzzerInjectionPoint(23);
%OptimizeMaglevOnNextCall(f10);
FuzzerInjectionPoint(24);
f10();
FuzzerInjectionPoint(25);