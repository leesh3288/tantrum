
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

}

function f1(a2, a3, a4) {

    function f5() {

        const v6 = f0();

        Uint8ClampedArray();

        function F9(a11, a12, a13, a14) {

            if (!new.target) { throw 'must be called with new'; }

        }

        for (const v16 in "2") {

            try {

                let v19;

                try { v19 = FinalizationRegistry(); } catch (e) {}

                Uint8Array(v19, SharedArrayBuffer(v19, SharedArrayBuffer), v19);

                Int32Array("MIN_VALUE", a4);

            } catch(e26) {

            } finally {

                try {

                const t0 = "MIN_VALUE";

                t0();

                } catch (e) {}

            }

            constructor();

            ([v6])?.map;

        }

    }

    ("p").search(f5);

}

const v37 = new Worker(f1, { type: "function" });

v37.getMessage();