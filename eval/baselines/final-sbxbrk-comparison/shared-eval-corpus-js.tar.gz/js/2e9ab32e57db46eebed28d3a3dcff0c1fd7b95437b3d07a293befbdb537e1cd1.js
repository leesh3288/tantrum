
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {

    a4.name;

    function f6(a7) {

        const v9 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

            0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x04,

            0x01, 0x60, 0x00, 0x00, 0x03, 0x02, 0x01, 0x00, 0x04, 0x01,

            0x00, 0x05, 0x01, 0x00, 0x06, 0x01, 0x00, 0x07, 0x06, 0x01,

            0x02, 0x77, 0x30, 0x00, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x04,

            0x01, 0x02, 0x00, 0x0B,

        ])));

        const v10 = v9.exports;

        v10.w0(v10);

        function f12() {

            const v13 = [4,-61572,9,1957989437,1073741824,128,-2];

            for (let v14 = 0; v14 < 5; v14++) {

                v13[1587200051];

                class C17 extends WeakMap {

                }

            }

            return f1;

        }

        const v18 = f12();

        try { v18.apply(); } catch (e) {}

        for (let v20 = 0; v20 < 5; v20++) {

        }

        return v18;

    }

    %OptimizeFunctionOnNextCall(f6);

    return f6(a4);

}

const v22 = f1(f1, 1587200051, f1);

f1(v22, f1, v22);