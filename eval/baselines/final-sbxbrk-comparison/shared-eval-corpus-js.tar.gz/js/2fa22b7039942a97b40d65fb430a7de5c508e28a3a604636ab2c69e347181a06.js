
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-13,3,-6,-1073741824,377195315,-2,268435439,10];
FuzzerInjectionPoint(2);
const v2 = v1.push;
FuzzerInjectionPoint(3);
try { v2(); } catch (e) {}
FuzzerInjectionPoint(4);
new Uint16Array(v1);
FuzzerInjectionPoint(5);