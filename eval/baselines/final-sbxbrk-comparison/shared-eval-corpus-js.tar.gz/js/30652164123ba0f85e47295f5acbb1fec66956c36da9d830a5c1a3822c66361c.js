
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
class C1 extends C0 {

    static {
FuzzerInjectionPoint(5);
        const v3 = {};
FuzzerInjectionPoint(6);
        try { v3.repeat(C0, v3); } catch (e) {}
FuzzerInjectionPoint(7);
    }

    static 0;

}