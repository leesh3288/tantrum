
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    function f4(a5, a6, a7, a8) {
FuzzerInjectionPoint(3);
        return a2;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    f4.apply(206, arguments);
FuzzerInjectionPoint(6);
    return f1;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f1();
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(11);
f1();
FuzzerInjectionPoint(12);