
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = [25981,4294967295,6,-7711,-2147483649,4];
FuzzerInjectionPoint(2);
const v3 = [2,13,4,-6431,16,-1053085365,64,9007199254740991];
FuzzerInjectionPoint(3);
let v4 = [-829559078,10,7,1073741824,3,10038,3,-1333253819];
FuzzerInjectionPoint(4);
const v5 = [16,-15,268435441,-10,0];
FuzzerInjectionPoint(5);
function F6(a8, a9) {
FuzzerInjectionPoint(6);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(7);
    this.c = a9;
FuzzerInjectionPoint(8);
    this.e = v4;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
new F6(v3, 4);
FuzzerInjectionPoint(11);
let v11 = new F6(v2, -4294967297);
FuzzerInjectionPoint(12);
({"length":v4,...v11} = v5);
FuzzerInjectionPoint(13);
class C12 extends F6 {

    7;

}
FuzzerInjectionPoint(16);
new C12();
FuzzerInjectionPoint(17);
new C12();
FuzzerInjectionPoint(18);
new C12();