
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {

    if (!new.target) { throw 'must be called with new'; }

}

const v3 = this.toLocaleString();

const v5 = { [v3]: F0 };

this.createExternalizableTwoByteString(v3);