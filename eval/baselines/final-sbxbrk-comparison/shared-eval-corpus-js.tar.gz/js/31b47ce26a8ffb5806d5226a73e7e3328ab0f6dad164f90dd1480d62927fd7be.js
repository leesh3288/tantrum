
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v4 = {

        d: -1000.0,

        set c(a3) {
FuzzerInjectionPoint(5);
        },

    };
FuzzerInjectionPoint(7);
    return v4;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
class C5 extends f0 {

    d = f0;

}
FuzzerInjectionPoint(12);
new C5();
FuzzerInjectionPoint(13);
new C5();
FuzzerInjectionPoint(14);
const v11 = new Int8Array(156);
FuzzerInjectionPoint(15);
const v12 = v11[32];
FuzzerInjectionPoint(16);
try { v12.toString(Uint32Array); } catch (e) {}