
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    return {};
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v2 = f0();
FuzzerInjectionPoint(5);
const v3 = f0();
FuzzerInjectionPoint(6);
const v4 = [27930,536870912];
FuzzerInjectionPoint(7);
const v5 = [427356822,-9223372036854775807,-61734,1073741824,-32533,-1,9853,58262,16,-551780477];
FuzzerInjectionPoint(8);
function f6(a7, a8) {
FuzzerInjectionPoint(9);
    const v15 = {

        h: a7,

        c: a7,

        valueOf(a10, a11) {
FuzzerInjectionPoint(13);
            return a8;
FuzzerInjectionPoint(14);
        },

        [f6]: v3,

        g: f0,

        e: v5,

        d: f0,

        [a8](a13, a14) {
FuzzerInjectionPoint(20);
        },

        a: a8,

    };
FuzzerInjectionPoint(23);
    v15.b = v15;
FuzzerInjectionPoint(24);
    return v15;
FuzzerInjectionPoint(25);
}
FuzzerInjectionPoint(26);
const v16 = f6(v4, v3);
FuzzerInjectionPoint(27);
delete v16.d;
FuzzerInjectionPoint(28);
delete v16[v2];