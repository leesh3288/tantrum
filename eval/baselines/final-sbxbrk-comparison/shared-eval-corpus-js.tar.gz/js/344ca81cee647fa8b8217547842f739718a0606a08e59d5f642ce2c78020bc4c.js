
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
this.Atomics.isLockFree(8);
FuzzerInjectionPoint(2);