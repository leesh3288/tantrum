
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    "name" >= "name";
FuzzerInjectionPoint(3);
    return "name";
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f0();
FuzzerInjectionPoint(6);
f0();
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);