
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = {};
FuzzerInjectionPoint(2);
const v1 = %WasmStruct();
FuzzerInjectionPoint(3);
const v2 = v0.constructor;
FuzzerInjectionPoint(4);
try { v2.preventExtensions(v1); } catch (e) {}
FuzzerInjectionPoint(5);