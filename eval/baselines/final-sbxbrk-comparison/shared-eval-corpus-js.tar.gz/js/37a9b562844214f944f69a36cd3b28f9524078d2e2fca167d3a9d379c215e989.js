
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 extends Float32Array {

    constructor(a3, a4) {
FuzzerInjectionPoint(3);
        super();
FuzzerInjectionPoint(4);
        const v7 = (4294967296).toString();
FuzzerInjectionPoint(5);
        const v10 = new ArrayBuffer(1909, { maxByteLength: v7 });
FuzzerInjectionPoint(6);
        v10.resize(4294967296);
FuzzerInjectionPoint(7);
        const v13 = new BigInt64Array(v10);
FuzzerInjectionPoint(8);
        v13.fill(v7);
FuzzerInjectionPoint(9);
    }

}
FuzzerInjectionPoint(11);
new C1(C1, Float32Array);