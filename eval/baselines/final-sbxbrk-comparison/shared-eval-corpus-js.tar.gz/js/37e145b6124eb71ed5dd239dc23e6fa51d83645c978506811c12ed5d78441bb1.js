
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = new Uint8Array(1024);
FuzzerInjectionPoint(2);
function F4(a6, a7, a8, a9) {
FuzzerInjectionPoint(3);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(4);
    function f10(a11, a12, a13) {
FuzzerInjectionPoint(5);
        let v14;
FuzzerInjectionPoint(6);
        try { v14 = a11(v3); } catch (e) {}
FuzzerInjectionPoint(7);
        const v16 = new Uint32Array(1024, 1024, v14);
FuzzerInjectionPoint(8);
        const v18 = new Int8Array(a11);
FuzzerInjectionPoint(9);
        const v20 = [];
FuzzerInjectionPoint(10);
        Reflect.apply(v16.sort, v18, v20);
FuzzerInjectionPoint(11);
        return f10;
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    f10(f10);
FuzzerInjectionPoint(14);
    v3[8] = a8;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
new F4(1024, 1024, -2140543103);
FuzzerInjectionPoint(17);
new F4();
FuzzerInjectionPoint(18);