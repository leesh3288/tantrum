
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Set();
FuzzerInjectionPoint(2);
const t1 = v1.entries();
FuzzerInjectionPoint(3);
t1[Symbol] = Symbol;
FuzzerInjectionPoint(4);