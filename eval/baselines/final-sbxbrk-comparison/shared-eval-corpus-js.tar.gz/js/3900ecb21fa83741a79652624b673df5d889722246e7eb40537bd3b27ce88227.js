
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [10,877273978,-15412,-3,127,-15147];
FuzzerInjectionPoint(2);
function f1(a2, a3) {
FuzzerInjectionPoint(3);
    const v5 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

        0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

        0x00, 0x03, 0x01, 0x00, 0x04, 0x04, 0x01, 0x70, 0x00, 0x0A,

        0x05, 0x01, 0x00, 0x06, 0x01, 0x00, 0x07, 0x07, 0x01, 0x03,

        0x77, 0x74, 0x30, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x01,

        0x00,

    ])));
FuzzerInjectionPoint(10);
    const v7 = v5.exports.wt0;
FuzzerInjectionPoint(11);
    const v8 = v7.type();
FuzzerInjectionPoint(12);
    v8.maximum = v8;
FuzzerInjectionPoint(13);
    const t17 = v7.constructor;
FuzzerInjectionPoint(14);
    const v10 = new t17(v8);
FuzzerInjectionPoint(15);
    return v10;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
v0[Symbol.toPrimitive] = f1;
FuzzerInjectionPoint(18);
const v15 = new BigUint64Array();
FuzzerInjectionPoint(19);
try { v15.with(Uint8Array, v0); } catch (e) {}