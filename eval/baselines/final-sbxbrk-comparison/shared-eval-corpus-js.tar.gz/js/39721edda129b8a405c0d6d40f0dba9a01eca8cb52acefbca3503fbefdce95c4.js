
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v6 = new ArrayBuffer(1024, { maxByteLength: 268435441 });
FuzzerInjectionPoint(2);
const v7 = new Uint8ClampedArray(v6);
FuzzerInjectionPoint(3);
v7.constructor = Uint8Array;
FuzzerInjectionPoint(4);
v7.slice();
FuzzerInjectionPoint(5);