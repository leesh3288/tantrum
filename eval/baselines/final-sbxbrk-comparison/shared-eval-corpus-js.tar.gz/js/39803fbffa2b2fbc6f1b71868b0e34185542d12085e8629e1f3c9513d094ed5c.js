
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f14(a15, a16, a17) {
FuzzerInjectionPoint(2);
    const v19 = [a16];
FuzzerInjectionPoint(3);
    v19 || v19;
FuzzerInjectionPoint(4);
    !v19;
FuzzerInjectionPoint(5);
    class C23 {

    }
FuzzerInjectionPoint(7);
    return a17;
FuzzerInjectionPoint(8);
}