
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    [9];

    constructor(a5, a6) {

        ~a6;

        try { new WeakMap(); } catch (e) {}

        const v10 = new WeakMap();

        try { v10.get(a6); } catch (e) {}

        let v12;

        try { v12 = a6(v10); } catch (e) {}

        v12 ?? v12;

    }

    static #c;

    static [910.406317046934] = 910.406317046934;

    b;

    static #o(a19) {

        function F20(a22) {

            if (!new.target) { throw 'must be called with new'; }

            this.b = a22;

            this.d = this;

            this.e = this;

        }

        const v23 = new F20(a19);

        const v24 = new F20(v23);

        const v25 = new F20(v24);

        return v25;

    }

}

const v26 = new C3(910.406317046934, 9);

v26[9];

const v28 = new C3(v26, 910.406317046934);

new C3(684.8810892315807, C3);

new Uint8Array(4);

const v35 = new Float64Array(188);

try { v35.filter(Float64Array); } catch (e) {}

const v39 = new Int16Array(10);

function f40() {

    function f42(a43) {

        a43 >>> a43;

        function F45(a47, a48) {

            if (!new.target) { throw 'must be called with new'; }

            a48 * a48;

            this.c = v28;

        }

        try { new F45(9, a43); } catch (e) {}

        new F45(v26, a43);

        new F45(v28, v28);

        const v53 = new F45(v26, v28);

        v53.b = v53;

        a43 >>> a43;

        return f42;

    }

    let v55 = f42(-4294967295);

    [v55] = v39;

    v55[f42] = -4294967295;

    const v62 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

        0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x09,

        0x02, 0x60, 0x01, 0x7E, 0x01, 0x6F, 0x60, 0x00, 0x00, 0x02,

        0x18, 0x01, 0x07, 0x69, 0x6D, 0x70, 0x6F, 0x72, 0x74, 0x73,

        0x0C, 0x69, 0x6D, 0x70, 0x6F, 0x72, 0x74, 0x5F, 0x30, 0x5F,

        0x76, 0x35, 0x38, 0x00, 0x00, 0x03, 0x02, 0x01, 0x01, 0x04,

        0x01, 0x00, 0x05, 0x01, 0x00, 0x06, 0x01, 0x00, 0x07, 0x06,

        0x01, 0x02, 0x77, 0x30, 0x00, 0x01, 0x09, 0x01, 0x00, 0x0A,

        0x16, 0x01, 0x14, 0x02, 0x01, 0x7E, 0x01, 0x6F, 0x42, 0x81,

        0x80, 0x80, 0x80, 0x04, 0x21, 0x00, 0x20, 0x00, 0x10, 0x00,

        0x21, 0x01, 0x0B,

    ])),

    { imports: {

        import_0_v58: Symbol,

    } });

    v62.exports.w0();

    const v65 = ("e")?.split;

    try { new v65("-551030177", -4294967295); } catch (e) {}

    return v55;

}

const v68 = f40();

v68 * v68;

f40();

%OptimizeMaglevOnNextCall(f40);

const v71 = f40();

v71 * v71;