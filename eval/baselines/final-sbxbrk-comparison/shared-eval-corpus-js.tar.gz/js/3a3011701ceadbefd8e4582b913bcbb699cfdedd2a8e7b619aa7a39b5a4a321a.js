
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    return Number.isInteger(a2);
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f5(a6, a7, a8) {
FuzzerInjectionPoint(5);
    const v9 = [-1000000000000.0,-367.81301734010196,-476.74454452527516,-2.6076772957175923e+306,1.7976931348623157e+308,0.11176331082589741,Infinity,1000000.0];
FuzzerInjectionPoint(6);
    v9[7] = v9;
FuzzerInjectionPoint(7);
    v9.reduceRight(f0);
FuzzerInjectionPoint(8);
    return v9;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v11 = f5(f5, f5, f5);
FuzzerInjectionPoint(11);
f5();
FuzzerInjectionPoint(12);
%OptimizeFunctionOnNextCall(f5);
FuzzerInjectionPoint(13);
f5(v11, f0, f0);
FuzzerInjectionPoint(14);