
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

    for (let v1 = 0; v1 < 625; v1++) {

        const v3 = this.setTimeout;

        v3(v3);

    }

    return f0;

}

const v7 = { type: "function" };

const v8 = new Worker(f0, v7);

v8.getMessage(v7, v8, Worker, f0, f0);