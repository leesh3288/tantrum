
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
const v4 = constructor(C0, C0).Intl;
FuzzerInjectionPoint(4);
const v5 = v4.NumberFormat;
FuzzerInjectionPoint(5);
const v6 = v5(v4, v5, undefined);
FuzzerInjectionPoint(6);
try { v6.formatRangeToParts(C0, undefined); } catch (e) {}