
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    return 1628;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
let v4 = 3953;
FuzzerInjectionPoint(5);
v4++;
FuzzerInjectionPoint(6);
function F7(a9, a10, a11, a12) {
FuzzerInjectionPoint(7);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(8);
    a9.valueOf = f1;
FuzzerInjectionPoint(9);
    a11++;
FuzzerInjectionPoint(10);
    a11++;
FuzzerInjectionPoint(11);
    try { new a9(4096, this, a11, a11); } catch (e) {}
FuzzerInjectionPoint(12);
    ("object").constructor.fromCharCode(1, 4294967296, F7, a12, a11).localeCompare();
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
new F7(F7, -2147483649, v4);
FuzzerInjectionPoint(15);