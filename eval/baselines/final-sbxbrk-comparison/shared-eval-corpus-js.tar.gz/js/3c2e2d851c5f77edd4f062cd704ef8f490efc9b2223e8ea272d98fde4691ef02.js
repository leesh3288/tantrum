
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = Array(761323137);
FuzzerInjectionPoint(2);
v3.push(Uint8Array);
FuzzerInjectionPoint(3);
v3.concat(Uint8Array);
FuzzerInjectionPoint(4);