
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(2);
    ++a4;
FuzzerInjectionPoint(3);
    return { f: a4 };
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v8 = f2(-3.411894868854257, -1);
FuzzerInjectionPoint(6);
f2();
FuzzerInjectionPoint(7);
const v10 = { ...v8 };
FuzzerInjectionPoint(8);