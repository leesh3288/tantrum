
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = 127;
FuzzerInjectionPoint(2);
let v1 = 268435456;
FuzzerInjectionPoint(3);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(4);
    const v6 = { h: v0, [a5]: v1 };
FuzzerInjectionPoint(5);
    v0 = v6;
FuzzerInjectionPoint(6);
    v1 = -1228128665;
FuzzerInjectionPoint(7);
    function f8() {
FuzzerInjectionPoint(8);
        return v6[268435440];
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
    return v0;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
const v10 = f2(v1, v0, v0);
FuzzerInjectionPoint(13);
f2();
FuzzerInjectionPoint(14);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(15);
f2(v10, v10, v0);
FuzzerInjectionPoint(16);