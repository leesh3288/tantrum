
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v5 = new BigInt64Array(10);
FuzzerInjectionPoint(2);
const t1 = -5624;
FuzzerInjectionPoint(3);
t1[3] = 10;
FuzzerInjectionPoint(4);
try {
FuzzerInjectionPoint(5);
const t0 = 10;
FuzzerInjectionPoint(6);
t0();
FuzzerInjectionPoint(7);
} catch (e) {}
FuzzerInjectionPoint(8);
const v7 = [65536,-5624,v5,v5,BigInt64Array];
FuzzerInjectionPoint(9);
const v8 = [v5];
FuzzerInjectionPoint(10);
[v7];
FuzzerInjectionPoint(11);
new Int32Array(16);
FuzzerInjectionPoint(12);
v8[225] = v7;
FuzzerInjectionPoint(13);
const v17 = %WasmStruct();
FuzzerInjectionPoint(14);
new Uint16Array(0);
FuzzerInjectionPoint(15);
function F23(a25, a26, a27) {
FuzzerInjectionPoint(16);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(17);
}
FuzzerInjectionPoint(18);
const v28 = [449.38450831539944,-1000000000.0,59.53626402819964,3.0,-1e-15,209053.91153648333];
FuzzerInjectionPoint(19);
function f29() {
FuzzerInjectionPoint(20);
    const v30 = {};
FuzzerInjectionPoint(21);
    try { F23.toUpperCase(); } catch (e) {}
FuzzerInjectionPoint(22);
    let v33 = 10;
FuzzerInjectionPoint(23);
    function f34(a35, a36, a37, a38) {
FuzzerInjectionPoint(24);
        return { ...a36, __proto__: a36 };
FuzzerInjectionPoint(25);
    }
FuzzerInjectionPoint(26);
    f34(BigInt64Array, v17, 0, 65536);
FuzzerInjectionPoint(27);
    f34(f34(27346, v28, 536870912, -1), v7, v33, v33);
FuzzerInjectionPoint(28);
    for (; v33--;) {
FuzzerInjectionPoint(29);
    }
FuzzerInjectionPoint(30);
    return undefined;
FuzzerInjectionPoint(31);
}
FuzzerInjectionPoint(32);
f29();
FuzzerInjectionPoint(33);
f29();
FuzzerInjectionPoint(34);
%OptimizeMaglevOnNextCall(f29);
FuzzerInjectionPoint(35);
f29();
FuzzerInjectionPoint(36);