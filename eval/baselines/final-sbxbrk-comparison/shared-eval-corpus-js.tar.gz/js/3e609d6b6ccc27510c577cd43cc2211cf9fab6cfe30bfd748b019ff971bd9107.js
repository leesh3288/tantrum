
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Set();
FuzzerInjectionPoint(2);
function f2() {
FuzzerInjectionPoint(3);
    v1.size;
FuzzerInjectionPoint(4);
    return f2;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
const v4 = f2();
FuzzerInjectionPoint(7);
f2();
FuzzerInjectionPoint(8);
const v6 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(9);
function f7(a8, a9) {
FuzzerInjectionPoint(10);
    %OptimizeFunctionOnNextCall(v4);
FuzzerInjectionPoint(11);
    v4();
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
v6.toString = f7;
FuzzerInjectionPoint(14);
class C11 extends Set {

    [v6] = v6;

}