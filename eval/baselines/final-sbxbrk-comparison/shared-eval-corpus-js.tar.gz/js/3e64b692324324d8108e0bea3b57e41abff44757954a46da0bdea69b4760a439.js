
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v2 = new ArrayBuffer();
FuzzerInjectionPoint(3);
    const v4 = new DataView(v2);
FuzzerInjectionPoint(4);
    try { v4.getFloat64(); } catch (e) {}
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
f0();
FuzzerInjectionPoint(7);
f0();
FuzzerInjectionPoint(8);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(9);
f0();
FuzzerInjectionPoint(10);