
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
function f1() {
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f2(a3) {
FuzzerInjectionPoint(5);
    return a3;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
Object.defineProperty(v0, 0, { get: f1, set: f2 });
FuzzerInjectionPoint(8);
JSON.stringify(v0);
FuzzerInjectionPoint(9);