
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    function f2(a3) {
FuzzerInjectionPoint(4);
        this.valueOf = a3;
FuzzerInjectionPoint(5);
        delete this.valueOf;
FuzzerInjectionPoint(6);
        return f2;
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    f2();
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
new F0();
FuzzerInjectionPoint(11);
for (const v8 in this) {
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);