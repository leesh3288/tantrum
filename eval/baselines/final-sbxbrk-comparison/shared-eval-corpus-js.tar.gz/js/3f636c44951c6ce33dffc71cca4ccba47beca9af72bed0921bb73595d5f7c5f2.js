
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

    function f1(a2, a3, a4) {

        function f5() {

            [NaN,0.7158229625877318,Infinity,-714130.8683171929,3.0,89.88312061607235,1000000000000.0,Infinity];

            function F7() {

                if (!new.target) { throw 'must be called with new'; }

            }

            /05[\xf0\x9f\x92\xa9-\xf4\x8f\xbf\xbf](?<!a)a\s+/ug;

            const v13 = {

                get g() {

                    3 || 3;

                    return a4;

                },

            };

        }

        ("p").search(f5);

        return f1;

    }

    const v19 = new Worker(f1, { type: "function" });

    v19.getMessage(v19, f1, f0, f0);

    return f0;

}

f0();