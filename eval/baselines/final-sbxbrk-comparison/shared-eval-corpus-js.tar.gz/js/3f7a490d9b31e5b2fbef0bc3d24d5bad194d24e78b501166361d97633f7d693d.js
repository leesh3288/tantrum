
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Set();
FuzzerInjectionPoint(2);
function f3() {
FuzzerInjectionPoint(3);
    try {
FuzzerInjectionPoint(4);
        v2.delete();
FuzzerInjectionPoint(5);
    } catch(e5) {
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    let [v6] = v2;
FuzzerInjectionPoint(8);
    const v17 = {

        f: v6,

        get a() {
FuzzerInjectionPoint(11);
            return v2;
FuzzerInjectionPoint(12);
        },

        p(a9, a10) {
FuzzerInjectionPoint(14);
            a9.name;
FuzzerInjectionPoint(15);
            a10++;
FuzzerInjectionPoint(16);
            a9.e = a9;
FuzzerInjectionPoint(17);
            const v13 = a10[0];
FuzzerInjectionPoint(18);
            const v14 = v13 ?? v13;
FuzzerInjectionPoint(19);
            v14 ?? v14;
FuzzerInjectionPoint(20);
            let v16 = new WebAssembly.Global({ value: "f64", mutable: false }, 4.319357700079234e+307);
FuzzerInjectionPoint(21);
            return v16;
FuzzerInjectionPoint(22);
        },

    };
FuzzerInjectionPoint(24);
    let v18;
FuzzerInjectionPoint(25);
    try { v18 = v17.p(f3, 1073741824); } catch (e) {}
FuzzerInjectionPoint(26);
    try { v18.valueOf(); } catch (e) {}
FuzzerInjectionPoint(27);
    const v21 = v17["p"]("p", "p");
FuzzerInjectionPoint(28);
    try { v21.valueOf(); } catch (e) {}
FuzzerInjectionPoint(29);
    let v23;
FuzzerInjectionPoint(30);
    try { v23 = v21.valueOf(); } catch (e) {}
FuzzerInjectionPoint(31);
    const v24 = v23 >>> v23;
FuzzerInjectionPoint(32);
    v24 | v24;
FuzzerInjectionPoint(33);
    v21.dotAll;
FuzzerInjectionPoint(34);
    const v28 = {

        get f() {
FuzzerInjectionPoint(36);
        },

    };
FuzzerInjectionPoint(38);
    class C29 {

    }
FuzzerInjectionPoint(40);
    try { new C29(); } catch (e) {}
FuzzerInjectionPoint(41);
    return f3;
FuzzerInjectionPoint(42);
}
FuzzerInjectionPoint(43);
const v31 = f3();
FuzzerInjectionPoint(44);
f3();
FuzzerInjectionPoint(45);
const v33 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(46);
function f34(a35, a36) {
FuzzerInjectionPoint(47);
    %OptimizeFunctionOnNextCall(v31);
FuzzerInjectionPoint(48);
    v31();
FuzzerInjectionPoint(49);
}
FuzzerInjectionPoint(50);
v33.toString = f34;
FuzzerInjectionPoint(51);
class C38 extends Set {

    [v33] = v33;

}