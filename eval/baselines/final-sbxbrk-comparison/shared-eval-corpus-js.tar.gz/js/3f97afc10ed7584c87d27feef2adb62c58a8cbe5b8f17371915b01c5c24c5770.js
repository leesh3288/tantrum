
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
235 >>> 235;
FuzzerInjectionPoint(2);
new BigUint64Array(235);
FuzzerInjectionPoint(3);
new Uint8Array(37);
FuzzerInjectionPoint(4);
2803 - 2803;
FuzzerInjectionPoint(5);
const v13 = new Float32Array(2803);
FuzzerInjectionPoint(6);
function f14() {
FuzzerInjectionPoint(7);
    return v13;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
-2147483649 >>> -2147483649;
FuzzerInjectionPoint(10);
function f19() {
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
let v20 = "g";
FuzzerInjectionPoint(13);
try { ("object").startsWith("undefined"); } catch (e) {}
FuzzerInjectionPoint(14);
4096 + 4096;
FuzzerInjectionPoint(15);
let v30 = -3115n | -3115n;
FuzzerInjectionPoint(16);
v30--;
FuzzerInjectionPoint(17);
function F32(a34, a35, a36, a37) {
FuzzerInjectionPoint(18);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(19);
    function F38(a40, a41) {
FuzzerInjectionPoint(20);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(21);
        a41.normalize();
FuzzerInjectionPoint(22);
    }
FuzzerInjectionPoint(23);
    Int16Array.prototype;
FuzzerInjectionPoint(24);
    const v45 = this?.constructor;
FuzzerInjectionPoint(25);
    try { new v45(a34, this, a34, this); } catch (e) {}
FuzzerInjectionPoint(26);
    const v47 = a36?.constructor;
FuzzerInjectionPoint(27);
    try { new v47(-3115n); } catch (e) {}
FuzzerInjectionPoint(28);
}
FuzzerInjectionPoint(29);
F32.g = F32;
FuzzerInjectionPoint(30);
const v49 = new Date();
FuzzerInjectionPoint(31);
const v50 = v49?.setFullYear;
FuzzerInjectionPoint(32);
try { new v50(v20, v49, 4096); } catch (e) {}
FuzzerInjectionPoint(33);
128 - 128;
FuzzerInjectionPoint(34);
let v58 = 0;
FuzzerInjectionPoint(35);
v58 << v58;
FuzzerInjectionPoint(36);
do {
FuzzerInjectionPoint(37);
    const v61 = 9007199254740990 === 9007199254740990;
FuzzerInjectionPoint(38);
    v61 || v61;
FuzzerInjectionPoint(39);
    const v65 = -1170953448 >>> -1170953448;
FuzzerInjectionPoint(40);
    v65 % v65;
FuzzerInjectionPoint(41);
    const v67 = v58++;
FuzzerInjectionPoint(42);
    const v68 = v67 >>> v67;
FuzzerInjectionPoint(43);
    v68 ^ v68;
FuzzerInjectionPoint(44);
} while (v58 < 4)
FuzzerInjectionPoint(45);
new Array(4096);
FuzzerInjectionPoint(46);
function f73() {
FuzzerInjectionPoint(47);
    const v74 = {};
FuzzerInjectionPoint(48);
    v74.e = v74;
FuzzerInjectionPoint(49);
    return v74;
FuzzerInjectionPoint(50);
}
FuzzerInjectionPoint(51);
const v75 = f73?.constructor;
FuzzerInjectionPoint(52);
let v76;
FuzzerInjectionPoint(53);
try { v76 = new v75(57516); } catch (e) {}
FuzzerInjectionPoint(54);
v76.g = v76;
FuzzerInjectionPoint(55);
let v77 = f73();
FuzzerInjectionPoint(56);
try { v77.propertyIsEnumerable(F32); } catch (e) {}
FuzzerInjectionPoint(57);
const v79 = [-865879.4747004735];
FuzzerInjectionPoint(58);
function f80() {
FuzzerInjectionPoint(59);
    const v82 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(60);
    v82.at();
FuzzerInjectionPoint(61);
    for (let v84 = 0; v84 < 5; v84++) {
FuzzerInjectionPoint(62);
        v84 - v84;
FuzzerInjectionPoint(63);
        const v86 = v82[v84];
FuzzerInjectionPoint(64);
        v86 / v86;
FuzzerInjectionPoint(65);
        v77--;
FuzzerInjectionPoint(66);
        [v86];
FuzzerInjectionPoint(67);
    }
FuzzerInjectionPoint(68);
    -4294967295 <= -4294967295;
FuzzerInjectionPoint(69);
    function f92(a93) {
FuzzerInjectionPoint(70);
        const v94 = a93 ?? a93;
FuzzerInjectionPoint(71);
        v94 ?? v94;
FuzzerInjectionPoint(72);
        const v111 = {

            a: -4294967295,

            a: -163530867,

            ...v79,

            __proto__: v82,

            set e(a97) {
FuzzerInjectionPoint(78);
            },

            h: Array,

            o(a99, a100, a101) {
FuzzerInjectionPoint(81);
                "-767161113" >> "-767161113";
FuzzerInjectionPoint(82);
            },

            get f() {
FuzzerInjectionPoint(84);
            },

            set b(a106) {
FuzzerInjectionPoint(86);
                super[a106] = this;
FuzzerInjectionPoint(87);
                const v110 = {

                    f: this,

                    [-4294967295](a109) {
FuzzerInjectionPoint(90);
                    },

                };
FuzzerInjectionPoint(92);
                v110.f = v110;
FuzzerInjectionPoint(93);
                v110[65536] = v110;
FuzzerInjectionPoint(94);
            },

        };
FuzzerInjectionPoint(96);
        v111[0] = v111;
FuzzerInjectionPoint(97);
        (4294967295 >> 4294967295).toExponential();
FuzzerInjectionPoint(98);
        v111[0] = v111;
FuzzerInjectionPoint(99);
    }
FuzzerInjectionPoint(100);
    f92();
FuzzerInjectionPoint(101);
    try { Symbol.keyFor(-163530867); } catch (e) {}
FuzzerInjectionPoint(102);
    let v118;
FuzzerInjectionPoint(103);
    try { v118 = new Symbol(); } catch (e) {}
FuzzerInjectionPoint(104);
    v118 ?? v118;
FuzzerInjectionPoint(105);
    v118 ?? v118;
FuzzerInjectionPoint(106);
    const v123 = new Uint8ClampedArray(1);
FuzzerInjectionPoint(107);
    const v124 = v123[0];
FuzzerInjectionPoint(108);
    v124 >= v124;
FuzzerInjectionPoint(109);
    v123[0] = v123;
FuzzerInjectionPoint(110);
}
FuzzerInjectionPoint(111);
f80();
FuzzerInjectionPoint(112);
const v127 = f80();
FuzzerInjectionPoint(113);
v127 ?? v127;
FuzzerInjectionPoint(114);
%OptimizeMaglevOnNextCall(f80);
FuzzerInjectionPoint(115);
f80();
FuzzerInjectionPoint(116);
v20 **= 503335716;
FuzzerInjectionPoint(117);
const v132 = new Int16Array(66);
FuzzerInjectionPoint(118);
const v133 = v132[39];
FuzzerInjectionPoint(119);
v133 !== v133;
FuzzerInjectionPoint(120);
const v135 = v132.indexOf();
FuzzerInjectionPoint(121);
const v136 = v135 !== v135;
FuzzerInjectionPoint(122);
v136 || v136;