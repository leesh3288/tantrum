
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    function f4(a5, a6) {
FuzzerInjectionPoint(3);
        const v8 = Math.constructor;
FuzzerInjectionPoint(4);
        constructor();
FuzzerInjectionPoint(5);
        const v11 = v8.is(a6, 1000000000.0);
FuzzerInjectionPoint(6);
        v8.entries(Int16Array).toSpliced(v11);
FuzzerInjectionPoint(7);
        eval();
FuzzerInjectionPoint(8);
        return 1000000000.0;
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
    f4(f4, 1000000000.0);
FuzzerInjectionPoint(11);
    return f0;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f0(f0());
FuzzerInjectionPoint(14);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(15);
f0(f0);
FuzzerInjectionPoint(16);