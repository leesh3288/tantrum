
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = this.Intl.Locale;
FuzzerInjectionPoint(2);
const v4 = new t0("object");
FuzzerInjectionPoint(3);
v4.firstDayOfWeek;
FuzzerInjectionPoint(4);