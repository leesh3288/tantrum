
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

    static {
FuzzerInjectionPoint(3);
        const v2 = ~this;
FuzzerInjectionPoint(4);
        const v3 = -Infinity;
FuzzerInjectionPoint(5);
        v2 && v3;
FuzzerInjectionPoint(6);
        v2 ** v3;
FuzzerInjectionPoint(7);
    }

}