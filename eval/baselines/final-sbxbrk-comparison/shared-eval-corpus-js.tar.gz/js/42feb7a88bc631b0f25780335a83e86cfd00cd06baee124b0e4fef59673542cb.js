
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v6 = [a1] >= WeakMap;
FuzzerInjectionPoint(3);
    let v7 = undefined;
FuzzerInjectionPoint(4);
    for (let [i12, i13] = (() => {
FuzzerInjectionPoint(5);
            new Uint8ClampedArray();
FuzzerInjectionPoint(6);
            return [0, 10];
FuzzerInjectionPoint(7);
        })();

        i12 < i13;

        i12++) {
FuzzerInjectionPoint(10);
        v7 &= v6;
FuzzerInjectionPoint(11);
    }
FuzzerInjectionPoint(12);
    return a3;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
f0(f0, f0, f0);
FuzzerInjectionPoint(15);
f0();
FuzzerInjectionPoint(16);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(17);
f0(f0, f0, f0);