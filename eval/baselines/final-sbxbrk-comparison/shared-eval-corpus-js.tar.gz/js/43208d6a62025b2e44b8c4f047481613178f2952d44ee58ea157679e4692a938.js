
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F2(a4, a5, a6) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    a4++;
FuzzerInjectionPoint(4);
    try { new a6(-1000.0); } catch (e) {}
FuzzerInjectionPoint(5);
    function f9(a10, a11) {
FuzzerInjectionPoint(6);
        const v13 = new Date();
FuzzerInjectionPoint(7);
        v13.timeZone = a4;
FuzzerInjectionPoint(8);
        v13.toLocaleTimeString(1073741825, v13);
FuzzerInjectionPoint(9);
        return F2;
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    this.constructor = f9;
FuzzerInjectionPoint(12);
    const v15 = this.constructor;
FuzzerInjectionPoint(13);
    try { v15(f9, v15, f9, v15, v15); } catch (e) {}
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
new F2();
FuzzerInjectionPoint(16);
new F2(1073741825, 1073741825, F2);
FuzzerInjectionPoint(17);