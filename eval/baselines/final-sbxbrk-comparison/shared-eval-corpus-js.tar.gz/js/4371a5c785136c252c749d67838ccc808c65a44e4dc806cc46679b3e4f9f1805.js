
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
function f3(a4) {
FuzzerInjectionPoint(4);
    const v6 = -1000000.0 + 0.9465582471935173;
FuzzerInjectionPoint(5);
    -1000000.0 % a4;
FuzzerInjectionPoint(6);
    1073741824 + v6;
FuzzerInjectionPoint(7);
    (-1000000.0) ** v6;
FuzzerInjectionPoint(8);
    return v6;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f3(C0);
FuzzerInjectionPoint(11);
f3();
FuzzerInjectionPoint(12);
%OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(13);
f3();