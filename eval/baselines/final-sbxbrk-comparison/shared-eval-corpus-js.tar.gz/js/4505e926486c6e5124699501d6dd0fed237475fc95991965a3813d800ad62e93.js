
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    (typeof -9223372036854775808n).valueOf();
FuzzerInjectionPoint(3);
    return f0;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f0(f0, f0, f0());
FuzzerInjectionPoint(6);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(7);
f0();
FuzzerInjectionPoint(8);