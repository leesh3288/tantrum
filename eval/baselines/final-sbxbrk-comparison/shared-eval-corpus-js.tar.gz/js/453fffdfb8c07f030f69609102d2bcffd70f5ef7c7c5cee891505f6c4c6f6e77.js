
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    const v4 = new Date();
FuzzerInjectionPoint(3);
    v4.setUTCMonth(536870912n);
FuzzerInjectionPoint(4);
    return f1;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
try { f1(536870912n); } catch (e) {}
FuzzerInjectionPoint(7);