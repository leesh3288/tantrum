
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2() {
FuzzerInjectionPoint(2);
    return Date;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f3(a4) {
FuzzerInjectionPoint(5);
    for (let [i7, i8] = (() => {
FuzzerInjectionPoint(6);
            for (let v6 = 0; v6 < 5; v6++) {
FuzzerInjectionPoint(7);
            }
FuzzerInjectionPoint(8);
            return [f2, 10];
FuzzerInjectionPoint(9);
        })();

        (() => {
FuzzerInjectionPoint(11);
            Date[i8] %= 1;
FuzzerInjectionPoint(12);
            i8--;
FuzzerInjectionPoint(13);
            const t2 = {};
FuzzerInjectionPoint(14);
            t2.toString = f2;
FuzzerInjectionPoint(15);
            return i8;
FuzzerInjectionPoint(16);
        })();

        ) {
FuzzerInjectionPoint(18);
    }
FuzzerInjectionPoint(19);
    return f2;
FuzzerInjectionPoint(20);
}
FuzzerInjectionPoint(21);
f3.call();
FuzzerInjectionPoint(22);
const v16 = f3(f2);
FuzzerInjectionPoint(23);
v16.e = v16;
FuzzerInjectionPoint(24);
%OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(25);
f3();