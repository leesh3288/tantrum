
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v5 = new ArrayBuffer(129, { maxByteLength: 268435456 });
FuzzerInjectionPoint(2);
const v6 = new Int16Array(v5);
FuzzerInjectionPoint(3);
for (const v7 in v6) {
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);