
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C4 extends constructor().Intl.v8BreakIterator {

}
FuzzerInjectionPoint(3);
new C4();