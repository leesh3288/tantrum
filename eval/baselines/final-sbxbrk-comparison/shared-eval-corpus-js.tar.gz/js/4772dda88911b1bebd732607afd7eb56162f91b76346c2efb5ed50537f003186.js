
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = constructor(constructor, constructor, constructor, constructor, constructor).Intl.DurationFormat;
FuzzerInjectionPoint(2);
const v4 = new t0();
FuzzerInjectionPoint(3);
function f5(a6, a7) {
FuzzerInjectionPoint(4);
    return a6;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
v4.constructor = f5;
FuzzerInjectionPoint(7);