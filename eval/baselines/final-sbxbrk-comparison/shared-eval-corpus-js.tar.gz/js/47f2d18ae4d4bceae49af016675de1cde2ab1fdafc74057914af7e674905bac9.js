
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    function f4(a5, a6) {
FuzzerInjectionPoint(3);
        for (let v8 = 0; v8 < 5; v8++) {
FuzzerInjectionPoint(4);
            this.d -= v8;
FuzzerInjectionPoint(5);
            v8++;
FuzzerInjectionPoint(6);
        }
FuzzerInjectionPoint(7);
        return a1;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    try { f4(a1, f0); } catch (e) {}
FuzzerInjectionPoint(10);
    return f0;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
f0(f0(f0, f0, f0), f0, f0);
FuzzerInjectionPoint(13);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(14);
f0();
FuzzerInjectionPoint(15);