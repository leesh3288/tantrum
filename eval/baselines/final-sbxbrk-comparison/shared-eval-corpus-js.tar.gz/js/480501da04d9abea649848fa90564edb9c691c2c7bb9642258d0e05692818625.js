
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Int16Array([194.51384385818892]);
FuzzerInjectionPoint(2);