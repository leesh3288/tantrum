
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Int8Array(586);
FuzzerInjectionPoint(2);
const v5 = new Uint8Array(10);
FuzzerInjectionPoint(3);
v2.set(v5);
FuzzerInjectionPoint(4);