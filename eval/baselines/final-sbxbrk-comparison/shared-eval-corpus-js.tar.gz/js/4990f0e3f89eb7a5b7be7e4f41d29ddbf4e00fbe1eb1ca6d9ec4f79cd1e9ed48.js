
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v6 = new Float32Array();
FuzzerInjectionPoint(3);
    let v12 = 1172;
FuzzerInjectionPoint(4);
    v12--;
FuzzerInjectionPoint(5);
    let v15 = 0;
FuzzerInjectionPoint(6);
    v15--;
FuzzerInjectionPoint(7);
    function f17(a18, a19, a20) {
FuzzerInjectionPoint(8);
        const v21 = -a19;
FuzzerInjectionPoint(9);
        v21 / v21;
FuzzerInjectionPoint(10);
        ~a20;
FuzzerInjectionPoint(11);
        try { a18(v12); } catch (e) {}
FuzzerInjectionPoint(12);
        const v25 = a19 & a19;
FuzzerInjectionPoint(13);
        const v30 = {

            f: v15,

            [4]: a18,

            __proto__: BigInt64Array,

            d: 85,

            h: v6,

            set b(a27) {
FuzzerInjectionPoint(20);
                super[a27] = this;
FuzzerInjectionPoint(21);
            },

            10000: 85,

            10: v12,

            [v15]: 257,

            maxByteLength: 85,

            8: v12,

            [9007199254740991](a29) {
FuzzerInjectionPoint(28);
            },

            type: "name",

            a: v6,

            10000: BigInt64Array,

            maxByteLength: 4,

        };
FuzzerInjectionPoint(34);
        let v31;
FuzzerInjectionPoint(35);
        try { v31 = v30.includes(); } catch (e) {}
FuzzerInjectionPoint(36);
        const v32 = v31 ?? v31;
FuzzerInjectionPoint(37);
        const v33 = v32 ?? v32;
FuzzerInjectionPoint(38);
        const v34 = v33 ?? v33;
FuzzerInjectionPoint(39);
        v34 ?? v34;
FuzzerInjectionPoint(40);
        ("POSITIVE_INFINITY").link(v25);
FuzzerInjectionPoint(41);
        const v40 = new WeakMap(a2);
FuzzerInjectionPoint(42);
        let v41;
FuzzerInjectionPoint(43);
        try { v41 = v40.delete(a20); } catch (e) {}
FuzzerInjectionPoint(44);
        class C42 {

            268435440 = v41;

            static #h = WeakMap;

            set h(a44) {
FuzzerInjectionPoint(48);
            }

            static ["POSITIVE_INFINITY"] = "l9id";

            static [WeakMap] = v40;

            static ["l9id"] = WeakMap;

        }
FuzzerInjectionPoint(53);
        C42.prototype = C42;
FuzzerInjectionPoint(54);
        return v34;
FuzzerInjectionPoint(55);
    }
FuzzerInjectionPoint(56);
    f17();
FuzzerInjectionPoint(57);
    f17();
FuzzerInjectionPoint(58);
    %OptimizeFunctionOnNextCall(f17);
FuzzerInjectionPoint(59);
    return f17();
FuzzerInjectionPoint(60);
}
FuzzerInjectionPoint(61);
f0();
FuzzerInjectionPoint(62);
f0();