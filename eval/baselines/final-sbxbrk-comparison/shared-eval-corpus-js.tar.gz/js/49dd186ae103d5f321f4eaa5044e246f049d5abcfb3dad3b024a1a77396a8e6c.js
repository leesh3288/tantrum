
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    const v4 = `

        class C5 {

            static get a() {

                class C7 {

                }

                const arguments = C7;

            }

        }

    `;

    return eval(v4);

}

const v14 = new Worker(f0, { type: "function" });

v14.getMessage();