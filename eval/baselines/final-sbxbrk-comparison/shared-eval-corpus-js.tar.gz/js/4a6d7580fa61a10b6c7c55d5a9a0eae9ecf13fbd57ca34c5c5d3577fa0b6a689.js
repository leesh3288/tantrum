
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = {};
FuzzerInjectionPoint(2);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(3);
    [-6808,9007199254740992,2147483648,-7109,128,1052971967,1401542916];
FuzzerInjectionPoint(4);
    for (let v6 = 0; v6 < 5; v6++) {
FuzzerInjectionPoint(5);
        v0["p"] = v6;
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    const v8 = /abc?/musg;
FuzzerInjectionPoint(8);
    const v9 = /W/dsgi;
FuzzerInjectionPoint(9);
    const v10 = /ab\b\d\bcd/mvsgi;
FuzzerInjectionPoint(10);
    function f11(a12, a13) {
FuzzerInjectionPoint(11);
        const v17 = {

            valueOf(a15, a16) {
FuzzerInjectionPoint(13);
            },

        };
FuzzerInjectionPoint(15);
        const t14 = v17.constructor;
FuzzerInjectionPoint(16);
        t14();
FuzzerInjectionPoint(17);
        function F20(a22, a23, a24) {
FuzzerInjectionPoint(18);
            if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(19);
            a23.g = a24;
FuzzerInjectionPoint(20);
            a23.g = a23;
FuzzerInjectionPoint(21);
        }
FuzzerInjectionPoint(22);
        const v25 = new F20(v9, v9);
FuzzerInjectionPoint(23);
        const t22 = v25.constructor;
FuzzerInjectionPoint(24);
        new t22(v17, v17);
FuzzerInjectionPoint(25);
    }
FuzzerInjectionPoint(26);
    f11(v8, f11);
FuzzerInjectionPoint(27);
    f11(v10);
FuzzerInjectionPoint(28);
}
FuzzerInjectionPoint(29);
f1();
FuzzerInjectionPoint(30);
f1();
FuzzerInjectionPoint(31);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(32);
f1();