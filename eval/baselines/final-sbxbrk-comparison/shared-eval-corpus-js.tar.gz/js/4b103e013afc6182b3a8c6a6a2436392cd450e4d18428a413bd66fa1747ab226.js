
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    "p" + 9;
FuzzerInjectionPoint(3);
    return f0;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v6 = f0(f0, f0);
FuzzerInjectionPoint(6);
class C7 {

    constructor(a9, a10) {
FuzzerInjectionPoint(8);
        this.e();
FuzzerInjectionPoint(9);
        %OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(10);
    }

    e = f0;

}
FuzzerInjectionPoint(13);
const v12 = new C7(v6, C7);
FuzzerInjectionPoint(14);
new C7(v12, f0);