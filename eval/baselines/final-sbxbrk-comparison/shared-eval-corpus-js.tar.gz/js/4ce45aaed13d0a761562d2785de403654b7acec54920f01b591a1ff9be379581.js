
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new BigUint64Array(8);
FuzzerInjectionPoint(2);
let v5 = new BigUint64Array(2322);
FuzzerInjectionPoint(3);
function f8(a9, a10) {
FuzzerInjectionPoint(4);
    return 536870912 > -1422665183n;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
Object.defineProperty(BigInt64Array, "valueOf", { writable: true, value: f8 });
FuzzerInjectionPoint(7);
new BigInt64Array(7);
FuzzerInjectionPoint(8);
v2.byteOffset;
FuzzerInjectionPoint(9);
v5 = v2;
FuzzerInjectionPoint(10);
try {
FuzzerInjectionPoint(11);
    new BigUint64Array(v5);
FuzzerInjectionPoint(12);
} catch(e17) {
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
function f18() {
FuzzerInjectionPoint(15);
    return 7;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
class C19 extends BigInt64Array {

    static {
FuzzerInjectionPoint(19);
        f18();
FuzzerInjectionPoint(20);
        super.byteOffset;
FuzzerInjectionPoint(21);
    }

    constructor(a24, a25, a26, a27) {
FuzzerInjectionPoint(23);
        super(a27, a27, 7);
FuzzerInjectionPoint(24);
        gc({});
FuzzerInjectionPoint(25);
    }

}
FuzzerInjectionPoint(27);
const v33 = new C19(2322, 2322, 2322, 7);
FuzzerInjectionPoint(28);
try { v33.fill(C19); } catch (e) {}
FuzzerInjectionPoint(29);
[-7.6284762387535725,-334.76535506320283];
FuzzerInjectionPoint(30);
const v36 = /\xf0\x9f\x92\xa9(?<a>(?<b>(?<c>(?<d>.).).).)u\p{Script=Greek}*/udsiy;
FuzzerInjectionPoint(31);
function F37(a39, a40) {
FuzzerInjectionPoint(32);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(33);
}
FuzzerInjectionPoint(34);
function f42(a43, a44) {
FuzzerInjectionPoint(35);
    const v49 = {

        __proto__: a44,

        set d(a46) {
FuzzerInjectionPoint(38);
        },

        h: F37,

        c: v36,

        set f(a48) {
FuzzerInjectionPoint(42);
        },

    };
FuzzerInjectionPoint(44);
    return v49;
FuzzerInjectionPoint(45);
}
FuzzerInjectionPoint(46);
f42(-5n, f42(-5n, f42));