
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new ArrayBuffer(8, { maxByteLength: 8 });
FuzzerInjectionPoint(2);
const v6 = new Int32Array(v4);
FuzzerInjectionPoint(3);
new Float64Array(v6);
FuzzerInjectionPoint(4);