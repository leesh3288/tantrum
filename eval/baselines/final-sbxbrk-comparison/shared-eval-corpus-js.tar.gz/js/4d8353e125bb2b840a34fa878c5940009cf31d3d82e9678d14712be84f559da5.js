
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
16 - 16;
FuzzerInjectionPoint(2);
-1073741824 * -1073741824;
FuzzerInjectionPoint(3);
class C8 {

    static #n(a10, a11) {
FuzzerInjectionPoint(5);
        function F12(a14, a15) {
FuzzerInjectionPoint(6);
            if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(7);
            this.c = a15;
FuzzerInjectionPoint(8);
            this.h = a10;
FuzzerInjectionPoint(9);
            this.d = a11;
FuzzerInjectionPoint(10);
        }
FuzzerInjectionPoint(11);
        new F12(16, a10);
FuzzerInjectionPoint(12);
        new F12(a10, a10);
FuzzerInjectionPoint(13);
        new F12(a10, -1073741824);
FuzzerInjectionPoint(14);
        return 256;
FuzzerInjectionPoint(15);
    }

    #c;

    d;

    #a;

}
FuzzerInjectionPoint(20);
const v19 = C8?.call;
FuzzerInjectionPoint(21);
try { new v19(256); } catch (e) {}
FuzzerInjectionPoint(22);
const v21 = new C8();
FuzzerInjectionPoint(23);
new C8();
FuzzerInjectionPoint(24);
new C8();
FuzzerInjectionPoint(25);
new Int16Array(4034);
FuzzerInjectionPoint(26);
const v27 = [-455.42421195048814];
FuzzerInjectionPoint(27);
try { v27.sort(v27); } catch (e) {}
FuzzerInjectionPoint(28);
function f29(a30, a31, a32) {
FuzzerInjectionPoint(29);
    a30 ?? a30;
FuzzerInjectionPoint(30);
    a31 ?? a31;
FuzzerInjectionPoint(31);
    const v35 = a31 ?? a31;
FuzzerInjectionPoint(32);
    v35 ?? v35;
FuzzerInjectionPoint(33);
    const v38 = a31 ?? (v35 ?? f29);
FuzzerInjectionPoint(34);
    v38.caller = v38;
FuzzerInjectionPoint(35);
    function f39(a40, a41, a42) {
FuzzerInjectionPoint(36);
        const v43 = { ...f39 };
FuzzerInjectionPoint(37);
    }
FuzzerInjectionPoint(38);
    const v44 = f39?.constructor;
FuzzerInjectionPoint(39);
    try { new v44(v35); } catch (e) {}
FuzzerInjectionPoint(40);
    const v50 = {

        [a30](a47, a48) {
FuzzerInjectionPoint(42);
            try { this.undefined(v27); } catch (e) {}
FuzzerInjectionPoint(43);
        },

    };
FuzzerInjectionPoint(45);
    try { v50.undefined(v38, v38); } catch (e) {}
FuzzerInjectionPoint(46);
    v50.undefined();
FuzzerInjectionPoint(47);
}
FuzzerInjectionPoint(48);
try { f29(-536870912, v21, 256); } catch (e) {}
FuzzerInjectionPoint(49);
const v54 = [1758895061,255,616841396];
FuzzerInjectionPoint(50);
const v55 = [268435441,-1024,-1015,-2147483648,-1389703766,-16];
FuzzerInjectionPoint(51);
[2147483647,48294];
FuzzerInjectionPoint(52);
class C57 extends C8 {

    m(a59, a60) {
FuzzerInjectionPoint(54);
        /x\9foo|(bar|baz)|quux*/mdy;
FuzzerInjectionPoint(55);
        /nI\x01?/y;
FuzzerInjectionPoint(56);
        /w(x)(x)(x)(x)(x)(x)(x)(x)(x)(x)\109(?:ab)|cde/s;
FuzzerInjectionPoint(57);
        for (let v64 = 0; v64 < 32; v64++) {
FuzzerInjectionPoint(58);
            v54["p" + v64] = v64;
FuzzerInjectionPoint(59);
        }
FuzzerInjectionPoint(60);
        return a60;
FuzzerInjectionPoint(61);
    }

    785999032;

    [v55];

    #o(a68, a69) {
FuzzerInjectionPoint(65);
    }

    #c = 256;

    g;

    [-536870912] = -187447409;

    1388811459;

}
FuzzerInjectionPoint(71);
try { C57.apply(f29, f29); } catch (e) {}
FuzzerInjectionPoint(72);
([2.220446049250313e-16,-2.82836887780201,-1000000000.0,4.0,-217601.23895646317,NaN,-397365.6648717325])["includes"]();
FuzzerInjectionPoint(73);
function f74() {
FuzzerInjectionPoint(74);
    2147483647 != 2147483647;
FuzzerInjectionPoint(75);
    try { ("268435456").localeCompare(4034); } catch (e) {}
FuzzerInjectionPoint(76);
    let v80 = -2.220446049250313e-16 >>> -2.220446049250313e-16;
FuzzerInjectionPoint(77);
    v80++;
FuzzerInjectionPoint(78);
    const v95 = {

        e: -2.220446049250313e-16,

        m(a83, a84) {
FuzzerInjectionPoint(81);
            const v85 = delete a84?.[2];
FuzzerInjectionPoint(82);
            try { v85["round"](2147483647, v85, "round", "round", -2.220446049250313e-16); } catch (e) {}
FuzzerInjectionPoint(83);
            let v89 = -1242605751;
FuzzerInjectionPoint(84);
            Math.floor(2147483647);
FuzzerInjectionPoint(85);
            const v91 = 2147483647 || v89;
FuzzerInjectionPoint(86);
            const v92 = Math.imul(v89, v89);
FuzzerInjectionPoint(87);
            Math.asin(v91);
FuzzerInjectionPoint(88);
            v89++;
FuzzerInjectionPoint(89);
            return v92;
FuzzerInjectionPoint(90);
        },

    };
FuzzerInjectionPoint(92);
    function f96() {
FuzzerInjectionPoint(93);
        return f29;
FuzzerInjectionPoint(94);
    }
FuzzerInjectionPoint(95);
    Object.defineProperty(v95, "toString", { get: f96 });
FuzzerInjectionPoint(96);
    v95.e = v95;
FuzzerInjectionPoint(97);
}
FuzzerInjectionPoint(98);
f74();
FuzzerInjectionPoint(99);
const v98 = f74();
FuzzerInjectionPoint(100);
try { ("undefined").fontcolor(v98); } catch (e) {}
FuzzerInjectionPoint(101);
function f101() {
FuzzerInjectionPoint(102);
    const v104 = {

        o(a103) {
FuzzerInjectionPoint(104);
        },

    };
FuzzerInjectionPoint(106);
}
FuzzerInjectionPoint(107);
function f105() {
FuzzerInjectionPoint(108);
    for (let v106 = 0; v106 < 5; v106++) {
FuzzerInjectionPoint(109);
        f101();
FuzzerInjectionPoint(110);
    }
FuzzerInjectionPoint(111);
}
FuzzerInjectionPoint(112);
f105();