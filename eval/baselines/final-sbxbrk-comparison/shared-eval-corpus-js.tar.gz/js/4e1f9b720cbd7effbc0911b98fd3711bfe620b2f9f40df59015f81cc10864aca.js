
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
class C1 {

}
FuzzerInjectionPoint(5);
Int32Array[2] = C0;
FuzzerInjectionPoint(6);
const v4 = Object.seal(Int32Array);
FuzzerInjectionPoint(7);
try { v4.apply(C1, v4); } catch (e) {}