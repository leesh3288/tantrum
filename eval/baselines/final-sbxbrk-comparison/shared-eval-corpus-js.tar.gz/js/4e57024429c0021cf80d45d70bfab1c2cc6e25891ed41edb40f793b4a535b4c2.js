
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Float64Array();
FuzzerInjectionPoint(2);
function f3(a4) {
FuzzerInjectionPoint(3);
    const v5 = {};
FuzzerInjectionPoint(4);
    const v6 = v2.byteLength;
FuzzerInjectionPoint(5);
    const v9 = v5[Symbol.match];
FuzzerInjectionPoint(6);
    new Int32Array(v9, v9, v6);
FuzzerInjectionPoint(7);
    return Int32Array;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f3();
FuzzerInjectionPoint(10);
f3();
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(12);
f3();
FuzzerInjectionPoint(13);