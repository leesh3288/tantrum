
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    const v4 = a1.prototype.constructor;
FuzzerInjectionPoint(3);
    let v5;
FuzzerInjectionPoint(4);
    try { v5 = v4(); } catch (e) {}
FuzzerInjectionPoint(5);
    a1[16] = a1;
FuzzerInjectionPoint(6);
    async function f7(a8, a9, a10) {
FuzzerInjectionPoint(7);
        a9.name = a9;
FuzzerInjectionPoint(8);
        return v5;
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
    f7(Set, f7);
FuzzerInjectionPoint(11);
    return f0;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
class C12 {

    constructor(a14, a15) {
FuzzerInjectionPoint(15);
        this.e(a14);
FuzzerInjectionPoint(16);
        %OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(17);
    }

    e = f0;

}
FuzzerInjectionPoint(20);
new C12(f0);
FuzzerInjectionPoint(21);
try { new C12(f0, C12); } catch (e) {}