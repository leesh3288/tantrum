
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [0.7284011768201828,-1000000.0,0.035274165649744726,276392.70502625196,-2.2250738585072014e-308,-Infinity];
FuzzerInjectionPoint(2);
class C2 {

    [536870888] = v0;

}
FuzzerInjectionPoint(5);
const v3 = new C2();
FuzzerInjectionPoint(6);
d8.serializer.serialize(v3);