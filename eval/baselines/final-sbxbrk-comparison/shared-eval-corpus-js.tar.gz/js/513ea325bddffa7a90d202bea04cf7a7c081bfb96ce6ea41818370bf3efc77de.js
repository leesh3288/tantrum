
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
function f1() {
FuzzerInjectionPoint(3);
    return f1;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(6);
    a3.configurable = f2;
FuzzerInjectionPoint(7);
    return a3;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v8 = new Proxy(v0, { getOwnPropertyDescriptor: f2 });
FuzzerInjectionPoint(10);
v8.constructor = f1;
FuzzerInjectionPoint(11);
try { v8.splice(); } catch (e) {}
FuzzerInjectionPoint(12);