
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F4(a6, a7, a8, a9) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    function f10(a11) {
FuzzerInjectionPoint(4);
        return 1024;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    a6.valueOf = f10;
FuzzerInjectionPoint(7);
    const v12 = F4++;
FuzzerInjectionPoint(8);
    try { new a6(a6, this, a8, a8); } catch (e) {}
FuzzerInjectionPoint(9);
    ("1urPa").constructor.fromCharCode(1, -5, v12, a9).localeCompare();
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
new F4(F4, 268435456, 3953);
FuzzerInjectionPoint(12);