
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v7 = {

    m(a2, a3) {
FuzzerInjectionPoint(3);
        Math.sinh();
FuzzerInjectionPoint(4);
        Math.atan2(83.05891337575599, 83.05891337575599);
FuzzerInjectionPoint(5);
        return 83.05891337575599;
FuzzerInjectionPoint(6);
    },

};
FuzzerInjectionPoint(8);
v7.m();
FuzzerInjectionPoint(9);
try { new BigUint64Array(Float32Array); } catch (e) {}