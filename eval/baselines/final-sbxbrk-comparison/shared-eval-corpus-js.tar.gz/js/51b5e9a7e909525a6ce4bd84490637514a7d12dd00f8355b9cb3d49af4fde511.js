
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    static b;

    c;

    m(a5) {
FuzzerInjectionPoint(5);
        const v6 = super[this];
FuzzerInjectionPoint(6);
        [] > Array;
FuzzerInjectionPoint(7);
        let v10 = 9007199254740991n;
FuzzerInjectionPoint(8);
        v10++;
FuzzerInjectionPoint(9);
        v6 - v6;
FuzzerInjectionPoint(10);
        return this;
FuzzerInjectionPoint(11);
    }

    #e;

    static get c() {
FuzzerInjectionPoint(14);
        gc();
FuzzerInjectionPoint(15);
        return -128;
FuzzerInjectionPoint(16);
    }

}
FuzzerInjectionPoint(18);
C3.prototype;
FuzzerInjectionPoint(19);
const v17 = new C3();
FuzzerInjectionPoint(20);
v17.c;
FuzzerInjectionPoint(21);
new C3();
FuzzerInjectionPoint(22);
new C3();
FuzzerInjectionPoint(23);
function f21() {
FuzzerInjectionPoint(24);
    [-865879.4747004735];
FuzzerInjectionPoint(25);
    const v23 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(26);
    const v24 = v23.at();
FuzzerInjectionPoint(27);
    v24 * v24;
FuzzerInjectionPoint(28);
    for (let v26 = 0; v26 < 5; v26++) {
FuzzerInjectionPoint(29);
        [v23[v26]];
FuzzerInjectionPoint(30);
    }
FuzzerInjectionPoint(31);
    const v30 = new Uint8ClampedArray();
FuzzerInjectionPoint(32);
    v30[0] = v30;
FuzzerInjectionPoint(33);
    return f21;
FuzzerInjectionPoint(34);
}
FuzzerInjectionPoint(35);
const v31 = f21();
FuzzerInjectionPoint(36);
const v32 = v31?.constructor;
FuzzerInjectionPoint(37);
try { new v32(v17); } catch (e) {}
FuzzerInjectionPoint(38);
function f34(a35, a36) {
FuzzerInjectionPoint(39);
    a35 ?? a35;
FuzzerInjectionPoint(40);
    a36 ?? a36;
FuzzerInjectionPoint(41);
    %OptimizeFunctionOnNextCall(f21);
FuzzerInjectionPoint(42);
    v31();
FuzzerInjectionPoint(43);
    return a36;
FuzzerInjectionPoint(44);
}
FuzzerInjectionPoint(45);
[-2.220446049250313e-16,0.8732155735492322];
FuzzerInjectionPoint(46);
([302.564841966363,-7.215729346419135,1000.0,-1.0])[3];
FuzzerInjectionPoint(47);
[0.003227752603959244,1.0,-2.2250738585072014e-308,0.0,7.200325308308965];
FuzzerInjectionPoint(48);
/[\111]Q5/mdgy;
FuzzerInjectionPoint(49);
/r/mdv.lastIndex;
FuzzerInjectionPoint(50);
/\xe2\x81\xa3/ug;
FuzzerInjectionPoint(51);
const v48 = [];
FuzzerInjectionPoint(52);
const v49 = v48?.map;
FuzzerInjectionPoint(53);
try { new v49(v17); } catch (e) {}
FuzzerInjectionPoint(54);
function f51(a52, a53, a54) {
FuzzerInjectionPoint(55);
    a52 ?? a52;
FuzzerInjectionPoint(56);
    a54 ?? a54;
FuzzerInjectionPoint(57);
    const v58 = Math.expm1(v48);
FuzzerInjectionPoint(58);
    v58 % v58;
FuzzerInjectionPoint(59);
    v58 + v58;
FuzzerInjectionPoint(60);
    return v48;
FuzzerInjectionPoint(61);
}
FuzzerInjectionPoint(62);
const v61 = f51();
FuzzerInjectionPoint(63);
v61.toString = f34;
FuzzerInjectionPoint(64);
f51(f51, v61, v61);
FuzzerInjectionPoint(65);
%OptimizeFunctionOnNextCall(f51);
FuzzerInjectionPoint(66);
const v63 = f51();
FuzzerInjectionPoint(67);
try { v63.lastIndexOf(v63); } catch (e) {}