
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = -117.85125587123218;
FuzzerInjectionPoint(2);
const v1 = v0--;
FuzzerInjectionPoint(3);
function f2(a3, a4) {
FuzzerInjectionPoint(4);
    const v6 = new ArrayBuffer();
FuzzerInjectionPoint(5);
    const v8 = new DataView(v6);
FuzzerInjectionPoint(6);
    let v9;
FuzzerInjectionPoint(7);
    try { v9 = v8.setFloat32(v0); } catch (e) {}
FuzzerInjectionPoint(8);
    return v9;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f2(v1, v0);
FuzzerInjectionPoint(11);
f2();
FuzzerInjectionPoint(12);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(13);
f2(v0, v1);
FuzzerInjectionPoint(14);