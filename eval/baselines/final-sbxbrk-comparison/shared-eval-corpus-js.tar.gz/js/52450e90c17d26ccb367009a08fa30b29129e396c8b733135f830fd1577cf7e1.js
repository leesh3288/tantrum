
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 extends Array {

    6;

}
FuzzerInjectionPoint(4);
const v2 = new C1();
FuzzerInjectionPoint(5);
class C4 {

}
FuzzerInjectionPoint(7);
try { C4.apply(undefined, v2); } catch (e) {}