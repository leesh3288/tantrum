
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
for (let v19 = 0; v19 < 100; v19++) {
FuzzerInjectionPoint(2);
    class C20 {

    }
FuzzerInjectionPoint(4);
    for (let v21 = 0; v21 < 5; v21++) {
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    const v23 = {};
FuzzerInjectionPoint(7);
    try { v23.entries(-128n, C20, 2); } catch (e) {}
FuzzerInjectionPoint(8);
}