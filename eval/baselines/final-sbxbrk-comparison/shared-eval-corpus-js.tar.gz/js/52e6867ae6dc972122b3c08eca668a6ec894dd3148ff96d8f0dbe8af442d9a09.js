
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 extends WeakSet {

    static {
FuzzerInjectionPoint(3);
        function f4(a5) {
FuzzerInjectionPoint(4);
            for (let v6 = 0; v6 < 5; v6++) {
FuzzerInjectionPoint(5);
                delete arguments[v6];
FuzzerInjectionPoint(6);
            }
FuzzerInjectionPoint(7);
            return this;
FuzzerInjectionPoint(8);
        }
FuzzerInjectionPoint(9);
        f4(-2147483647);
FuzzerInjectionPoint(10);
    }

}