
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v4 = f0.toLocaleString().replace(/Q0k/mds, /xyz{1,}^xxx$/vgy);
FuzzerInjectionPoint(3);
    const v6 = v4.split.constructor;
FuzzerInjectionPoint(4);
    let v7;
FuzzerInjectionPoint(5);
    try { v7 = v6(v4); } catch (e) {}
FuzzerInjectionPoint(6);
    return v7;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);