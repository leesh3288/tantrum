
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint8Array(37);
FuzzerInjectionPoint(2);
const t1 = constructor().Intl.NumberFormat;
FuzzerInjectionPoint(3);
t1().formatToParts(v2);
FuzzerInjectionPoint(4);