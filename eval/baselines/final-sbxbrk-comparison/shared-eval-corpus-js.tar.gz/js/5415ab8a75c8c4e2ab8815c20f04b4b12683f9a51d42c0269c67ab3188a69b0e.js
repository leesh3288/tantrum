
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v5 = (7).toString();
FuzzerInjectionPoint(3);
    class C6 {

        static {
FuzzerInjectionPoint(5);
            try {
FuzzerInjectionPoint(6);
                const v8 = {};
FuzzerInjectionPoint(7);
                function f9() {
FuzzerInjectionPoint(8);
                    return a2;
FuzzerInjectionPoint(9);
                }
FuzzerInjectionPoint(10);
                function f10(a11) {
FuzzerInjectionPoint(11);
                    f10.length = a11;
FuzzerInjectionPoint(12);
                    return a11;
FuzzerInjectionPoint(13);
                }
FuzzerInjectionPoint(14);
                Object.defineProperty(v8, 65536, { enumerable: true, get: f9, set: f10 });
FuzzerInjectionPoint(15);
                v8[65536] = v8;
FuzzerInjectionPoint(16);
            } catch(e12) {
FuzzerInjectionPoint(17);
                e12.stack.replace(7, v5);
FuzzerInjectionPoint(18);
            }
FuzzerInjectionPoint(19);
        }

    }
FuzzerInjectionPoint(21);
    return f0;
FuzzerInjectionPoint(22);
}
FuzzerInjectionPoint(23);
f0();