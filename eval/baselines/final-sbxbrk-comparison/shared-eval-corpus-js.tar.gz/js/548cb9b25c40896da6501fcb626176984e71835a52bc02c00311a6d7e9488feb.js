
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
([-689196.9022430313]).concat(Uint16Array);
FuzzerInjectionPoint(2);