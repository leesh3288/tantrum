
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new Proxy(WeakSet, {});
FuzzerInjectionPoint(2);
const v5 = [449.5631501106536,0.3627753962059366,1.7976931348623157e+308,Infinity,-5.0,1.28193087278821e+308,-1.3464067296401868e+308,-5.0,-576806.2511913211,1.7976931348623157e+308];
FuzzerInjectionPoint(3);
v5.__proto__ = v4;
FuzzerInjectionPoint(4);
new Int16Array(v5);
FuzzerInjectionPoint(5);