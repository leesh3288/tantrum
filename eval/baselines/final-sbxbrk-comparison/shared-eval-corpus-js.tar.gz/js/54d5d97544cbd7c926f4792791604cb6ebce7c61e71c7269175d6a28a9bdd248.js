
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2() {
FuzzerInjectionPoint(2);
    BigInt64Array instanceof Int8Array;
FuzzerInjectionPoint(3);
    const v6 = Array(567);
FuzzerInjectionPoint(4);
    function f7(a8) {
FuzzerInjectionPoint(5);
        return v6;
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    return Int8Array;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f2();
FuzzerInjectionPoint(10);
f2();
FuzzerInjectionPoint(11);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(12);
f2();
FuzzerInjectionPoint(13);