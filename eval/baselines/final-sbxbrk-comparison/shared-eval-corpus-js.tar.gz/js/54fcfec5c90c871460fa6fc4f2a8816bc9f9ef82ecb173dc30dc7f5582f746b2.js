
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = [-Infinity,-1000000000.0];
FuzzerInjectionPoint(2);
v2.length = 6;
FuzzerInjectionPoint(3);
({}).constructor.freeze(v2);
FuzzerInjectionPoint(4);
v2["indexOf"](1411735524, "indexOf");
FuzzerInjectionPoint(5);