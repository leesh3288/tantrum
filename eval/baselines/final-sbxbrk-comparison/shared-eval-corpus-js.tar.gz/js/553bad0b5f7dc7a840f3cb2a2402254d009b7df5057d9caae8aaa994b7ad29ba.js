
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    const v7 = constructor().Intl;
FuzzerInjectionPoint(3);
    v7[Symbol.toPrimitive] = f0;
FuzzerInjectionPoint(4);
    const t3 = v7.NumberFormat;
FuzzerInjectionPoint(5);
    const v11 = t3();
FuzzerInjectionPoint(6);
    try { v11.formatRangeToParts(v7, a2); } catch (e) {}
FuzzerInjectionPoint(7);
    return v11.formatRange(9452n, -712962336n);
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v16 = new Uint8Array(255);
FuzzerInjectionPoint(10);
v16.find(f0);
FuzzerInjectionPoint(11);