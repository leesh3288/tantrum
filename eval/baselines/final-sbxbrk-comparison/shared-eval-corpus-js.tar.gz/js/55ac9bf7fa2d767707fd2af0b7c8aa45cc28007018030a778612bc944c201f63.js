
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
JSON.toJSON = [37323,-9007199254740992,2147483647,1438370477,2147483649,10];
FuzzerInjectionPoint(2);
JSON.stringify(JSON, "undefined", "boolean");
FuzzerInjectionPoint(3);