
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    a2++;
FuzzerInjectionPoint(3);
    class C6 {

    }
FuzzerInjectionPoint(5);
    const v8 = Math.imul(1073741823, a2);
FuzzerInjectionPoint(6);
    function f9(a10, a11, a12) {
FuzzerInjectionPoint(7);
        return v8;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v14 = f1(f1(), f1, f1);
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(12);
f1(1073741823, 1073741823, v14);