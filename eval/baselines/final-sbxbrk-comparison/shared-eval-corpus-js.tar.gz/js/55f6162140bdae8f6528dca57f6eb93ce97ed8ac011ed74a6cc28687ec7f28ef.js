
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    static h = "-10397";

    get c() {

        for (let v5 = 0; v5 < 32; v5++) {

            this["p" + v5] = v5;

            const v12 = Int8Array(3036);

            function f14(a15, a16, a17) {
FuzzerInjectionPoint(8);
                -a17;

                const v19 = [-1000000.0,-4.0,0.8001481853982213,NaN,-1.2588228100373335,NaN,4.790138581879706,0.37294717680582157,-4.0];

                const v20 = [-2.220446049250313e-16,3.370178617236892,351.5120790226979];

                const v21 = [-Infinity,8.72776997471745e+307,3.0];

                const v22 = [v21,v20,v21];

                [v20,v20,v22,v21,v22];

                new Int8Array(65535);

                new Int8Array(257);

                const v34 = Uint32Array(16);

                v34[2418] &&= 65535;

                class C35 {

                    static [65535] = v34;

                    128;

                    [257];

                    [v19] = 257;

                }

                C35();

                new C35();

                a15 & a15;

                const v42 = {

                    ...f14,

                    get f() {

                        return 129;

                    },

                    68: Int8Array,

                    f: v12,

                    b: a15,

                    h: a16,

                    set c(a41) {

                    },

                    e: 10,

                };

                return v42;

            }

            f14(BigInt64Array, BigInt64Array, 129);

            f14(129);
FuzzerInjectionPoint(44);
        }

        return this;

    }

    9 = 268435456;

}

C3.length;

let v46 = 256;

v46--;

new Uint8ClampedArray();

function f51() {

}

const v52 = [15,1073741823];

function F54() {

    if (!new.target) { throw 'must be called with new'; }

}
FuzzerInjectionPoint(59);
const v57 = new ArrayBuffer();

v57.slice();

v52[0] = v52;

function f63(a64, a65, a66) {

    const v70 = {

        ...f63,

        get f() {

            return 129;

        },

        b: a64,

        h: a65,

        set c(a69) {
FuzzerInjectionPoint(71);
        },

        e: 10,

        a: Int8Array,

        ...a64,

    };

    return v70;

}

3397 == 3397;

Uint8Array.length = Uint8Array;

const v73 = new Uint8Array();

const v74 = v73?.constructor;

try { new v74(v52, 3397, v52); } catch (e) {}

const v77 = 1571 | 1571;

v77 < v77;

const v80 = new Float64Array(1571);

8 >>> 8;

new Uint16Array(8);
FuzzerInjectionPoint(88);
[-63829];

[1073741825,2147483647,8,-1355701431,5];

const v88 = new BigInt64Array();

const v90 = new BigInt64Array(v88.subarray(), BigInt64Array, BigInt64Array);

v90.BYTES_PER_ELEMENT;

const v92 = [268435440,-5488,-2147483649,536870889,-1246036791,-11,-350,20024,1000];

v92[5] = v92;

/gpy7QS?/udgiy;

!true;

function F96(a98, a99) {

    if (!new.target) { throw 'must be called with new'; }

    a99[117] = a99;

    this.a = a99;

}
FuzzerInjectionPoint(102);
const v100 = F96?.__lookupSetter__;
FuzzerInjectionPoint(103);
try { new v100(f51); } catch (e) {}

try { new F96(v80, v80); } catch (e) {}

class C104 extends WeakMap {

}

/(((\xed\xa0\x80))\x02\xed\xb0\x80)/mudsiy.multiline;
FuzzerInjectionPoint(108);
const v107 = C3?.hasOwnProperty;

try { v107(); } catch (e) {}

const v110 = [5.0,1.086302118340775e+308,-4.0,1000000000.0,NaN,-8.028061503276937e+307];

v110[4] = v110;

class C112 {

}
FuzzerInjectionPoint(114);
const v114 = ~C112;

const v116 = v114 ^ (-9007199254740991 & v114);
FuzzerInjectionPoint(116);
v116 >>> v116;

Math.log10();

const v123 = new Int8Array(1293);

5 >>> 5;
FuzzerInjectionPoint(120);
for (let i = 0; i < 50; i++) {

    const t120 = 3;

    t120.valueOf = 10;

    try { ("undefined").fontsize(v123); } catch (e) {}

    v123.join();

}