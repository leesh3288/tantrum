
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {

    function f5() {

        class C7 {

        }

        [C7,-65536n];

        return f1;

    }

    ("string").search(f5);

}

const v13 = new Worker(f1, { type: "function" });

v13.getMessage();