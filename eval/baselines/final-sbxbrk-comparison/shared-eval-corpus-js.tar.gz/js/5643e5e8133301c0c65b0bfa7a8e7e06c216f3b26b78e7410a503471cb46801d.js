
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2() {
FuzzerInjectionPoint(2);
    const v3 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(3);
    for (let v4 = 0; v4 < 5; v4++) {
FuzzerInjectionPoint(4);
        v4 * v4;
FuzzerInjectionPoint(5);
        Uint32Array.BYTES_PER_ELEMENT = Uint32Array;
FuzzerInjectionPoint(6);
        function f7(a8, a9, a10, a11) {
FuzzerInjectionPoint(7);
        }
FuzzerInjectionPoint(8);
        v3[v4];
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f2();
FuzzerInjectionPoint(12);
f2();
FuzzerInjectionPoint(13);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(14);
f2();
FuzzerInjectionPoint(15);