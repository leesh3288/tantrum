
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = /fa\bc?/mudg;
FuzzerInjectionPoint(2);
const v1 = /w/diy;
FuzzerInjectionPoint(3);
const v2 = /8D/mvsgy;
FuzzerInjectionPoint(4);
function f3(a4, a5) {
FuzzerInjectionPoint(5);
    const v6 = %WasmStruct();
FuzzerInjectionPoint(6);
    try {
FuzzerInjectionPoint(7);
        v0.exec("p");
FuzzerInjectionPoint(8);
    } catch(e9) {
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
v2[Symbol.toPrimitive] = f3;
FuzzerInjectionPoint(12);
class C12 {

    static [v2];

    [v1] = v0;

    constructor(a14) {
FuzzerInjectionPoint(16);
        gc({ execution: "sync", type: "major" });
FuzzerInjectionPoint(17);
    }

}
FuzzerInjectionPoint(19);
new C12(v1);
FuzzerInjectionPoint(20);
new BigUint64Array(0);
FuzzerInjectionPoint(21);
const v26 = Date();
FuzzerInjectionPoint(22);
const v27 = { __proto__: v26 };