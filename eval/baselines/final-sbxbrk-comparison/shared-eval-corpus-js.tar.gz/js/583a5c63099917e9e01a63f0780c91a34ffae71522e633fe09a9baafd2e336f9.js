
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [6.962931374131044e+306,569.79957233908,-9.317502026321723e+307,-7.376503578462626e+307,5.0,-2.713765281165079,1000000000.0,0.9129536734004149];
FuzzerInjectionPoint(2);
const v1 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

    0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00,

    0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A,

    0x01, 0x00,

])));
FuzzerInjectionPoint(8);
function f3() {
FuzzerInjectionPoint(9);
    let v4 = 0.006747058553866703;
FuzzerInjectionPoint(10);
    const v9 = {

        c: 0.26466734924051094,

        __proto__: f3,

        0: f3,

        268435456: 177,

        f: v4,

        toString(a7, a8) {
FuzzerInjectionPoint(17);
            ({"h":v4,} = a8);
FuzzerInjectionPoint(18);
            return this;
FuzzerInjectionPoint(19);
        },

    };
FuzzerInjectionPoint(21);
    return v9;
FuzzerInjectionPoint(22);
}
FuzzerInjectionPoint(23);
[-2.220446049250313e-16,-1e-15,-2.2250738585072014e-308,-5.0,0.0,5.0,-4.0,2.8810898499754494,2.2250738585072014e-308];
FuzzerInjectionPoint(24);
const v11 = [1.369803961282905,-370749.9548839739];
FuzzerInjectionPoint(25);
class C12 {

    static b;

}
FuzzerInjectionPoint(28);
new C12();
FuzzerInjectionPoint(29);
new C12();
FuzzerInjectionPoint(30);
new C12();
FuzzerInjectionPoint(31);
[-4294967295,-65004,-61620,-65537];
FuzzerInjectionPoint(32);
const v17 = [-65537,4096,1000,-2147483647];
FuzzerInjectionPoint(33);
const v18 = [1019751986];
FuzzerInjectionPoint(34);
128 !== v0;
FuzzerInjectionPoint(35);
v18 - 2;
FuzzerInjectionPoint(36);
[3.188728153324346e+307,-1000.0];
FuzzerInjectionPoint(37);
[0.17239914544994228,-Infinity,3.0,1.0,-6.576622368847143,2.0,6.0378993451813585,1.0,4.769906117446442e+307,-2.0];
FuzzerInjectionPoint(38);
[7.297816910557678];
FuzzerInjectionPoint(39);
++C12;
FuzzerInjectionPoint(40);
new Set();
FuzzerInjectionPoint(41);
let v31 = -995881780;
FuzzerInjectionPoint(42);
v0 & v17;
FuzzerInjectionPoint(43);
const v34 = -(--v31);
FuzzerInjectionPoint(44);
Math.cbrt(v31);
FuzzerInjectionPoint(45);
v0 & v34;
FuzzerInjectionPoint(46);
~10000;
FuzzerInjectionPoint(47);
[v11,v17];
FuzzerInjectionPoint(48);
const v39 = [v18];
FuzzerInjectionPoint(49);
[v39,v11];
FuzzerInjectionPoint(50);
/([\xe2\x81\xa3])/mdsgi;

const v42 = /([\ca]k[\0])/mdg;
FuzzerInjectionPoint(52);
/(ab|cde)TO./ud;
FuzzerInjectionPoint(53);
const v49 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

    0x00, 0x03, 0x01, 0x00, 0x04, 0x04, 0x01, 0x70, 0x00, 0x0A,

    0x05, 0x06, 0x01, 0x01, 0x04, 0xD6, 0x92, 0x02, 0x06, 0x08,

    0x01, 0x7F, 0x00, 0x41, 0x80, 0xEA, 0x00, 0x0B, 0x07, 0x0D,

    0x02, 0x03, 0x77, 0x67, 0x30, 0x03, 0x00, 0x03, 0x77, 0x74,

    0x30, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x01, 0x00,

])));
FuzzerInjectionPoint(61);
v49.exports;
FuzzerInjectionPoint(62);
new Uint8Array(3397);
FuzzerInjectionPoint(63);
1571 | 1571;
FuzzerInjectionPoint(64);
const v55 = new Float64Array(1571);
FuzzerInjectionPoint(65);
new Uint16Array(8);
FuzzerInjectionPoint(66);
[-63829];

[1073741825,2147483647,8,-1355701431,5];
FuzzerInjectionPoint(68);
const v61 = [268435440,-5488,-2147483649,536870889,-1246036791,-11,-350,20024,1000];
FuzzerInjectionPoint(69);
v61[5] = v61;
FuzzerInjectionPoint(70);
/gpy7QS?/udgiy;
FuzzerInjectionPoint(71);
!true;
FuzzerInjectionPoint(72);
function F65(a67, a68) {
FuzzerInjectionPoint(73);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(74);
    this.a = a68;
FuzzerInjectionPoint(75);
}
FuzzerInjectionPoint(76);
try { new F65(v55, v55); } catch (e) {}
FuzzerInjectionPoint(77);
[5.0,1.086302118340775e+308,-4.0,1000000000.0,NaN,-8.028061503276937e+307];
FuzzerInjectionPoint(78);
if (v42 === true) {
FuzzerInjectionPoint(79);
    try {
FuzzerInjectionPoint(80);
        v39.toReversed();
FuzzerInjectionPoint(81);
    } catch(e78) {
FuzzerInjectionPoint(82);
    }
FuzzerInjectionPoint(83);
} else {
FuzzerInjectionPoint(84);
    let v79 = WebAssembly.JSTag;
FuzzerInjectionPoint(85);
    const v80 = %WasmStruct();
FuzzerInjectionPoint(86);
}
FuzzerInjectionPoint(87);
const v81 = new Int8Array(1293);
FuzzerInjectionPoint(88);
5 >>> 5;
FuzzerInjectionPoint(89);
for (let i = 0; i < 100; i++) {
FuzzerInjectionPoint(90);
    const t100 = 3;
FuzzerInjectionPoint(91);
    t100.valueOf = 10;
FuzzerInjectionPoint(92);
    try { ("undefined").fontsize(v81); } catch (e) {}
FuzzerInjectionPoint(93);
    v81.join();
FuzzerInjectionPoint(94);
}