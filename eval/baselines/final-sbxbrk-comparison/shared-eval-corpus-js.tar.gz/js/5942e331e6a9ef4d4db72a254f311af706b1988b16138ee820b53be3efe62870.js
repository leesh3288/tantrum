
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3) {
FuzzerInjectionPoint(2);
    function f4() {
FuzzerInjectionPoint(3);
        return a3;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    class C5 {

        constructor(a7, a8, a9, a10) {
FuzzerInjectionPoint(7);
            for (const v11 in a3) {
FuzzerInjectionPoint(8);
            }
FuzzerInjectionPoint(9);
            const v12 = this.constructor;
FuzzerInjectionPoint(10);
            try { new v12(); } catch (e) {}
FuzzerInjectionPoint(11);
            this.constructor = f4;
FuzzerInjectionPoint(12);
            const v14 = this.constructor;
FuzzerInjectionPoint(13);
            function f15(a16) {
FuzzerInjectionPoint(14);
            }
FuzzerInjectionPoint(15);
            let v17;
FuzzerInjectionPoint(16);
            try { v17 = new v14(); } catch (e) {}
FuzzerInjectionPoint(17);
            v17.length;
FuzzerInjectionPoint(18);
            for (let i20 = 0, i21 = Int16Array;

                i20;

                (() => {
FuzzerInjectionPoint(21);
                    function f24() {
FuzzerInjectionPoint(22);
                        return v14;
FuzzerInjectionPoint(23);
                    }
FuzzerInjectionPoint(24);
                })()) {
FuzzerInjectionPoint(25);
            }
FuzzerInjectionPoint(26);
        }

    }
FuzzerInjectionPoint(28);
    new C5(f1, a3, f1, f4);
FuzzerInjectionPoint(29);
    return Int16Array;
FuzzerInjectionPoint(30);
}
FuzzerInjectionPoint(31);
f1(Int16Array, f1);