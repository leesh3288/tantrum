
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-865879.4747004735];
FuzzerInjectionPoint(2);
for (let v2 = 0; v2 < 5; v2++) {
FuzzerInjectionPoint(3);
    const v4 = v1.__proto__;
FuzzerInjectionPoint(4);
    v4.includes(268435441);
FuzzerInjectionPoint(5);
    v4[0] = -9.669007513562892e+307;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);