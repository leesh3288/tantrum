
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-2147483649,341926594,5];
FuzzerInjectionPoint(2);
const v1 = v0.flat(v0);
FuzzerInjectionPoint(3);
const v7 = new SharedArrayBuffer(491, { maxByteLength: 3721665499 });
FuzzerInjectionPoint(4);
const v8 = new Float32Array(v7);
FuzzerInjectionPoint(5);
v8.set(v1);
FuzzerInjectionPoint(6);