
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
class C1 {

    static {
FuzzerInjectionPoint(4);
        let v3;
FuzzerInjectionPoint(5);
        try { v3 = this.acos(); } catch (e) {}
FuzzerInjectionPoint(6);
        v3 >>>= this;
FuzzerInjectionPoint(7);
        this[v0] = v0;
FuzzerInjectionPoint(8);
        this[1958184263] == v0;
FuzzerInjectionPoint(9);
    }

    [v0] = v0;

    static [v0];

    b;

    0;

    static #g = v0;

    static a;

}
FuzzerInjectionPoint(17);
const v6 = new C1();
FuzzerInjectionPoint(18);
const v7 = new C1();
FuzzerInjectionPoint(19);
const v8 = new C1();
FuzzerInjectionPoint(20);
let v15;
FuzzerInjectionPoint(21);
try { v15 = ("NT5s5").trimRight(); } catch (e) {}
FuzzerInjectionPoint(22);
const v17 = gc();
FuzzerInjectionPoint(23);
try { new v15(v15, "NT5s5", 4.0, v17); } catch (e) {}
FuzzerInjectionPoint(24);
let v22 = Infinity;
FuzzerInjectionPoint(25);
let v23 = ++v22;
FuzzerInjectionPoint(26);
const v24 = v23 ^ "NT5s5";
FuzzerInjectionPoint(27);
1657399545 - v23--;
FuzzerInjectionPoint(28);
!v7;
FuzzerInjectionPoint(29);
Math.abs(v24);
FuzzerInjectionPoint(30);
1657399545 ** v0;
FuzzerInjectionPoint(31);
class C30 extends C1 {

    get c() {
FuzzerInjectionPoint(33);
        const v32 = {

            apply: gc,

            call: gc,

            construct: gc,

            defineProperty: gc,

            deleteProperty: gc,

            get: gc,

            getOwnPropertyDescriptor: gc,

            getPrototypeOf: gc,

            has: gc,

            isExtensible: gc,

            ownKeys: gc,

            set: gc,

            setPrototypeOf: gc,

        };
FuzzerInjectionPoint(48);
        new Proxy(C1, v32);
FuzzerInjectionPoint(49);
        return v8;
FuzzerInjectionPoint(50);
    }

    o(a36, a37, a38) {
FuzzerInjectionPoint(52);
        a37 >> v8;
FuzzerInjectionPoint(53);
        a38.__proto__ = Math;
FuzzerInjectionPoint(54);
        typeof "NT5s5" === "object";
FuzzerInjectionPoint(55);
        return a38;
FuzzerInjectionPoint(56);
    }

    set f(a47) {
FuzzerInjectionPoint(58);
        C1.a = v6;
FuzzerInjectionPoint(59);
        [v8,4.0,[v7,a47,"-4294967295",v7,a47]];
FuzzerInjectionPoint(60);
        [681.4142192451609,a47,v0];
FuzzerInjectionPoint(61);
    }

    #e;

}
FuzzerInjectionPoint(64);
const v51 = new C30();
FuzzerInjectionPoint(65);
v17?.[v51];
FuzzerInjectionPoint(66);
let v54 = 3;
FuzzerInjectionPoint(67);
const v56 = gc >>> 4.2875625934882855;
FuzzerInjectionPoint(68);
const v57 = v54++;
FuzzerInjectionPoint(69);
gc / v56;
FuzzerInjectionPoint(70);
-v57;
FuzzerInjectionPoint(71);
new C30();
FuzzerInjectionPoint(72);
new C30();
FuzzerInjectionPoint(73);
function f62() {
FuzzerInjectionPoint(74);
    const v66 = {

        toString(a64, a65) {
FuzzerInjectionPoint(76);
            return this;
FuzzerInjectionPoint(77);
        },

    };
FuzzerInjectionPoint(79);
    return v66;
FuzzerInjectionPoint(80);
}
FuzzerInjectionPoint(81);
const v67 = f62();
FuzzerInjectionPoint(82);
([0,127,-4916615,1681156843,536870912,53158])[3];
FuzzerInjectionPoint(83);
function f70(a71, a72, a73, a74) {
FuzzerInjectionPoint(84);
    a71 <= a71;
FuzzerInjectionPoint(85);
    return f62;
FuzzerInjectionPoint(86);
}
FuzzerInjectionPoint(87);
try { f70(v67); } catch (e) {}
FuzzerInjectionPoint(88);
let v77 = 9007199254740991n;
FuzzerInjectionPoint(89);
v77--;