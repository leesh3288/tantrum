
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-1000.0,-3.0,0.0,-623512.7201507678,-2.2250738585072014e-308,123625.05009495094,-1000.0,NaN,1000.0];
FuzzerInjectionPoint(2);
const v1 = `
FuzzerInjectionPoint(3);
    /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(4);
`;
FuzzerInjectionPoint(5);
const v3 = +v0;
FuzzerInjectionPoint(6);
const v7 = {

    [v1]: v3,

    get f() {
FuzzerInjectionPoint(9);
        try { JSON.stringify(this); } catch (e) {}
FuzzerInjectionPoint(10);
        return v3;
FuzzerInjectionPoint(11);
    },

};
FuzzerInjectionPoint(13);
const v8 = { ...v7 };