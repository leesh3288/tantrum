
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    const v3 = a2--;
FuzzerInjectionPoint(3);
    const v4 = { [a1]: a1 };
FuzzerInjectionPoint(4);
    v4[0] = v3;
FuzzerInjectionPoint(5);
    const v6 = -v4[0];
FuzzerInjectionPoint(6);
    let v7;
FuzzerInjectionPoint(7);
    try { v7 = v6(); } catch (e) {}
FuzzerInjectionPoint(8);
    return v7;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v10 = new Uint8Array(255);
FuzzerInjectionPoint(11);
v10.find(f0);
FuzzerInjectionPoint(12);