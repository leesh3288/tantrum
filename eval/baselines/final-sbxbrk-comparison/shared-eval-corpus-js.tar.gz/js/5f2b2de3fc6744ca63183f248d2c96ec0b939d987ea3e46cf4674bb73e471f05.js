
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Int8Array();
FuzzerInjectionPoint(2);
({}).constructor.apply(Uint16Array, v2);
FuzzerInjectionPoint(3);