
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    for (let i6 = 15, i7 = 0;

        (() => {
FuzzerInjectionPoint(4);
            const v8 = i7 % i7;
FuzzerInjectionPoint(5);
            i6 !== i6;
FuzzerInjectionPoint(6);
            return v8;
FuzzerInjectionPoint(7);
        })();

        ) {
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
    Set.bind(Set, Set, Set);
FuzzerInjectionPoint(11);
    return a1;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f0();
FuzzerInjectionPoint(14);
f0();
FuzzerInjectionPoint(15);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(16);
f0();