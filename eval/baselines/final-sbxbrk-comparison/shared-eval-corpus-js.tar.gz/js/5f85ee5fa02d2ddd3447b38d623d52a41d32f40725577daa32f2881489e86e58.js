
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

    static toString(a2, a3) {
FuzzerInjectionPoint(3);
        try {
FuzzerInjectionPoint(4);
            a3.valueOf();
FuzzerInjectionPoint(5);
        } catch(e5) {
FuzzerInjectionPoint(6);
            e5.stack;
FuzzerInjectionPoint(7);
        }
FuzzerInjectionPoint(8);
    }

}
FuzzerInjectionPoint(10);
const v8 = new Int16Array();
FuzzerInjectionPoint(11);
v8.fill(C0);