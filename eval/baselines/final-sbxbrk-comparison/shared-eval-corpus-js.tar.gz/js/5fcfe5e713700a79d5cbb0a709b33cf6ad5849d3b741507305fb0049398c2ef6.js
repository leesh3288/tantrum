
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = d8.test.FastCAPI;

const v3 = new t0();

const v4 = v3.overloaded_add_all_32bit_int_no_sig;

try { v4(); } catch (e) {}