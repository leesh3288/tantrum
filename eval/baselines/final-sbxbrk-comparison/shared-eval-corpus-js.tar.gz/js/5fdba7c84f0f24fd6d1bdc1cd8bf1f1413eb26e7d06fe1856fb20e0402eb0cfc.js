
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = Array.isArray(938);
FuzzerInjectionPoint(2);
const v6 = this.Intl.Locale;
FuzzerInjectionPoint(3);
v6.firstDayOfWeek = 938;
FuzzerInjectionPoint(4);
function f7() {
FuzzerInjectionPoint(5);
    return v2;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
Object.defineProperty(v6, "collation", { get: f7 });
FuzzerInjectionPoint(8);
v6.numeric = v6;
FuzzerInjectionPoint(9);
const v8 = new v6("object", v6);
FuzzerInjectionPoint(10);
v8.toString();
FuzzerInjectionPoint(11);