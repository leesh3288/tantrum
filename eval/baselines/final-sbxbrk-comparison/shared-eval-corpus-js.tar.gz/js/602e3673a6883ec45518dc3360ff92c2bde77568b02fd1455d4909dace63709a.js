
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    class C3 {

    }
FuzzerInjectionPoint(4);
    try { C3.bind(constructor); } catch (e) {}
FuzzerInjectionPoint(5);
    for (let [i8, i9] = (() => {
FuzzerInjectionPoint(6);
            10 - 10;
FuzzerInjectionPoint(7);
            return [0, 10];
FuzzerInjectionPoint(8);
        })();

        i8 < i9;

        (() => {
FuzzerInjectionPoint(11);
            const v13 = i8++;
FuzzerInjectionPoint(12);
            v13 >>> v13;
FuzzerInjectionPoint(13);
            i9--;
FuzzerInjectionPoint(14);
        })()) {
FuzzerInjectionPoint(15);
        new Float32Array([Infinity,0.4761088559953277,1.775746044000269e+308,-5.0,121.20958743215851]);
FuzzerInjectionPoint(16);
    }
FuzzerInjectionPoint(17);
    return f1;
FuzzerInjectionPoint(18);
}
FuzzerInjectionPoint(19);
f1();
FuzzerInjectionPoint(20);
f1(f1);
FuzzerInjectionPoint(21);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(22);
f1();