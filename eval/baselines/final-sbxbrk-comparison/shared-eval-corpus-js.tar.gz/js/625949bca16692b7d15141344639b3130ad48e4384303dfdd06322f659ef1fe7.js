
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
([0.32886627289699144,-1.5598880375892608e+308,2.2250738585072014e-308,-1.0]).toLocaleString();
FuzzerInjectionPoint(2);