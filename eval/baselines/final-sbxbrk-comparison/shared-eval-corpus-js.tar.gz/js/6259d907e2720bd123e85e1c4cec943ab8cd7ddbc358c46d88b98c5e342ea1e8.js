
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

    ("0A").link().match();

    return f0;

}

f0();

f0();

%OptimizeMaglevOnNextCall(f0);

f0();