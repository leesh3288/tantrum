
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);
f0();
FuzzerInjectionPoint(4);
f0();
FuzzerInjectionPoint(5);
function F6(a8, a9) {
FuzzerInjectionPoint(6);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
new F6();
FuzzerInjectionPoint(9);
for (let v18 = 0; v18 < 5; v18++) {
FuzzerInjectionPoint(10);
    const v19 = /(?<a>)+/mudgiy;
FuzzerInjectionPoint(11);
    function f20(a21) {
FuzzerInjectionPoint(12);
        return f20;
FuzzerInjectionPoint(13);
    }
FuzzerInjectionPoint(14);
    function f22() {
FuzzerInjectionPoint(15);
    }
FuzzerInjectionPoint(16);
    function f25() {
FuzzerInjectionPoint(17);
        const v26 = [536870912,4];
FuzzerInjectionPoint(18);
        for (let v29 = 0; v29 < 5; v29++) {
FuzzerInjectionPoint(19);
            try {
FuzzerInjectionPoint(20);
                f20();
FuzzerInjectionPoint(21);
            } catch(e31) {
FuzzerInjectionPoint(22);
            }
FuzzerInjectionPoint(23);
            v19[Symbol] = WeakSet;
FuzzerInjectionPoint(24);
        }
FuzzerInjectionPoint(25);
        const v33 = v26 ?? v26;
FuzzerInjectionPoint(26);
        const v34 = `
FuzzerInjectionPoint(27);
            v33[Symbol] = f22;
FuzzerInjectionPoint(28);
        `;
FuzzerInjectionPoint(29);
        eval();
FuzzerInjectionPoint(30);
    }
FuzzerInjectionPoint(31);
    f25();
FuzzerInjectionPoint(32);
    %OptimizeMaglevOnNextCall(f25);
FuzzerInjectionPoint(33);
}
FuzzerInjectionPoint(34);