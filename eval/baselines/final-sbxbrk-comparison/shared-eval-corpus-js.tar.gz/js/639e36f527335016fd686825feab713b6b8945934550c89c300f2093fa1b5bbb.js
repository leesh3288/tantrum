
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    function f4(a5, a6, a7) {
FuzzerInjectionPoint(3);
        const t2 = 13;
FuzzerInjectionPoint(4);
        t2.b = (4.0 / (-4294967297 & a5)) << a5;
FuzzerInjectionPoint(5);
        return 4.0;
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    f4(f4());
FuzzerInjectionPoint(8);
    return a2;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f0(f0, f0);
FuzzerInjectionPoint(11);
f0();
FuzzerInjectionPoint(12);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(13);
f0();
FuzzerInjectionPoint(14);