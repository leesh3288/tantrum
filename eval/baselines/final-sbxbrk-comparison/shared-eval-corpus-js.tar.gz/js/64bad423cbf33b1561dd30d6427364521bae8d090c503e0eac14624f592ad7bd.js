
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2() {
FuzzerInjectionPoint(2);
    parseInt("-2147483649", 279.6510956202751);
FuzzerInjectionPoint(3);
    return f2;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v6 = f2();
FuzzerInjectionPoint(6);
v6();
FuzzerInjectionPoint(7);
const v8 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(8);
function f9(a10, a11) {
FuzzerInjectionPoint(9);
    %OptimizeFunctionOnNextCall(v6);
FuzzerInjectionPoint(10);
    v6();
FuzzerInjectionPoint(11);
    return a11;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
v8.toString = f9;
FuzzerInjectionPoint(14);
class C13 extends Set {

    [v8] = v8;

}