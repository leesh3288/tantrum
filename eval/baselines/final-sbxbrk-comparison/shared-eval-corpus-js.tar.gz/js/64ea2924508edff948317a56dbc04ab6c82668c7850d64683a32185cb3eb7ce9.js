
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = ("toSorted").match(257);
FuzzerInjectionPoint(2);
try {
FuzzerInjectionPoint(3);
    ("boolean").localeCompare("boolean", "boolean", v2);
FuzzerInjectionPoint(4);
} catch(e5) {
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);