
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

}

function f3() {

    return f3;

}

function f4() {

    const v7 = Array(122);

    const v8 = [1000000000.0,185453.66805808875,887.1083108101639,-Infinity,2.2250738585072014e-308,-9.96501636426367e+307];

    const v9 = { __proto__: v7, a: 122, maxByteLength: 255, ...v8 };

    const v10 = v9.toLocaleString();

    return v10.bold(f4, f4, v9, v10, v10);

}

f3.valueOf = f4;

new Date(f3);

const v14 = new Int16Array(255);

new Date();

Symbol.toPrimitive;

gc();

v14[157];

const v29 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08,

    0x01, 0x60, 0x04, 0x7C, 0x7D, 0x7F, 0x7D, 0x00, 0x03, 0x02,

    0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00, 0x06, 0x01,

    0x00, 0x07, 0x06, 0x01, 0x02, 0x77, 0x30, 0x00, 0x00, 0x09,

    0x01, 0x00, 0x0A, 0x0D, 0x01, 0x0B, 0x01, 0x01, 0x7F, 0x20,

    0x02, 0x20, 0x02, 0x6D, 0x21, 0x04, 0x0B,

])));

const v30 = v29.exports;

try { v30.w0(); } catch (e) {}