
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
for (let i2 = 0, i3 = 10; i3; i3--) {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);
for (let v9 = 0; v9 < 5; v9++) {
FuzzerInjectionPoint(4);
    function f10(a11, a12, a13) {
FuzzerInjectionPoint(5);
        function f14(a15) {
FuzzerInjectionPoint(6);
            const v18 = new WeakMap();
FuzzerInjectionPoint(7);
            class C19 {

                constructor(a21, a22) {
FuzzerInjectionPoint(9);
                    v18.set(v18);
FuzzerInjectionPoint(10);
                }

            }
FuzzerInjectionPoint(12);
            new C19();
FuzzerInjectionPoint(13);
            gc({ execution: "async", type: "minor" });
FuzzerInjectionPoint(14);
            return f10;
FuzzerInjectionPoint(15);
        }
FuzzerInjectionPoint(16);
        f14(a11);
FuzzerInjectionPoint(17);
        f14(f10);
FuzzerInjectionPoint(18);
        return f10;
FuzzerInjectionPoint(19);
    }
FuzzerInjectionPoint(20);
    f10();
FuzzerInjectionPoint(21);
}