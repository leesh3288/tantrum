
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    function f4() {

        function f5(a6, a7, a8) {

            class C9 {

                constructor(a11, a12) {

                    try {

                        super.p();

                    } catch(e14) {

                    }

                }

            }

            const v15 = new C9(C9, a3);

            return v15;

        }

        const v16 = f5(f5, a2, f0);

        return f5(a2, f5(a2, f0, a3), v16);

    }

    f4();

    const v20 = f4();

    f4();

    return v20;

}

const v25 = new Worker(f0, { type: "function" });

v25.getMessage();