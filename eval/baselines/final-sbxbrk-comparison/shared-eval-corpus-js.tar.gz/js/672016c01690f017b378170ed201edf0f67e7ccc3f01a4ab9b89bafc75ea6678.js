
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = Number.isNaN();

function f2(a3, a4) {

    return Number;

}

const v8 = new Worker(f2, { type: "function" });

v8.postMessage(v1);