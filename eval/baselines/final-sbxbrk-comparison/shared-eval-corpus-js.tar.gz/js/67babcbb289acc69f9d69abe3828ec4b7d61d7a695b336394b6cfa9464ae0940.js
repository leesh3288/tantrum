
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v5 = new BigInt64Array([-128n,9007199254740992n,-1073741824n,-128n,-1073741824n]);
FuzzerInjectionPoint(2);
v5.sort();
FuzzerInjectionPoint(3);