
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Int16Array(435);
FuzzerInjectionPoint(2);
v2.lastIndexOf();
FuzzerInjectionPoint(3);