
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    function f1(a2, a3, a4) {
FuzzerInjectionPoint(3);
        Math.abs(f1);
FuzzerInjectionPoint(4);
        return f1;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    for (let v7 = 0; v7 < 5; v7++) {
FuzzerInjectionPoint(7);
        v7 / v7;
FuzzerInjectionPoint(8);
        function f9() {
FuzzerInjectionPoint(9);
            for (let v10 = 0; v10 < 5; v10++) {
FuzzerInjectionPoint(10);
                const v11 = %WasmArray();
FuzzerInjectionPoint(11);
            }
FuzzerInjectionPoint(12);
            return f1;
FuzzerInjectionPoint(13);
        }
FuzzerInjectionPoint(14);
        try { f9(); } catch (e) {}
FuzzerInjectionPoint(15);
        f9();
FuzzerInjectionPoint(16);
    }
FuzzerInjectionPoint(17);
    return f0;
FuzzerInjectionPoint(18);
}
FuzzerInjectionPoint(19);
f0();
FuzzerInjectionPoint(20);
f0();
FuzzerInjectionPoint(21);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(22);
f0();
FuzzerInjectionPoint(23);