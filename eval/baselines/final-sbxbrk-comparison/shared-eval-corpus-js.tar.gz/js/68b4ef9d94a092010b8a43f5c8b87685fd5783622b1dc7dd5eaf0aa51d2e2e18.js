
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    function F3() {
FuzzerInjectionPoint(3);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    class C5 {

        n(a7, a8) {
FuzzerInjectionPoint(7);
            this instanceof a8.__proto__;
FuzzerInjectionPoint(8);
        }

    }
FuzzerInjectionPoint(10);
    const v11 = new C5();
FuzzerInjectionPoint(11);
    let v12;
FuzzerInjectionPoint(12);
    try { v12 = v11.n(F3, F3); } catch (e) {}
FuzzerInjectionPoint(13);
    return v12;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
const v15 = new Uint8Array(255);
FuzzerInjectionPoint(16);
v15.find(f0);