
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = `

    /\u{12345}\u{23456}/dvi;

    function f3(a4, a5, a6) {

        return v1;

    }

`;

function f7(a8, a9, a10) {

    return a10;

}

const v13 = [-55558,Worker,v1];

new Worker(f7, { arguments: v13, type: "function" });