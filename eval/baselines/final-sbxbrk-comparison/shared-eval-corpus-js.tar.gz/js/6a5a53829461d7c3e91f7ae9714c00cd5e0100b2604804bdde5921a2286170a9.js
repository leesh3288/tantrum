
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = -1000000.0;
FuzzerInjectionPoint(2);
t0.b = -1000000.0;
FuzzerInjectionPoint(3);
function f2() {
FuzzerInjectionPoint(4);
    for (let v3 = 0; v3 < 5; v3++) {
FuzzerInjectionPoint(5);
        const v4 = -v3;
FuzzerInjectionPoint(6);
        const v7 = Array(122);
FuzzerInjectionPoint(7);
        const v8 = [-1000000000000.0,2.0,-1e-15,-5.0050640670918645];
FuzzerInjectionPoint(8);
        const v9 = [3.0,-4.0,1.7976931348623157e+308,-1.0,-7.081833756406592];
FuzzerInjectionPoint(9);
        const v10 = [-596992.2717851705,1.3656356845740762e+308];
FuzzerInjectionPoint(10);
        function f11(a12, a13) {
FuzzerInjectionPoint(11);
            return { 3: v9, [v7]: v8, ...v10 };
FuzzerInjectionPoint(12);
        }
FuzzerInjectionPoint(13);
        f11(v10);
FuzzerInjectionPoint(14);
        f11(v3, v3);
FuzzerInjectionPoint(15);
        v4 % v4;
FuzzerInjectionPoint(16);
    }
FuzzerInjectionPoint(17);
    return f2;
FuzzerInjectionPoint(18);
}
FuzzerInjectionPoint(19);
const t18 = f2();
FuzzerInjectionPoint(20);
t18();
FuzzerInjectionPoint(21);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(22);
f2();
FuzzerInjectionPoint(23);