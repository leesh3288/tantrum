
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-2.2250738585072014e-308,-2.0,-314.3788121119486,6.589672936608327];

const v1 = [Infinity,751679.4055589868,1000.0,-7.229909029034363,1e-15,-3.0,-0.0,-1.0,1000000000000.0,1e-15];

const v2 = [3.9240870369464215e+307,-2.2250738585072014e-308];

class C3 {

    static #f = v0;

    constructor(a5) {

        const v6 = this?.__lookupGetter__;

        try { new v6(v0); } catch (e) {}

        a5[1] = a5;

        const v8 = v2.length;

        try {

            delete v1[this];

            super.e = a5;

            C3?.[v8];

            [...a5] = v2;

            new WeakSet();

            super.valueOf();

        } catch(e14) {

            const v15 = e14?.__lookupGetter__;

            try { new v15(e14); } catch (e) {}

        }

    }

    toString(a18, a19) {

        this.length = this;

        const f = this;

        f.length;

        const v22 = {};

        const v24 = new Proxy(v0, v22);

        try { v24.fill(v24); } catch (e) {}

        return v22;

    }

    static n(a27, a28) {

        return C3;

    }

}

C3.prototype = C3;

const v32 = new C3(v2);

const v33 = new C3(v1);

v33.length;

const v35 = new C3(v1);

try { v35.toString(v1, v35); } catch (e) {}

new BigUint64Array(3277);

try { new BigInt64Array(BigInt64Array, v1, v1); } catch (e) {}

new BigInt64Array(2);

~8;

try { new Uint32Array(v2, v2, v1); } catch (e) {}

const v49 = new Uint32Array(8);

4 * 4;

const v53 = new Int16Array(4);

1651 * 1651;

new Float64Array(1651);

const v59 = new Uint8ClampedArray(725);

const v61 = new Int32Array();

try { v61.fill(v32); } catch (e) {}

const v63 = v61.keys();

try { v63.some(725); } catch (e) {}

const v65 = [-1.0];

const v66 = v65[0];

const v67 = [-510545.8560286926,2.2250738585072014e-308,1000000.0,-0.0];

try { v67.every(v53); } catch (e) {}

v67.flat();

function f70() {

    const v72 = { a: -4294967295 };

    v72.b = v72;

    let v73 = v72.a;

    v65[268435456] = v73;

    8 === v49;

    const v76 = Symbol.dispose;

    const v78 = {

        value: Float64Array,

        [v76]() {

            return v59;

        },

    };

    using v79 = v78;

    -v73;

    const v81 = -v73;

    v81 * v81;

    for (let v83 = 0; v83 < 54; v83++) {

        v73 = v72;

        1651 >> v66;

    }

    -(v73 & v73);

}

f70();

f70();

f70();