
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    for (let v3 = 0; v3 < 32; v3++) {
FuzzerInjectionPoint(3);
        function f4() {
FuzzerInjectionPoint(4);
            return f4;
FuzzerInjectionPoint(5);
        }
FuzzerInjectionPoint(6);
        class C5 extends f4 {

            static {
FuzzerInjectionPoint(8);
                try {
FuzzerInjectionPoint(9);
                    super.setTime();
FuzzerInjectionPoint(10);
                } catch(e8) {
FuzzerInjectionPoint(11);
                }
FuzzerInjectionPoint(12);
            }

        }
FuzzerInjectionPoint(14);
    }
FuzzerInjectionPoint(15);
    return f0;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
new Promise(f0);