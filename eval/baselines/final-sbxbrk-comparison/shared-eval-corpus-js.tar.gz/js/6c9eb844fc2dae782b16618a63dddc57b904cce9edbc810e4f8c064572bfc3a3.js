
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0(a2, a3, a4) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v5 = new F0();
FuzzerInjectionPoint(5);
function f6() {
FuzzerInjectionPoint(6);
    gc();
FuzzerInjectionPoint(7);
    return v5;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
function f9(a10) {
FuzzerInjectionPoint(10);
    return F0;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
Object.defineProperty(v5, "a", { configurable: true, enumerable: true, get: f6, set: f9 });
FuzzerInjectionPoint(13);
d8.serializer.serialize(v5);
FuzzerInjectionPoint(14);