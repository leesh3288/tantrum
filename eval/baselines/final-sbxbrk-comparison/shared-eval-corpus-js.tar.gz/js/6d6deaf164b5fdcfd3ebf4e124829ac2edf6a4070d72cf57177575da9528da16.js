
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = ([257,0,16,-12,-1545663704,60054,-1073741824,-350588351]).__proto__;
FuzzerInjectionPoint(2);
([536870912,1979792005,-1024]).concat(v1);
FuzzerInjectionPoint(3);