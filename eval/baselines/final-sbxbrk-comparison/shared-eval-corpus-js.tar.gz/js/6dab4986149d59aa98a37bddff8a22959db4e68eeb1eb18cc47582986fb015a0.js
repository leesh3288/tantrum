
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3) {
FuzzerInjectionPoint(2);
    function* f4(a5, a6, a7, a8) {
FuzzerInjectionPoint(3);
        [WeakMap];
FuzzerInjectionPoint(4);
        return f4;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    a3[a3] = 255;
FuzzerInjectionPoint(7);
    const v12 = { maxByteLength: 1073741824 };
FuzzerInjectionPoint(8);
    const v14 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

        0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

        0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00,

        0x06, 0x0D, 0x01, 0x7C, 0x00, 0x44, 0x00, 0x00, 0x00, 0x00,

        0x00, 0x00, 0x14, 0xC0, 0x0B, 0x07, 0x07, 0x01, 0x03, 0x77,

        0x67, 0x30, 0x03, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x01, 0x00,

    ])));
FuzzerInjectionPoint(15);
    d = 512;
FuzzerInjectionPoint(16);
    function f17(a18) {
FuzzerInjectionPoint(17);
        const v19 = {};
FuzzerInjectionPoint(18);
        v19.b = d;
FuzzerInjectionPoint(19);
        return v19;
FuzzerInjectionPoint(20);
    }
FuzzerInjectionPoint(21);
    return 255;
FuzzerInjectionPoint(22);
}
FuzzerInjectionPoint(23);
Float32Array[Symbol.toPrimitive] = f2;
FuzzerInjectionPoint(24);
new Float32Array(255);
FuzzerInjectionPoint(25);
function f23() {
FuzzerInjectionPoint(26);
    return f23;
FuzzerInjectionPoint(27);
}
FuzzerInjectionPoint(28);
const v24 = [536870912,4];
FuzzerInjectionPoint(29);
Math.log2(v24);
FuzzerInjectionPoint(30);
try {
FuzzerInjectionPoint(31);
    new f23();
FuzzerInjectionPoint(32);
    v24.length;
FuzzerInjectionPoint(33);
} catch(e29) {
FuzzerInjectionPoint(34);
}
FuzzerInjectionPoint(35);
new BigInt64Array(2953);
FuzzerInjectionPoint(36);
class C33 {

    constructor(a35, a36) {
FuzzerInjectionPoint(38);
        JSON.stringify(JSON, C33, a35);
FuzzerInjectionPoint(39);
    }

}
FuzzerInjectionPoint(41);
new BigUint64Array(0);
FuzzerInjectionPoint(42);
let v44 = 0;
FuzzerInjectionPoint(43);
do {
FuzzerInjectionPoint(44);
    v44++;
FuzzerInjectionPoint(45);
} while (v44 < 23683)
FuzzerInjectionPoint(46);
[1000000.0,8.64708792366644,-831664.6872030196,0.3346655020016013,-2.0,1.0856389565094547e+308,1.0,2.0,655948.9789209445,231.21962419128636];
FuzzerInjectionPoint(47);
[1.1041054324286819,NaN,2.6551375135986814e+307,-186.68891956766754,-4.0,508.51218705414135,-1000000000.0,-2.301825763874106,642.2339602079278,368.235770370984];
FuzzerInjectionPoint(48);
const v52 = [1000000000000.0,-760655.3553068807,-3.852250443624053,-8.585712325374802,1.1581765098175279e+308,-2.2250738585072014e-308,-92230.24290328729,-5.0,694680.9002399112];
FuzzerInjectionPoint(49);
for (let v54 = 0; v54 < 5; v54++) {
FuzzerInjectionPoint(50);
    ("HJm").startsWith("HJm", v54);
FuzzerInjectionPoint(51);
}
FuzzerInjectionPoint(52);
function f57() {
FuzzerInjectionPoint(53);
    function f59() {
FuzzerInjectionPoint(54);
        return f57;
FuzzerInjectionPoint(55);
    }
FuzzerInjectionPoint(56);
    %PrepareFunctionForOptimization(f59);
FuzzerInjectionPoint(57);
    f59();
FuzzerInjectionPoint(58);
    function f61() {
FuzzerInjectionPoint(59);
        const v62 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(60);
        try { Int16Array.findIndex(); } catch (e) {}
FuzzerInjectionPoint(61);
        const v65 = v62.at();
FuzzerInjectionPoint(62);
        v65 >> v65;
FuzzerInjectionPoint(63);
    }
FuzzerInjectionPoint(64);
    f61();
FuzzerInjectionPoint(65);
}
FuzzerInjectionPoint(66);
Float32Array[Symbol.toPrimitive] = Symbol;
FuzzerInjectionPoint(67);
function f71() {
FuzzerInjectionPoint(68);
    function f72(a73) {
FuzzerInjectionPoint(69);
        class C74 {

        }
FuzzerInjectionPoint(71);
        function f75(a76, a77, a78, a79) {
FuzzerInjectionPoint(72);
            return C74;
FuzzerInjectionPoint(73);
        }
FuzzerInjectionPoint(74);
    }
FuzzerInjectionPoint(75);
    function f80() {
FuzzerInjectionPoint(76);
        return Float32Array;
FuzzerInjectionPoint(77);
    }
FuzzerInjectionPoint(78);
    let v81 = 4294967296;
FuzzerInjectionPoint(79);
    const v84 = ([-865879.4747004735]).fill.call(v81);
FuzzerInjectionPoint(80);
    v81--;
FuzzerInjectionPoint(81);
    const v87 = new Float64Array();
FuzzerInjectionPoint(82);
    function f88() {
FuzzerInjectionPoint(83);
    }
FuzzerInjectionPoint(84);
    const v90 = new Int32Array(v52);
FuzzerInjectionPoint(85);
    const v91 = v87.length;
FuzzerInjectionPoint(86);
    f88(v91, ...v52, ...v90, v91);
FuzzerInjectionPoint(87);
    function f93(a94) {
FuzzerInjectionPoint(88);
        const v95 = {};
FuzzerInjectionPoint(89);
    }
FuzzerInjectionPoint(90);
    Object.defineProperty(v84, Symbol.toPrimitive, { enumerable: true, set: f93 });
FuzzerInjectionPoint(91);
    v84[Symbol.toPrimitive] = f80;
FuzzerInjectionPoint(92);
    v84.toFixed();
FuzzerInjectionPoint(93);
    class C101 {

        209 = f72;

    }
FuzzerInjectionPoint(96);
}
FuzzerInjectionPoint(97);
f71();
FuzzerInjectionPoint(98);
f71();
FuzzerInjectionPoint(99);
%OptimizeMaglevOnNextCall(f71);
FuzzerInjectionPoint(100);
f71();