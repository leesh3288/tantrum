
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    const v4 = `

        const v5 = /wP\u{12345}\u{23456}/vsgi;

        v5.exec(v5);

    `;

    eval(v4);

    return v4;

}

const v12 = new Worker(f0, { type: "function" });

v12.getMessage();