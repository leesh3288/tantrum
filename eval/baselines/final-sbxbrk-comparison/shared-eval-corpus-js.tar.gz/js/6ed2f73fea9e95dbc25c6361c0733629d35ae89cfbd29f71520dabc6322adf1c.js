
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [3,536870889,-2147483649,0,-2128784737,8,20147];

function f1(a2) {

    const v4 = new Map(a2);

    v4.e = v0;

    const v6 = Symbol.dispose;

    const v7 = v6.description;

    const v9 = {

        [v6]() {

        },

    };

    using v10 = v9;

    for (const v11 of v4) {

    }

    return v7;

}

f1();

f1();

%OptimizeFunctionOnNextCall(f1);

f1();