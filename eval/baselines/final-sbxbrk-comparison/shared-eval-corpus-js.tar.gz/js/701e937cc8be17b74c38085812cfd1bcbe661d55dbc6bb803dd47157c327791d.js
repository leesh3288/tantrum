
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    let v1 = 9007199254740992n;
FuzzerInjectionPoint(3);
    v1++;
FuzzerInjectionPoint(4);
    v1++;
FuzzerInjectionPoint(5);
    const v4 = ~v1;
FuzzerInjectionPoint(6);
    v1 *= v1;
FuzzerInjectionPoint(7);
    return v1 * v4;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
class C6 {

}
FuzzerInjectionPoint(11);
C6.valueOf = f0;
FuzzerInjectionPoint(12);
const v9 = ([C6,[]])[1];
FuzzerInjectionPoint(13);
const t11 = constructor().Intl.NumberFormat;
FuzzerInjectionPoint(14);
t11().formatRangeToParts(C6, v9);