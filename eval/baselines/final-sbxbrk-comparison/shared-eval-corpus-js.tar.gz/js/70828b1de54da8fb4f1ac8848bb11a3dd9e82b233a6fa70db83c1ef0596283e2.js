
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v4 = [-469902281,-4096,129,-1326,-39103];
FuzzerInjectionPoint(3);
    let v5 = 268435456;
FuzzerInjectionPoint(4);
    for (let v6 = 0; v6 < 5; v6++) {
FuzzerInjectionPoint(5);
        const v7 = v4 * v4;
FuzzerInjectionPoint(6);
        v5 &= !(v7 & v7);
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    return f0;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f0(f0, f0, f0);
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f0());
FuzzerInjectionPoint(12);
f0();
FuzzerInjectionPoint(13);