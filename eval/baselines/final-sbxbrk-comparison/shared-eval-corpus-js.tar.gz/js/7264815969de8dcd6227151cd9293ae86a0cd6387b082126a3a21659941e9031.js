
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-40583,-6161,16,-9007];
FuzzerInjectionPoint(2);
const v3 = new Int8Array(v0);
FuzzerInjectionPoint(3);
const v6 = new Uint8ClampedArray(98);
FuzzerInjectionPoint(4);
function f7(a8, a9) {
FuzzerInjectionPoint(5);
    v6[6] = a9;
FuzzerInjectionPoint(6);
    Float32Array[a9] = a8;
FuzzerInjectionPoint(7);
    v0 >>> 98;
FuzzerInjectionPoint(8);
    let v13;
FuzzerInjectionPoint(9);
    try { v13 = constructor.toString(a8, a8); } catch (e) {}
FuzzerInjectionPoint(10);
    const v14 = constructor(a9, v13, v13);
FuzzerInjectionPoint(11);
    const v15 = v14?.DisposableStack;
FuzzerInjectionPoint(12);
    try { v15(f7, f7, a8, v14); } catch (e) {}
FuzzerInjectionPoint(13);
    const v17 = v14?.TypeError;
FuzzerInjectionPoint(14);
    v17.stackTraceLimit = v17;
FuzzerInjectionPoint(15);
    let v18;
FuzzerInjectionPoint(16);
    try { v18 = new Float32Array(); } catch (e) {}
FuzzerInjectionPoint(17);
    v18.AsyncDisposableStack = v18;
FuzzerInjectionPoint(18);
    v3[v15] >>>= 5;
FuzzerInjectionPoint(19);
    v6[9] = a8;
FuzzerInjectionPoint(20);
    v3.length += constructor;
FuzzerInjectionPoint(21);
    const v19 = v18?.PI;
FuzzerInjectionPoint(22);
    let v20;
FuzzerInjectionPoint(23);
    try { v20 = v19(); } catch (e) {}
FuzzerInjectionPoint(24);
    try { v20.use(); } catch (e) {}
FuzzerInjectionPoint(25);
    for (let v22 = 0; v22 < 5; v22++) {
FuzzerInjectionPoint(26);
        const v24 = "p" + v22;
FuzzerInjectionPoint(27);
        const v25 = v24[1];
FuzzerInjectionPoint(28);
        v25[0] = v25;
FuzzerInjectionPoint(29);
        let v26;
FuzzerInjectionPoint(30);
        try { v26 = v24.trimLeft(); } catch (e) {}
FuzzerInjectionPoint(31);
        try { v26.toString(); } catch (e) {}
FuzzerInjectionPoint(32);
    }
FuzzerInjectionPoint(33);
    return Uint8ClampedArray;
FuzzerInjectionPoint(34);
}
FuzzerInjectionPoint(35);
f7();
FuzzerInjectionPoint(36);
f7();
FuzzerInjectionPoint(37);
%OptimizeFunctionOnNextCall(f7);
FuzzerInjectionPoint(38);
f7();
FuzzerInjectionPoint(39);