
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Set();
FuzzerInjectionPoint(2);
function f2() {
FuzzerInjectionPoint(3);
    for (let v3 = 0; v3 < 5; v3++) {
FuzzerInjectionPoint(4);
        let v5 = 0;
FuzzerInjectionPoint(5);
        do {
FuzzerInjectionPoint(6);
            v1.d = v5;
FuzzerInjectionPoint(7);
            Math.b = v5;
FuzzerInjectionPoint(8);
            v5++;
FuzzerInjectionPoint(9);
        } while (v5 < 6)
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    return v1;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f2();
FuzzerInjectionPoint(14);
f2();
FuzzerInjectionPoint(15);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(16);
f2();
FuzzerInjectionPoint(17);