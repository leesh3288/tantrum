
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v6 = Array(a3);
FuzzerInjectionPoint(3);
    try { v6.find(a2); } catch (e) {}
FuzzerInjectionPoint(4);
    return f1;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
const t5 = f1();
FuzzerInjectionPoint(7);
t5(10, 10);
FuzzerInjectionPoint(8);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);