
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Uint16Array();
FuzzerInjectionPoint(2);
v1.filter(Float64Array);
FuzzerInjectionPoint(3);