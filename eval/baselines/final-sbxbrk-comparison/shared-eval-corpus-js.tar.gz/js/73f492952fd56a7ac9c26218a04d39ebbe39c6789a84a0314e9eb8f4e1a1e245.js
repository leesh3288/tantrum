
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = { maxByteLength: 38721.29611928039 };
FuzzerInjectionPoint(2);
const v5 = new ArrayBuffer(10, v3);
FuzzerInjectionPoint(3);
const v7 = new Float32Array(v5);
FuzzerInjectionPoint(4);
v7[1] = v7;
FuzzerInjectionPoint(5);
const v9 = new ArrayBuffer(129, v3);
FuzzerInjectionPoint(6);
const v10 = new Uint32Array(v9);
FuzzerInjectionPoint(7);
v10.set(v7);
FuzzerInjectionPoint(8);