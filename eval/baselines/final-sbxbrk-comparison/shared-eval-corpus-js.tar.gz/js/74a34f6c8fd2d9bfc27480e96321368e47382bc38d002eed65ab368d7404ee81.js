
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v6 = new ArrayBuffer(257, { maxByteLength: 795 });
FuzzerInjectionPoint(2);
const v7 = new Int8Array(v6);
FuzzerInjectionPoint(3);
const v12 = new SharedArrayBuffer(257, { maxByteLength: 65537 });
FuzzerInjectionPoint(4);
const v13 = new Uint8ClampedArray(v12);
FuzzerInjectionPoint(5);
v7.set(v13);
FuzzerInjectionPoint(6);