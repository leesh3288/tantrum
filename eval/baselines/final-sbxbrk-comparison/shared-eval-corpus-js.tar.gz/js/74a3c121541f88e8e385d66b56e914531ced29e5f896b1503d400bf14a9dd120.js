
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    Reflect.construct(URIError, URIError, Uint16Array);
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
function f6(a7, a8) {
FuzzerInjectionPoint(6);
    new F0();
FuzzerInjectionPoint(7);
    return f6;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v10 = f6();
FuzzerInjectionPoint(10);
const v11 = f6();
FuzzerInjectionPoint(11);
%OptimizeMaglevOnNextCall(v10);
FuzzerInjectionPoint(12);
v11();
FuzzerInjectionPoint(13);