
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Date();
FuzzerInjectionPoint(2);
v2.setUTCDate(-23192);
FuzzerInjectionPoint(3);
Date[v2];
FuzzerInjectionPoint(4);