
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
-5 > -1422665183n;
FuzzerInjectionPoint(2);