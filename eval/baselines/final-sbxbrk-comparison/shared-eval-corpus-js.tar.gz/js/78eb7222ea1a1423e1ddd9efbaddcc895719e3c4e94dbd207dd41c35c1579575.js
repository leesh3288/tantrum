
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = constructor();
FuzzerInjectionPoint(2);
const v3 = v1.Intl.PluralRules;
FuzzerInjectionPoint(3);
const v4 = new v3();
FuzzerInjectionPoint(4);
const v5 = v4.select;
FuzzerInjectionPoint(5);
try { v5(v5, v1, v3); } catch (e) {}
FuzzerInjectionPoint(6);