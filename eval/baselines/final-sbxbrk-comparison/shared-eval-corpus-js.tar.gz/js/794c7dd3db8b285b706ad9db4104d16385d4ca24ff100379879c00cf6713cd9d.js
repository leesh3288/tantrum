
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    return f0;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f3(a4, a5) {
FuzzerInjectionPoint(5);
    const v8 = new SharedArrayBuffer(862);
FuzzerInjectionPoint(6);
    const v10 = new DataView(v8);
FuzzerInjectionPoint(7);
    let v11 = v10.getUint8();
FuzzerInjectionPoint(8);
    Object.defineProperty(f0, 82, { writable: true, enumerable: true, value: 247 });
FuzzerInjectionPoint(9);
    v11++;
FuzzerInjectionPoint(10);
    return 247;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
class C14 {

    constructor(a16, a17) {
FuzzerInjectionPoint(14);
        const t13 = this.e;
FuzzerInjectionPoint(15);
        const v20 = this.e(a17, t13());
FuzzerInjectionPoint(16);
        %OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(17);
        f3(this, v20);
FuzzerInjectionPoint(18);
    }

    e = f3;

}
FuzzerInjectionPoint(21);
new C14();