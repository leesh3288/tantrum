
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = constructor().Intl;
FuzzerInjectionPoint(2);
const v4 = v3.Segmenter;
FuzzerInjectionPoint(3);
try { v4.supportedLocalesOf(v3, null); } catch (e) {}
FuzzerInjectionPoint(4);