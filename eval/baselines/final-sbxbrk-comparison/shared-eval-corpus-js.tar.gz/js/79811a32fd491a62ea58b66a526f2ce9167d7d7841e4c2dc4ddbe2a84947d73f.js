
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    function F3(a5, a6) {
FuzzerInjectionPoint(3);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(4);
        a5 >= a5;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    new F3(-321066.4472580489);
FuzzerInjectionPoint(7);
    new F3();
FuzzerInjectionPoint(8);
    return f1;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v10 = f1();
FuzzerInjectionPoint(11);
f1();
FuzzerInjectionPoint(12);
const v12 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(13);
function f13(a14, a15) {
FuzzerInjectionPoint(14);
    %OptimizeFunctionOnNextCall(v10);
FuzzerInjectionPoint(15);
    v10();
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
v12.toString = f13;
FuzzerInjectionPoint(18);
class C17 extends Set {

    [v12] = v12;

}