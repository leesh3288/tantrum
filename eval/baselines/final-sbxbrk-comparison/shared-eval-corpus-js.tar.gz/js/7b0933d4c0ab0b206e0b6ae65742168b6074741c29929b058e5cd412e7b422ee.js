
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    let v3 = 10;
FuzzerInjectionPoint(3);
    for (; v3--;) {
FuzzerInjectionPoint(4);
        function f5() {
FuzzerInjectionPoint(5);
            const v6 = [3,2147483648,1073741824,8471,-579631482,12,10,0,-5];
FuzzerInjectionPoint(6);
            Object.defineProperty(v6, 9007199254740990, { writable: true, configurable: true, value: v6 });
FuzzerInjectionPoint(7);
            return f5;
FuzzerInjectionPoint(8);
        }
FuzzerInjectionPoint(9);
        f5();
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    class C9 extends Set {

        constructor(a11, a12, a13, a14) {
FuzzerInjectionPoint(13);
            const t12 = "n";
FuzzerInjectionPoint(14);
            t12.length ??= v3;
FuzzerInjectionPoint(15);
        }

    }
FuzzerInjectionPoint(17);
    return f0;
FuzzerInjectionPoint(18);
}
FuzzerInjectionPoint(19);
f0(f0, f0);
FuzzerInjectionPoint(20);
const v17 = f0();
FuzzerInjectionPoint(21);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(22);
f0(v17, f0);