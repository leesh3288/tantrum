
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new SharedArrayBuffer(85, { maxByteLength: 85 });
FuzzerInjectionPoint(2);
const v6 = new Int8Array(v4);
FuzzerInjectionPoint(3);
v6.lastIndexOf(v4, 85);
FuzzerInjectionPoint(4);