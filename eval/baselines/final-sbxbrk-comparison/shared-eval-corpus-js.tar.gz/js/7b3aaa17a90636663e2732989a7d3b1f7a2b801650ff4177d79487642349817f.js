
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f6(a7, a8, a9, a10) {
FuzzerInjectionPoint(2);
    const v13 = {

        set b(a12) {
FuzzerInjectionPoint(4);
        },

    };
FuzzerInjectionPoint(6);
    return a8;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f6(-439848.9526752329, "6", -439848.9526752329, -5.535831814068191);
FuzzerInjectionPoint(9);
f6(1.0, "object", -439848.9526752329, 1.0);
FuzzerInjectionPoint(10);
const v16 = ("object")["TfR3D"];
FuzzerInjectionPoint(11);
try {
FuzzerInjectionPoint(12);
    f6("6", "object", v16, 1.0);
FuzzerInjectionPoint(13);
} catch(e18) {
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
f6(1.0, "6", 1.0, -439848.9526752329);
FuzzerInjectionPoint(16);
[-5.0,9.567460294311706e+307,868.6998575276511,4.0,2.0,989.7576301331114,-1000000000.0,-335764.55326560175,-216462.3762910742,1e-15];
FuzzerInjectionPoint(17);
[-1000000000.0];
FuzzerInjectionPoint(18);
[-0.14560709830807994,161952.3397189465,-3.0,0.4506227251002559,2.220446049250313e-16,7.5731385572145165,439.19361685382205,-4.446277710837478];
FuzzerInjectionPoint(19);
[-2.220446049250313e-16,Infinity];
FuzzerInjectionPoint(20);
[296.0787200936786,322589.5493588364,67.49453475334894,0.0,1e-15,0.5058920090213426,52898.10915497248];
FuzzerInjectionPoint(21);
[-1.0,-Infinity,424.27677821461,-1e-15,2.8458125103726957];
FuzzerInjectionPoint(22);
const v28 = new Uint8ClampedArray(1);
FuzzerInjectionPoint(23);
const v30 = 128 >>> 128;
FuzzerInjectionPoint(24);
Uint8ClampedArray.d = Uint8ClampedArray;
FuzzerInjectionPoint(25);
const v31 = (1)?.forEach;
FuzzerInjectionPoint(26);
try { v31(v28); } catch (e) {}
FuzzerInjectionPoint(27);
const v33 = new Uint8ClampedArray(128);
FuzzerInjectionPoint(28);
try { BigInt64Array(1, v30, v33); } catch (e) {}
FuzzerInjectionPoint(29);
const t28 = BigInt64Array?.constructor;
FuzzerInjectionPoint(30);
t28();