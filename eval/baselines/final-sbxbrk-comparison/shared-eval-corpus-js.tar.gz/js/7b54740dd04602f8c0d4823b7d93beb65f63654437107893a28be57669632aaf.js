
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    const v3 = new Int32Array();
FuzzerInjectionPoint(3);
    const v4 = v3.length;
FuzzerInjectionPoint(4);
    v4 < v4;
FuzzerInjectionPoint(5);
    return a1;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f0(f0);
FuzzerInjectionPoint(8);
f0(f0);
FuzzerInjectionPoint(9);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(10);
f0();
FuzzerInjectionPoint(11);