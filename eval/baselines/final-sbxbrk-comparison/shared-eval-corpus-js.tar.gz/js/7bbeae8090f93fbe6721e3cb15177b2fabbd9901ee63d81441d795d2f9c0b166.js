
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3, a4, a5) {

    ~Math;

    "asyncDispose" < Float32Array;

    const v10 = Symbol.dispose;

    const v12 = {

        [v10]() {

        },

    };

    using v13 = v12;

    return v12;

}

f2();

f2("asyncDispose", Float32Array, "asyncDispose");

%OptimizeFunctionOnNextCall(f2);

f2();