
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
const v1 = [v0,v0];
FuzzerInjectionPoint(3);
try { JSON.parse(v1); } catch (e) {}
FuzzerInjectionPoint(4);