
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    return 6;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v2 = /zg/mdv;
FuzzerInjectionPoint(5);
function f3(a4, a5) {
FuzzerInjectionPoint(6);
    a4.exec = f1;
FuzzerInjectionPoint(7);
    return a4;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f3[Symbol.species] = f3;
FuzzerInjectionPoint(10);
Uint8Array.constructor = f3;
FuzzerInjectionPoint(11);
const v10 = v2[Symbol.split];
FuzzerInjectionPoint(12);
try { v10.call(Uint8Array); } catch (e) {}
FuzzerInjectionPoint(13);