
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = `
FuzzerInjectionPoint(2);
    class C1 {

    }
FuzzerInjectionPoint(4);
`;
FuzzerInjectionPoint(5);
eval(v0);