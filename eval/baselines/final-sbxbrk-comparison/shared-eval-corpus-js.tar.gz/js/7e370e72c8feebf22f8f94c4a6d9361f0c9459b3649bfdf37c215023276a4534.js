
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
const v1 = [-366826.721786716,-1.7976931348623157e+308,0.6984290895420702,-1e-15,-7.354925890901989e+307,-9.241133795578273,0.727547165575758];
FuzzerInjectionPoint(4);
function f2(a3) {
FuzzerInjectionPoint(5);
    function f4(a5, a6) {
FuzzerInjectionPoint(6);
        return C0;
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    const v8 = new Promise(f4);
FuzzerInjectionPoint(9);
    v8.catch(C0, v1);
FuzzerInjectionPoint(10);
    return C0;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
f2(f2);
FuzzerInjectionPoint(13);
f2();
FuzzerInjectionPoint(14);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(15);
f2(f2);