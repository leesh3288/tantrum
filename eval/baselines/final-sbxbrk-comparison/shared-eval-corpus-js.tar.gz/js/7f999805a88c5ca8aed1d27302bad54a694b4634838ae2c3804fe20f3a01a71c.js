
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-487941734,-51124,-20325];
FuzzerInjectionPoint(2);
const v1 = { ...v0 };
FuzzerInjectionPoint(3);