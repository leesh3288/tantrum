
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-2147483649,11,318719596,1];
FuzzerInjectionPoint(2);
const v1 = { __proto__: v0 };
FuzzerInjectionPoint(3);
const v4 = new Float64Array(1621);
FuzzerInjectionPoint(4);
v4.sort(v4.set(v1));
FuzzerInjectionPoint(5);