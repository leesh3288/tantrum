
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = /a||bc/mdvg;
FuzzerInjectionPoint(2);
const v1 = /wP\u{12345}\u{23456}/vsgi;
FuzzerInjectionPoint(3);
function F2(a4, a5) {
FuzzerInjectionPoint(4);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(5);
    const t4 = a5.constructor;
FuzzerInjectionPoint(6);
    t4(v1, v1);
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
try { new F2(v0, F2); } catch (e) {}
FuzzerInjectionPoint(9);