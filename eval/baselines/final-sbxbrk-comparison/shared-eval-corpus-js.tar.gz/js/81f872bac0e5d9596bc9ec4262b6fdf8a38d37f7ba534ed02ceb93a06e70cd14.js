
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    9n >= 9n;
FuzzerInjectionPoint(3);
    return 9n;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f0(f0, f0);
FuzzerInjectionPoint(6);
f0();
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);