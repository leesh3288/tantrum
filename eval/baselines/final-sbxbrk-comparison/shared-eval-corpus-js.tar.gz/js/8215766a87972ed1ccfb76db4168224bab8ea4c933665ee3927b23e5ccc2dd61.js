
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    return f0;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v1 = [536870887,9223372036854775807,-1,-62483,-9007199254740991,-33305];
FuzzerInjectionPoint(5);
const v3 = `
FuzzerInjectionPoint(6);
    f0 = f0;
FuzzerInjectionPoint(7);
`;
FuzzerInjectionPoint(8);
const v5 = JSON.stringify(v1, 2, v3);
FuzzerInjectionPoint(9);
const v7 = Uint8Array.constructor;
FuzzerInjectionPoint(10);
try { v7(v5, f0); } catch (e) {}
FuzzerInjectionPoint(11);