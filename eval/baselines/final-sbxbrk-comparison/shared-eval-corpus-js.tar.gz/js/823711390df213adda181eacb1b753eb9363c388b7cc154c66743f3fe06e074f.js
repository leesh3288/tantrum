
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

}

class C4 extends Array {

}

const v6 = { type: "function" };

class C9 extends f0 {

    p(a11) {

        let v13 = undefined;

        a11 in this;

        const v15 = %WasmStruct();

        this[Symbol] = this;

        v13 = -1041534711;

        return false;

    }

    static #f;

    #d = -1041534711;

    static [-1041534711] = f0;

    #b;

    static 4085049658 = C4;

    static b = C4;

    static #g;

    [-1041534711] = -26495;

}

C9[C9] = "valueOf";

C9[C9] = C9;

const t25 = {};

t25.a = v6;

const v19 = {};

v19.a = v6;

v19.e = 2147483648;

const v20 = {};

v20.a = v6;

v20.e = 2147483648;

v20.f = -26495;

const v21 = {};

v21.a = v6;

v21.e = 2147483648;

v21.f = v6;

function f23(a24, a25) {

    return a24;

}

function f26(a27, a28, a29) {

    [-1000000000000.0,-367.81301734010196,-476.74454452527516,-2.6076772957175923e+306,1.7976931348623157e+308,0.11176331082589741,Infinity,1000000.0];

    const t42 = 2147483648;

    t42();

}

new Uint16Array();

[];

function F43(a45, a46) {

    if (!new.target) { throw 'must be called with new'; }

    a45--;

    let v48 = -8.579397776936135e+306;

    --v48;

    [-1838,908941924,-61700,268435440,-15,-7920,65536,-4096,-13,37974];

    function f51() {

    }

}

function f52() {

}

class C53 extends Uint32Array {

    constructor(a55, a56, a57) {

    }

}

gc();

function f60() {

    const v61 = {};

    try {

    } catch(e62) {

    }

}

const v63 = {};

const v64 = {};

function f65() {

}

const v73 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x07,

    0x01, 0x60, 0x03, 0x7D, 0x7D, 0x7C, 0x00, 0x03, 0x02, 0x01,

    0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00, 0x06, 0x01, 0x00,

    0x07, 0x06, 0x01, 0x02, 0x77, 0x30, 0x00, 0x00, 0x09, 0x01,

    0x00, 0x0A, 0x32, 0x01, 0x30, 0x03, 0x01, 0x7B, 0x01, 0x7B,

    0x01, 0x7B, 0xFD, 0x0C, 0x4C, 0x43, 0xC4, 0xDC, 0x76, 0xFB,

    0x84, 0x3F, 0x1D, 0xB8, 0xDC, 0xBF, 0x52, 0x33, 0x33, 0xB5,

    0x21, 0x03, 0x20, 0x03, 0x20, 0x03, 0xFD, 0xE5, 0x01, 0x01,

    0x21, 0x04, 0x20, 0x03, 0x20, 0x04, 0xFD, 0x82, 0x01, 0x01,

    0x21, 0x05, 0x0B,

])));

v73.exports.w0();