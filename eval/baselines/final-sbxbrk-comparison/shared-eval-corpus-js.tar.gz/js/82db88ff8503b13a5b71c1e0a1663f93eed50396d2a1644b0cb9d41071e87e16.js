
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
JSON.parse(-149541.003488546);
FuzzerInjectionPoint(2);