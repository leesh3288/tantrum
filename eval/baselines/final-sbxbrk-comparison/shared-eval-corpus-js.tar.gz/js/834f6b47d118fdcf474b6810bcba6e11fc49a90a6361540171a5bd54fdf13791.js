
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {

    function f3(a4) {

        return a1();

    }

    Object.defineProperty(this, "onmessage", { enumerable: true, get: f3 });

    return f0;

}

const v9 = new Worker(f0, { type: "function" });

v9["getMessage"]();