
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v1 = /\11a/mdsgi;
FuzzerInjectionPoint(3);
    SharedArrayBuffer.c = SharedArrayBuffer;
FuzzerInjectionPoint(4);
    SharedArrayBuffer.__proto__ = v1;
FuzzerInjectionPoint(5);
    return f0;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v3 = f0();
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);
const v6 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(10);
function f7(a8, a9) {
FuzzerInjectionPoint(11);
    %OptimizeFunctionOnNextCall(v3);
FuzzerInjectionPoint(12);
    v3();
FuzzerInjectionPoint(13);
    return a8;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
v6.toString = f7;
FuzzerInjectionPoint(16);
class C11 extends Set {

    [v6] = v6;

}