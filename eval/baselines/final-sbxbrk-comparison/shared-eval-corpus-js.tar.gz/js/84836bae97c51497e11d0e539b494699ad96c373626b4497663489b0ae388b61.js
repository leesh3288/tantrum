
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3) {
FuzzerInjectionPoint(2);
    return a3;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v4 = new Date();
FuzzerInjectionPoint(5);
try { v4.setUTCMonth(f2, -521026537n); } catch (e) {}
FuzzerInjectionPoint(6);