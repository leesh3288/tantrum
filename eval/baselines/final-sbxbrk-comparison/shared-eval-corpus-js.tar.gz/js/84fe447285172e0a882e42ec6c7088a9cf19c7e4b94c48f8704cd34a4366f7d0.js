
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [[-12338,1024,-1,13146]];
FuzzerInjectionPoint(2);
class C2 {

    static {
FuzzerInjectionPoint(4);
        this.__proto__ = v1;
FuzzerInjectionPoint(5);
    }

    constructor() {
FuzzerInjectionPoint(7);
        for (let v5 = 0; v5 < 5; v5++) {
FuzzerInjectionPoint(8);
            v1[v5] = v5;
FuzzerInjectionPoint(9);
        }
FuzzerInjectionPoint(10);
    }

}
FuzzerInjectionPoint(12);
new C2();