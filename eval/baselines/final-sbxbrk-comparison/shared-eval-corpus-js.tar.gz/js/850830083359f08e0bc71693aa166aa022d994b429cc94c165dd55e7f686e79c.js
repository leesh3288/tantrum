
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    return {};
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
class C2 {

}
FuzzerInjectionPoint(6);
const v5 = new Proxy(C2, { setPrototypeOf: f0 });
FuzzerInjectionPoint(7);
v5.__proto__ = f0;