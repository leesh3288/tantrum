
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F1(a3, a4) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f5() {
FuzzerInjectionPoint(5);
    const t4 = "v";
FuzzerInjectionPoint(6);
    delete t4[512];
FuzzerInjectionPoint(7);
    Reflect.construct(F1, [Reflect,F1], f5);
FuzzerInjectionPoint(8);
    new Uint32Array(5);
FuzzerInjectionPoint(9);
    new Uint16Array(3898);
FuzzerInjectionPoint(10);
    new Uint8Array(9);
FuzzerInjectionPoint(11);
    return f5;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
function f19() {
FuzzerInjectionPoint(14);
    const v20 = new f5();
FuzzerInjectionPoint(15);
    typeof v20 === "undefined";
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
f19();
FuzzerInjectionPoint(18);
f19();
FuzzerInjectionPoint(19);
%OptimizeMaglevOnNextCall(f19);
FuzzerInjectionPoint(20);
f19();
FuzzerInjectionPoint(21);