
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    /TB(?<a>.)\k<a>abc|def|ghi(ab)\1[\cA](?:a{5,1000000}){3,1000000}/mudgy;
FuzzerInjectionPoint(3);
    const v5 = Array(122);
FuzzerInjectionPoint(4);
    v5.fill(f0);
FuzzerInjectionPoint(5);
    /TB(?<a>.)\k<a>abc|def|ghi(ab)\1[\cA](?:a{5,1000000}){3,1000000}/mudgy;
FuzzerInjectionPoint(6);
    [1000000000.0,185453.66805808875,887.1083108101639,-Infinity,2.2250738585072014e-308,-9.96501636426367e+307];
FuzzerInjectionPoint(7);
    const v9 = { __proto__: v5 };
FuzzerInjectionPoint(8);
    const v10 = v9.toLocaleString(f0, v9);
FuzzerInjectionPoint(9);
    return v10.match(v10);
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
try { f0(); } catch (e) {}
FuzzerInjectionPoint(12);