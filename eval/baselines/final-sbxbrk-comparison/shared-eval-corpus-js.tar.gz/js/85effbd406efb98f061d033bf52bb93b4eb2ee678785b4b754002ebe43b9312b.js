
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v6 = {

        set a(a5) {
FuzzerInjectionPoint(4);
        },

    };
FuzzerInjectionPoint(6);
    return v6;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
const v7 = f0(f0, f0, f0);
FuzzerInjectionPoint(9);
function f8(a9, a10, a11) {
FuzzerInjectionPoint(10);
    function f12() {
FuzzerInjectionPoint(11);
        for (let v13 = 0; v13 < 5; v13++) {
FuzzerInjectionPoint(12);
            v13++;
FuzzerInjectionPoint(13);
            const v15 = v13 - v13;
FuzzerInjectionPoint(14);
            const v16 = v7?.constructor;
FuzzerInjectionPoint(15);
            try { v16(v7, v7, v7, v7); } catch (e) {}
FuzzerInjectionPoint(16);
            let v20 = new BigUint64Array();
FuzzerInjectionPoint(17);
            function f24(a25) {
FuzzerInjectionPoint(18);
                const v29 = {

                    __proto__: -4294967295,

                    f: a25,

                    [-4294967295](a27) {
FuzzerInjectionPoint(22);
                        a25();
FuzzerInjectionPoint(23);
                    },

                };
FuzzerInjectionPoint(25);
                let v30;
FuzzerInjectionPoint(26);
                try { v30 = v29.toString(f24); } catch (e) {}
FuzzerInjectionPoint(27);
                [10,-2147483649];
FuzzerInjectionPoint(28);
                [-9007199254740990,536870887,8];
FuzzerInjectionPoint(29);
                v30[[4294967297,-15,39470]] >>>= 255;
FuzzerInjectionPoint(30);
                v20 ??= v20;
FuzzerInjectionPoint(31);
                v30.padStart();
FuzzerInjectionPoint(32);
                return f0;
FuzzerInjectionPoint(33);
            }
FuzzerInjectionPoint(34);
            try { f24(-163530867, 127); } catch (e) {}
FuzzerInjectionPoint(35);
            const v36 = [-9.281820383163979,-844.3088521549797,2.0,-2.220446049250313e-16,0.6395567114098742];
FuzzerInjectionPoint(36);
            const v37 = [0.6272003961623817,-1000000.0,0.4591495940964663,2.220446049250313e-16,1000000000.0,-1.0,-792481.1024104208,3.009228372555967e+307];
FuzzerInjectionPoint(37);
            try { v37.copyWithin(); } catch (e) {}
FuzzerInjectionPoint(38);
            function f39() {
FuzzerInjectionPoint(39);
                return v36;
FuzzerInjectionPoint(40);
            }
FuzzerInjectionPoint(41);
            try {
FuzzerInjectionPoint(42);
                f39();
FuzzerInjectionPoint(43);
            } catch(e41) {
FuzzerInjectionPoint(44);
            }
FuzzerInjectionPoint(45);
            v15 << v15;
FuzzerInjectionPoint(46);
        }
FuzzerInjectionPoint(47);
        return a9;
FuzzerInjectionPoint(48);
    }
FuzzerInjectionPoint(49);
    f12();
FuzzerInjectionPoint(50);
    return f8;
FuzzerInjectionPoint(51);
}
FuzzerInjectionPoint(52);
f8();
FuzzerInjectionPoint(53);
f8();
FuzzerInjectionPoint(54);
%OptimizeFunctionOnNextCall(f8);
FuzzerInjectionPoint(55);
f8();