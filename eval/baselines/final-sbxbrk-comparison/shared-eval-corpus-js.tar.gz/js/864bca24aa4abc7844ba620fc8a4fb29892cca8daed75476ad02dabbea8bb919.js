
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    function f1(a2, a3, a4, a5) {
FuzzerInjectionPoint(3);
        function f6(a7) {
FuzzerInjectionPoint(4);
            return f1;
FuzzerInjectionPoint(5);
        }
FuzzerInjectionPoint(6);
        a2.toString = f6;
FuzzerInjectionPoint(7);
        return a2 > a2;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    try { f1(f1); } catch (e) {}
FuzzerInjectionPoint(10);
    return f0;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
f0();
FuzzerInjectionPoint(13);
f0();
FuzzerInjectionPoint(14);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(15);
f0();
FuzzerInjectionPoint(16);