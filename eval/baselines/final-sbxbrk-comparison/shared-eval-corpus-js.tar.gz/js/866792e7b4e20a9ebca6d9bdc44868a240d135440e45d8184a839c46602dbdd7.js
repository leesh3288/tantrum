
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    function f3(a4, a5) {
FuzzerInjectionPoint(3);
        return f3;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    class C6 {

    }
FuzzerInjectionPoint(7);
    const v7 = [1000000000000.0,1.707640977331252];
FuzzerInjectionPoint(8);
    function f8(a9, a10) {
FuzzerInjectionPoint(9);
        const v12 = Array();
FuzzerInjectionPoint(10);
        const v13 = { __proto__: v12 };
FuzzerInjectionPoint(11);
        const v15 = Symbol.isConcatSpreadable;
FuzzerInjectionPoint(12);
        v13[v15] = f3;
FuzzerInjectionPoint(13);
        const v16 = v13.concat();
FuzzerInjectionPoint(14);
        v16[0] = C6;
FuzzerInjectionPoint(15);
        v16.push(v7);
FuzzerInjectionPoint(16);
        return v15;
FuzzerInjectionPoint(17);
    }
FuzzerInjectionPoint(18);
    f8();
FuzzerInjectionPoint(19);
    return f8();
FuzzerInjectionPoint(20);
}
FuzzerInjectionPoint(21);
f0(f0, f0(f0, f0));
FuzzerInjectionPoint(22);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(23);
f0();