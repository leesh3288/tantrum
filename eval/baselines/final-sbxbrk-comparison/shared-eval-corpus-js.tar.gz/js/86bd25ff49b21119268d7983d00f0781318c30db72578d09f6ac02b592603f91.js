
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    static #p(a5) {

        [10,255,16];

        [128,-1,6,50929,10,-1436946049,-12,-55747];

        [-2147483649];

        return -4096;

    }

    static {

        function f10() {

            function f12(a13) {

                this[arguments] ??= -4096;

            }

            this.onmessage = f12;

            f12(-745027.2486962036);

            this.onmessage;

        }

        const v19 = [];

        new Worker(f10, { arguments: v19, type: "function" });

    }

}

new C3();

const v23 = new C3();

new C3();

function F28(a30, a31, a32) {

    if (!new.target) { throw 'must be called with new'; }

    this.d = a30;

    this.g = a32;

    this.f = a30;

}

new F28(15, 15, 13);

new F28(13, 15, 15);

new F28(13, 13, 13);

new Int8Array(1676);

new Uint32Array(243);

new Int32Array(3);

const v58 = {

    valueOf(a46) {

        const v57 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

            0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0E,

            0x01, 0x60, 0x09, 0x7F, 0x7C, 0x7D, 0x7C, 0x7C, 0x7F, 0x7C,

            0x7C, 0x7D, 0x01, 0x7D, 0x03, 0x02, 0x01, 0x00, 0x04, 0x01,

            0x00, 0x05, 0x01, 0x00, 0x06, 0x01, 0x00, 0x07, 0x06, 0x01,

            0x02, 0x77, 0x30, 0x00, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x04,

            0x01, 0x02, 0x00, 0x0B,

        ])));

        return v57;

    },

};

new Uint32Array(15, F28 >> v23, 1676);

const v65 = Uint32Array.toString();

try { v65.codePointAt(v58); } catch (e) {}