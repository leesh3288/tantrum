
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = __proto__.constructor();
FuzzerInjectionPoint(2);
function f2() {
FuzzerInjectionPoint(3);
    function f4(a5) {
FuzzerInjectionPoint(4);
        -(a5 & a5);
FuzzerInjectionPoint(5);
        return -4294967295;
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    f4(-4294967295);
FuzzerInjectionPoint(8);
    return __proto__;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v9 = f2.prototype;
FuzzerInjectionPoint(11);
v9.constructor(__proto__, f2, v1, v9, v1);
FuzzerInjectionPoint(12);
f2();
FuzzerInjectionPoint(13);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(14);
f2();
FuzzerInjectionPoint(15);