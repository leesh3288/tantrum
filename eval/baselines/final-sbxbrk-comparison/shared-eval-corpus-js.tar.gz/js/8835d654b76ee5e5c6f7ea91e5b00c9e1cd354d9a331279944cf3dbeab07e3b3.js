
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f5() {
FuzzerInjectionPoint(2);
    const v8 = Array(103);
FuzzerInjectionPoint(3);
    v8[103] = -0.0;
FuzzerInjectionPoint(4);
    [-1e-15,906.3820157808566,1000000.0,-19504.868524338817,-2.7967137025373567,-4.514949428413207];
FuzzerInjectionPoint(5);
    function f11(a12, a13, a14) {
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    const v15 = v8[7];
FuzzerInjectionPoint(8);
    v15 ?? v15;
FuzzerInjectionPoint(9);
    g = v15;
FuzzerInjectionPoint(10);
    let v18 = 16453;
FuzzerInjectionPoint(11);
    ++v18;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
const v20 = f5();
FuzzerInjectionPoint(14);
f5();
FuzzerInjectionPoint(15);
%OptimizeMaglevOnNextCall(f5);
FuzzerInjectionPoint(16);
new BigInt64Array();
FuzzerInjectionPoint(17);
/(?:a?)+(?!\1(a\1)\1)\1/dvs;
FuzzerInjectionPoint(18);
/\p{gc=Nd}(\1a)w(?<a>)(.3a||bc)/ugi;
FuzzerInjectionPoint(19);
function f30() {
FuzzerInjectionPoint(20);
    let v31 = [-268435456,12,268435439,14141,19968442,64,56122303,7];
FuzzerInjectionPoint(21);
    for (let v32 = 0; v32 < 5; v32++) {
FuzzerInjectionPoint(22);
        v31 ^ v31;
FuzzerInjectionPoint(23);
        v31++;
FuzzerInjectionPoint(24);
    }
FuzzerInjectionPoint(25);
    const v35 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

        0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

        0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00,

        0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A,

        0x01, 0x00,

    ])));
FuzzerInjectionPoint(31);
}
FuzzerInjectionPoint(32);
f30();
FuzzerInjectionPoint(33);
%OptimizeMaglevOnNextCall(f30);
FuzzerInjectionPoint(34);
f5();
FuzzerInjectionPoint(35);
const v38 = { has: v20 };