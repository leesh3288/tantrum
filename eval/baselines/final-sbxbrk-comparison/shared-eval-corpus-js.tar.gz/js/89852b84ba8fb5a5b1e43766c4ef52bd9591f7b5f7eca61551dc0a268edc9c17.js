
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = this.DisposableStack.prototype.defer;

try { v4.call(-1073741824); } catch (e) {}