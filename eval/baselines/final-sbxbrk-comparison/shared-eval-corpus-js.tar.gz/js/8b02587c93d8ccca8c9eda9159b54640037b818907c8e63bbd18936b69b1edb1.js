
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
Math.sinh(([-379.63557389864764,-9969.356563432724,1.7976931348623157e+308,7.635636502150863,1.0,-Infinity,1.075075513877374e+308]).toLocaleString());
FuzzerInjectionPoint(2);