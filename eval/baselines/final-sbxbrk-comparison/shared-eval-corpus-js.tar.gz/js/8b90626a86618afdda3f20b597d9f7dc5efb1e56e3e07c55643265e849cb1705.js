
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v6 = a4 ^ Int32Array;
FuzzerInjectionPoint(3);
    const v7 = Math.sign(v6);
FuzzerInjectionPoint(4);
    let v8 = v7 - v7;
FuzzerInjectionPoint(5);
    const v9 = {};
FuzzerInjectionPoint(6);
    v8--;
FuzzerInjectionPoint(7);
    for (let v11 = 0; v11 < 5; v11++) {
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    return v8 * v6;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f1();
FuzzerInjectionPoint(12);
f1();
FuzzerInjectionPoint(13);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(14);
f1();
FuzzerInjectionPoint(15);