
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = /Fxa\nb\bcLGd(?!\1(a\1)\1)\1/sgiy;
FuzzerInjectionPoint(2);
function f2(a3, a4) {
FuzzerInjectionPoint(3);
    return a3;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
v1[Symbol.toPrimitive] = f2;
FuzzerInjectionPoint(6);
const v9 = constructor().Intl;
FuzzerInjectionPoint(7);
v9.language = "symbol";
FuzzerInjectionPoint(8);
const t7 = v9.Locale;
FuzzerInjectionPoint(9);
new t7(v1, v9);
FuzzerInjectionPoint(10);