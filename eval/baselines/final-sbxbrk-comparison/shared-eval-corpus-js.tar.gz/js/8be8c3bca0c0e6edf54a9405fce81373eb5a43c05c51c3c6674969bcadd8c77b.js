
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[0.8786173865510243];

let v5 = [-1e-15,-0.0,-3.0,0.0,3.8832168571630383,2.0];

[-1.0,1000000000000.0,-1.6598587515105448e+308,2.220446049250313e-16,1000.0];

const v13 = [];

const v17 = [-268435456,35055,-4294967297,561981768,-21132,-1];

const v18 = [16,-9007199254740991,268435440,-43214,1751605062];

const v19 = [-10897,4294967296,255,-36080,1,9,-1024];

class C21 {

}

function f22(a23, a24, a25) {

    a25 >>> a25;

    a23.caller;

    a23.g = a23;

}

v13[2] /= v13;

v17[1];

v18[1073741825] = -576n;

%VerifyType(v17);

delete v18.length;

try { v19.map(); } catch (e) {}

const v38 = 1434125896n * 1434125896n;

class C39 {

    static [v38] = 802548760n;

}

try {

    v19.entries();

} catch(e41) {

}

function f43() {

    return f43;

}

function f45() {

    const v51 = {

        p(a47, a48) {

            this.d = this;

            let v49 = new WebAssembly.Global({ value: "f64", mutable: false }, 4.319357700079234e+307);

            try { v49.valueOf(); } catch (e) {}

            return v49;

        },

    };

    const v53 = v51["p"]();

    try { v53.valueOf(); } catch (e) {}

    const v55 = v53.constructor;

    try { new v55(2147483649); } catch (e) {}

    const v58 = {

        get f() {

            return this;

        },

    };

    return f45;

}

const t51 = f45();

t51();

new BigInt64Array();

function f63(a64, a65, a66) {

    function f68(a69) {

        const v72 = { d: a64 };

        v72.d = v72;

        function f73() {

            function f74(a75) {

                return f73;

            }

            f74.length;

            function f77(a78) {

                return f74;

            }

            function f79(a80, a81, a82) {

                f77 * 23588;

                return a80;

            }

            return f77;

        }

    }

    this.onmessage = f68;

    const t74 = "65537";

    t74.f = this[2147483648];

}

const v89 = [BigInt64Array,-5.0,true];

const v90 = { arguments: v89, type: "function" };

new Worker(f63, v90);

new BigInt64Array();

function f93() {

    return Uint8ClampedArray;

}

[f93];

15315n + 2147483648n;

`4294967295${647512162n}1073741824${f93}bdP${1434125896n}d${v17}arguments`;

try {

} catch(e97) {

    for (let i100 = 0, i101 = 10; i100;) {

    }

}

const v109 = { execution: "async", type: "minor" };

for (let v110 = 0; v110 < 5; v110++) {

    const v112 = "p" + v110;

    const v113 = [8,1024,23499,268435441,268435439,54851];

    class C114 {

    }

    const v117 = [];

    const v122 = {

        h: 9007199254740991,

        valueOf() {

            try { this.reverse(); } catch (e) {}

            try { ("dNd").small(); } catch (e) {}

            const t2 = "dNd";

            t2[2699094064] -= v117;

            return this;

        },

    };

    v122.valueOf(v122, v113, 64, v122, v122);

    const t109 = "p";

    t109.length = v110;

    const t112 = "async";

    t112[v112] = v110;

}

v90.__proto__;

v5 = v89;

v109.execution;

gc(v109).finally(13);

constructor().constructor();