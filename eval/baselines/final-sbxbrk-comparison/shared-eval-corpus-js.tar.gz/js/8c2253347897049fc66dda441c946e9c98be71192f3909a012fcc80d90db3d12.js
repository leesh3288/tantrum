
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3) {
FuzzerInjectionPoint(2);
    return f2;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
with (Date) {
FuzzerInjectionPoint(5);
    const v6 = prototype ?? prototype;
FuzzerInjectionPoint(6);
    function f8(a9, a10, a11) {
FuzzerInjectionPoint(7);
        function f13(a14) {
FuzzerInjectionPoint(8);
            function f15(a16) {
FuzzerInjectionPoint(9);
            }
FuzzerInjectionPoint(10);
            Symbol[Symbol.toPrimitive] = f15;
FuzzerInjectionPoint(11);
            Symbol[Symbol.toPrimitive] = Symbol;
FuzzerInjectionPoint(12);
            Symbol[Symbol.toPrimitive] = Symbol;
FuzzerInjectionPoint(13);
            const v21 = {

                [Symbol]() {
FuzzerInjectionPoint(15);
                },

            };
FuzzerInjectionPoint(17);
            return f8;
FuzzerInjectionPoint(18);
        }
FuzzerInjectionPoint(19);
        f13();
FuzzerInjectionPoint(20);
        f13(a10);
FuzzerInjectionPoint(21);
        f13(4.0);
FuzzerInjectionPoint(22);
        try { prototype(v6, "7", a10, f2); } catch (e) {}
FuzzerInjectionPoint(23);
        f2[92] = a10;
FuzzerInjectionPoint(24);
        let v26 = [-5.0,-1000000000.0,-5.0,-4.94464798038672e+307,33.87806942460543,-0.0,1000.0,-1000000000.0,-194.7794671137351];
FuzzerInjectionPoint(25);
        const v28 = new Int16Array();
FuzzerInjectionPoint(26);
        let v29 = /a\S/dvy;
FuzzerInjectionPoint(27);
        ({"length":v29,...v26} = v28);
FuzzerInjectionPoint(28);
        const v30 = {};
FuzzerInjectionPoint(29);
        v30.e = v29;
FuzzerInjectionPoint(30);
        v30 ** v29;
FuzzerInjectionPoint(31);
        a11 = BigUint64Array;
FuzzerInjectionPoint(32);
        const v33 = new SharedArrayBuffer();
FuzzerInjectionPoint(33);
        new DataView(v33);
FuzzerInjectionPoint(34);
        for (const v36 in 4.0) {
FuzzerInjectionPoint(35);
        }
FuzzerInjectionPoint(36);
        a10 ?? BigUint64Array;
FuzzerInjectionPoint(37);
        BigUint64Array ?? BigUint64Array;
FuzzerInjectionPoint(38);
        BigUint64Array ?? BigUint64Array;
FuzzerInjectionPoint(39);
        BigUint64Array ?? BigUint64Array;
FuzzerInjectionPoint(40);
        BigUint64Array ?? BigUint64Array;
FuzzerInjectionPoint(41);
        a9 | a9;
FuzzerInjectionPoint(42);
        a9 - a9;
FuzzerInjectionPoint(43);
        class C44 {

            #g;

            static #c;

            #h;

        }
FuzzerInjectionPoint(48);
        return Symbol;
FuzzerInjectionPoint(49);
    }
FuzzerInjectionPoint(50);
    f8();
FuzzerInjectionPoint(51);
    f8();
FuzzerInjectionPoint(52);
    %OptimizeFunctionOnNextCall(f8);
FuzzerInjectionPoint(53);
    f8();
FuzzerInjectionPoint(54);
}