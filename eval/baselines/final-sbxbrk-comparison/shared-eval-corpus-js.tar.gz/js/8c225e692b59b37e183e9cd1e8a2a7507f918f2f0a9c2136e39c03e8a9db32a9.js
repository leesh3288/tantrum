
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    #valueOf(a5, a6) {
FuzzerInjectionPoint(3);
        return a5;
FuzzerInjectionPoint(4);
    }

    [-2147483648] = -2147483648;

    #o(a8) {
FuzzerInjectionPoint(7);
        if (a8 != [536870887,65535]) {
FuzzerInjectionPoint(8);
            const t7 = "a";
FuzzerInjectionPoint(9);
            t7.length >>= -1315881693;
FuzzerInjectionPoint(10);
        }
FuzzerInjectionPoint(11);
        return -1315881693;
FuzzerInjectionPoint(12);
    }

}
FuzzerInjectionPoint(14);
const v11 = new C3();
FuzzerInjectionPoint(15);
let v13 = 536870888;
FuzzerInjectionPoint(16);
[-2147483648,v13,["a",v11],-65537,-65537];
FuzzerInjectionPoint(17);
function f16(a17, a18, a19) {
FuzzerInjectionPoint(18);
    class C20 {

    }
FuzzerInjectionPoint(20);
    v13 += a18;
FuzzerInjectionPoint(21);
    try { a18(); } catch (e) {}
FuzzerInjectionPoint(22);
    const v22 = {};
FuzzerInjectionPoint(23);
    const v23 = {};
FuzzerInjectionPoint(24);
    v23.g = a18;
FuzzerInjectionPoint(25);
    v23.e = C20;
FuzzerInjectionPoint(26);
    const t25 = {};
FuzzerInjectionPoint(27);
    t25.g = a18;
FuzzerInjectionPoint(28);
    const v25 = {};
FuzzerInjectionPoint(29);
    let v27;
FuzzerInjectionPoint(30);
    try { v27 = Reflect.has(); } catch (e) {}
FuzzerInjectionPoint(31);
    Symbol.split;
FuzzerInjectionPoint(32);
    return v27;
FuzzerInjectionPoint(33);
}
FuzzerInjectionPoint(34);
f16();
FuzzerInjectionPoint(35);
f16();