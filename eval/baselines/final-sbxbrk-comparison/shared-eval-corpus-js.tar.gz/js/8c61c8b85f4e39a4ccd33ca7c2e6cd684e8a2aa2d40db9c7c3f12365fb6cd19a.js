
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v5 = {

    ...Infinity,

    [-2]: 0.927504582796395,

    g: 5.923190277297278e+307,

    c: -0.0,

    a: -0.0,

    f: 0.927504582796395,

};
FuzzerInjectionPoint(9);
v5[8.689673268815028] = 5.923190277297278e+307;