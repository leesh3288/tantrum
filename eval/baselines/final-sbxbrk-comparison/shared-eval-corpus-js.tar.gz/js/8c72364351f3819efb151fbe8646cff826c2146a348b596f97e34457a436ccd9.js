
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = constructor();
FuzzerInjectionPoint(2);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(3);
    return v1;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
class C6 extends f2 {

    #toString(a8, a9, a10) {
FuzzerInjectionPoint(7);
    }

    static {
FuzzerInjectionPoint(9);
        try {
FuzzerInjectionPoint(10);
            v1.#toString();
FuzzerInjectionPoint(11);
        } catch(e13) {
FuzzerInjectionPoint(12);
        }
FuzzerInjectionPoint(13);
    }

}