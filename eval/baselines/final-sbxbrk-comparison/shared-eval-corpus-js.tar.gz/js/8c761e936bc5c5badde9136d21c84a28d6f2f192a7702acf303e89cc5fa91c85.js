
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-4294967296,14,-4294967295,-4294967296,9,9,-65537,0,129];
FuzzerInjectionPoint(2);
Object.defineProperty(v1, "maximumSignificantDigits", { value: Map });
FuzzerInjectionPoint(3);
function f2(a3, a4) {
FuzzerInjectionPoint(4);
    return a4;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
try { v1.toLocaleString(f2, v1); } catch (e) {}
FuzzerInjectionPoint(7);