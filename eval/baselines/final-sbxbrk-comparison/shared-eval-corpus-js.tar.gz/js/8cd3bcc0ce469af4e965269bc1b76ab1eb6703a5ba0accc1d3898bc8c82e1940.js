
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [0.0,-209.41425397542093,2.0,-696463.5008173722,2.0,2.2250738585072014e-308,-1000000000000.0,2.0,5.0];
FuzzerInjectionPoint(2);
const v3 = Array(122);
FuzzerInjectionPoint(3);
const v4 = [1000000000.0,185453.66805808875,887.1083108101639,-Infinity,2.2250738585072014e-308,-9.96501636426367e+307];
FuzzerInjectionPoint(4);
const v5 = { __proto__: v3, ...v4 };
FuzzerInjectionPoint(5);
v5.unshift(v0);
FuzzerInjectionPoint(6);
parseInt(v5.toLocaleString());
FuzzerInjectionPoint(7);