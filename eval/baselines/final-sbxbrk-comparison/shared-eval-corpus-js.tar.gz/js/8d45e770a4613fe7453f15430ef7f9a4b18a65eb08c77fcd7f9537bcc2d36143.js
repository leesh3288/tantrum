
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = [1e-15,2.0,-103217.19626860146,4.0,-1.729206641487118e+308,0.2862810442021342,-1000000000000.0,-4.0,0.0];

const v4 = [1.0639315188103833,-597.8995836184592,0.06755095721383808,1000.0,1.0160011982838952,-1.7976931348623157e+308,-2.220446049250313e-16,81013.62983084284,241613.78123690793];

const v5 = [-1e-15,-867351.148288137,5.841769826011841,Infinity,-2.2250738585072014e-308];

const v6 = [v3,-2,v4,v3];

try { v6.some(-2); } catch (e) {}

[-9221,v6,v6,-2,v5];

const v9 = [v4,255];

function f13() {

    return v9;

}

f13.arguments = f13;

try { gc(); } catch (e) {}

const v18 = { type: "minor" };

const v20 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x04,

    0x01, 0x60, 0x00, 0x00, 0x03, 0x02, 0x01, 0x00, 0x04, 0x01,

    0x00, 0x05, 0x01, 0x00, 0x06, 0x01, 0x00, 0x07, 0x06, 0x01,

    0x02, 0x77, 0x30, 0x00, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x04,

    0x01, 0x02, 0x00, 0x0B,

])));

const v22 = v20.exports.w0;

const v24 = this.WebAssembly;

const t28 = v24.promising(v22);

t28(v24, this, v18);