
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
function f1(a2, a3) {
FuzzerInjectionPoint(4);
    return f1;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
const v5 = Symbol.iterator;
FuzzerInjectionPoint(7);
C0[v5] = f1;
FuzzerInjectionPoint(8);
function f6(a7, a8, a9, a10) {
FuzzerInjectionPoint(9);
    return C0;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
const v11 = f6(Symbol, v5, C0, v5);
FuzzerInjectionPoint(12);
function f12() {
FuzzerInjectionPoint(13);
    Math.expm1(f1);
FuzzerInjectionPoint(14);
    try { Math.exp(-5.918996314904348, ...v11, ...Math); } catch (e) {}
FuzzerInjectionPoint(15);
    return v5;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
f12();
FuzzerInjectionPoint(18);
f12();
FuzzerInjectionPoint(19);
%OptimizeMaglevOnNextCall(f12);
FuzzerInjectionPoint(20);
f12();