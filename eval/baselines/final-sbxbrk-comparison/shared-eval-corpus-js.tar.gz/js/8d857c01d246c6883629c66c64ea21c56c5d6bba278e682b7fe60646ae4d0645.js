
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f3() {
FuzzerInjectionPoint(2);
    return f3;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v4 = [-2.788471489859754e+305];
FuzzerInjectionPoint(5);
const v5 = [6.282580359395815e+307,5.362750490501087,1.5926202573347826e+306,2.0,2.2250738585072014e-308,-1.7976931348623157e+308,-5.0];
FuzzerInjectionPoint(6);
const v6 = [0.10281860495791983,-882934.3575712838,5.086074806086066e+307,1000000000.0,477.97019146969615,-2.2250738585072014e-308,34410.487750383676,Infinity,-1.1265646683982815e+308];
FuzzerInjectionPoint(7);
const v9 = [-4.0,-5.0,-728231.7208226407,-1e-15,8.165136138200752e+306,5.0,-1000000.0];
FuzzerInjectionPoint(8);
const v10 = [-1000000.0];
FuzzerInjectionPoint(9);
const v11 = [-3.514511838138425e+307,-1.7976931348623157e+308,-1.4515033196894892e+308];
FuzzerInjectionPoint(10);
function f13(a14, a15, a16) {
FuzzerInjectionPoint(11);
    const v21 = {

        h: v10,

        ...v6,

        [2]: 268435456,

        c: a16,

        2: a16,

        b: v11,

        a: 268435439,

        set b(a18) {
FuzzerInjectionPoint(20);
        },

        ...v10,

        e: -4,

        [v9]: a14,

        f: 0.0,

        set a(a20) {
FuzzerInjectionPoint(26);
        },

        deleteProperty: f3,

        [v5]: v11,

        g: -1073741824,

        f: a14,

        __proto__: v4,

        a: v10,

        d: 2,

    };
FuzzerInjectionPoint(35);
    return f3;
FuzzerInjectionPoint(36);
}
FuzzerInjectionPoint(37);
const v22 = f13();
FuzzerInjectionPoint(38);
f13(v11, v22, v22);
FuzzerInjectionPoint(39);
%OptimizeMaglevOnNextCall(f13);
FuzzerInjectionPoint(40);
f13();