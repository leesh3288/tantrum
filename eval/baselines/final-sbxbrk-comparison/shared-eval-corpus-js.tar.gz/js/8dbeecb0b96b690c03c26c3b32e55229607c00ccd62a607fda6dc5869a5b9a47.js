
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [2,-38278,13,257,2];
FuzzerInjectionPoint(2);
const v4 = constructor(v0, BigUint64Array, v0, constructor, constructor).Intl;
FuzzerInjectionPoint(3);
try { v4.getCanonicalLocales(v0); } catch (e) {}
FuzzerInjectionPoint(4);
const v6 = v4.PluralRules;
FuzzerInjectionPoint(5);
const v7 = new v6(v6);
FuzzerInjectionPoint(6);
try { v7.selectRange(BigUint64Array, constructor); } catch (e) {}
FuzzerInjectionPoint(7);