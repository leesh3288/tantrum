
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = constructor.bind();
FuzzerInjectionPoint(2);
function f3() {
FuzzerInjectionPoint(3);
    class C4 {

    }
FuzzerInjectionPoint(5);
    const v5 = /\11/msgiy;
FuzzerInjectionPoint(6);
    v5.Int8Array = v1;
FuzzerInjectionPoint(7);
    with (v5) {
FuzzerInjectionPoint(8);
        C4 instanceof Int8Array;
FuzzerInjectionPoint(9);
    }
FuzzerInjectionPoint(10);
    return f3;
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
f3();
FuzzerInjectionPoint(13);
f3();
FuzzerInjectionPoint(14);
%OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(15);
f3();