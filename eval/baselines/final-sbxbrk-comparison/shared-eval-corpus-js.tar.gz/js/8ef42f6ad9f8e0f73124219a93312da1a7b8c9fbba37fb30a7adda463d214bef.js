
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0(a2, a3) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    const v4 = `
FuzzerInjectionPoint(4);
        for (let v5 = 0; v5 < 5; v5++) {
FuzzerInjectionPoint(5);
        }
FuzzerInjectionPoint(6);
    `;
FuzzerInjectionPoint(7);
    const v6 = v4.toUpperCase();
FuzzerInjectionPoint(8);
    try { eval(v6); } catch (e) {}
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
new F0();
FuzzerInjectionPoint(11);