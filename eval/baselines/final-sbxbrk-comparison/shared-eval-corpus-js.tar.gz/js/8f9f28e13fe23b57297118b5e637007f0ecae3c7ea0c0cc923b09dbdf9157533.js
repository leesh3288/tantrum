
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[10000];
FuzzerInjectionPoint(2);
const v1 = [8,1024,23499,268435441,268435439,54851];

class C7 {

    static [1.5554632819502635e+308] = 1.5554632819502635e+308;

}
FuzzerInjectionPoint(6);
[-596992.2717851705,1.3656356845740762e+308];

247 == 247;

C7.d = C7;
FuzzerInjectionPoint(9);
try { new BigInt64Array(Uint8ClampedArray, BigInt64Array, 9007199254740991); } catch (e) {}
FuzzerInjectionPoint(10);
const v17 = [];
FuzzerInjectionPoint(11);
function f18() {
FuzzerInjectionPoint(12);
    const v23 = {

        a: BigInt64Array,

        [v17]: 3.0,

        h: 9007199254740991,

        ...C7,

        __proto__: v17,

        valueOf() {
FuzzerInjectionPoint(19);
            try { this.reverse(); } catch (e) {}

            try { ("dNd").small(); } catch (e) {}
FuzzerInjectionPoint(21);
            const t2 = "dNd";
FuzzerInjectionPoint(22);
            t2[2699094064] -= v17;
FuzzerInjectionPoint(23);
            return this;
FuzzerInjectionPoint(24);
        },

    };

    try { v23.reduce(64); } catch (e) {}
FuzzerInjectionPoint(27);
    const v25 = v23.valueOf(v23, v1, 64, v23, v23);
FuzzerInjectionPoint(28);
    try { v25.entries(); } catch (e) {}
FuzzerInjectionPoint(29);
}
FuzzerInjectionPoint(30);
f18 ?? f18;
FuzzerInjectionPoint(31);
for (let v28 = 0; v28 < 100; v28++) {
FuzzerInjectionPoint(32);
    const v29 = f18();
FuzzerInjectionPoint(33);
    const v30 = v29 ?? v29;
FuzzerInjectionPoint(34);
    v30 ?? v30;
FuzzerInjectionPoint(35);
}