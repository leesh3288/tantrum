
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F1(a3, a4, a5, a6) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    ("undefined").constructor.fromCharCode(-8335, 2393).normalize();
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
new F1(2393, F1, 2393, 2393);
FuzzerInjectionPoint(6);