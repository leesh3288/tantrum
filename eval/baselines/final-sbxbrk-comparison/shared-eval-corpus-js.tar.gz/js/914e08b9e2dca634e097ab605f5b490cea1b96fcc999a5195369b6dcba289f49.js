
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C5 {

    static #e = 151856190n;

    h;

    #g;

}
FuzzerInjectionPoint(6);
C5.g = C5;
FuzzerInjectionPoint(7);
12n ?? 12n;
FuzzerInjectionPoint(8);
(12n).valueOf("number", 12n);
FuzzerInjectionPoint(9);
C5[C5] = -45021n;
FuzzerInjectionPoint(10);
151856190n ?? 151856190n;
FuzzerInjectionPoint(11);
C5 ?? C5;
FuzzerInjectionPoint(12);
C5 ?? C5;
FuzzerInjectionPoint(13);
const v11 = {};
FuzzerInjectionPoint(14);
v11.h = v11;
FuzzerInjectionPoint(15);
let v13;
FuzzerInjectionPoint(16);
try { v13 = Proxy.revocable(151856190n, 12n); } catch (e) {}
FuzzerInjectionPoint(17);
v13 ?? v13;
FuzzerInjectionPoint(18);
Proxy.b = Proxy;
FuzzerInjectionPoint(19);
Proxy.b = Proxy;
FuzzerInjectionPoint(20);
Proxy.h = Proxy;
FuzzerInjectionPoint(21);
new C5();
FuzzerInjectionPoint(22);
try {
FuzzerInjectionPoint(23);
const t0 = 151856190n;
FuzzerInjectionPoint(24);
t0(v11, C5);
FuzzerInjectionPoint(25);
} catch (e) {}
FuzzerInjectionPoint(26);
try {
FuzzerInjectionPoint(27);
const t0 = 151856190n;
FuzzerInjectionPoint(28);
t0();
FuzzerInjectionPoint(29);
} catch (e) {}
FuzzerInjectionPoint(30);
WeakMap.prototype = WeakMap;
FuzzerInjectionPoint(31);
WeakMap.prototype = WeakMap;
FuzzerInjectionPoint(32);
new WeakMap();
FuzzerInjectionPoint(33);
function f20(a21, a22, a23) {
FuzzerInjectionPoint(34);
    a22 ?? a22;
FuzzerInjectionPoint(35);
    a22.d = a22;
FuzzerInjectionPoint(36);
    a23 ^ a23;
FuzzerInjectionPoint(37);
    return { ...a22, [a22]: a23, c: a22, a: 12n };
FuzzerInjectionPoint(38);
}
FuzzerInjectionPoint(39);
f20.caller = f20;
FuzzerInjectionPoint(40);
const t39 = 12n;
FuzzerInjectionPoint(41);
t39.a = 12n;
FuzzerInjectionPoint(42);
const v27 = f20(C5, C5, 12n);
FuzzerInjectionPoint(43);
v27.d;
FuzzerInjectionPoint(44);
f20(-45021n, C5, 12n);
FuzzerInjectionPoint(45);
f20(12n, C5, 151856190n);
FuzzerInjectionPoint(46);
function f31() {
FuzzerInjectionPoint(47);
    return f31;
FuzzerInjectionPoint(48);
}
FuzzerInjectionPoint(49);
f31();
FuzzerInjectionPoint(50);
f31 ?? f31;
FuzzerInjectionPoint(51);
f31 ?? f31;
FuzzerInjectionPoint(52);
let v35 = 0;
FuzzerInjectionPoint(53);
const v36 = {

    defineProperty: -45021n,

    isExtensible: f31,

    preventExtensions: f31,

    set: f20,

    setPrototypeOf: f20,

};
FuzzerInjectionPoint(60);
v36.setPrototypeOf(v36, v36, f20);
FuzzerInjectionPoint(61);
const v38 = v36.isExtensible;
FuzzerInjectionPoint(62);
const t61 = v38.constructor;
FuzzerInjectionPoint(63);
t61(v13);
FuzzerInjectionPoint(64);
let v41;
FuzzerInjectionPoint(65);
try { v41 = Proxy(); } catch (e) {}
FuzzerInjectionPoint(66);
v41 ?? v41;
FuzzerInjectionPoint(67);
const v43 = v38();
FuzzerInjectionPoint(68);
v43.g = v43;
FuzzerInjectionPoint(69);
let v45;
FuzzerInjectionPoint(70);
try { v45 = Proxy(Proxy, v35); } catch (e) {}
FuzzerInjectionPoint(71);
v45 ?? v45;
FuzzerInjectionPoint(72);
const v47 = new Proxy(v27, v36);
FuzzerInjectionPoint(73);
v47.d = v47;
FuzzerInjectionPoint(74);
v35++;
FuzzerInjectionPoint(75);
let v49 = 9;
FuzzerInjectionPoint(76);
-v49;
FuzzerInjectionPoint(77);
v49 != v49;
FuzzerInjectionPoint(78);
v49--;
FuzzerInjectionPoint(79);
const v53 = v35 < v35;
FuzzerInjectionPoint(80);
v53 && v53;
FuzzerInjectionPoint(81);
const v55 = f31.arguments;
FuzzerInjectionPoint(82);
v55 ?? v55;