
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new ArrayBuffer(1024, { maxByteLength: 2147483649 });
FuzzerInjectionPoint(2);
const v6 = new Float64Array(v4);
FuzzerInjectionPoint(3);
v6.fill(-0.0);
FuzzerInjectionPoint(4);