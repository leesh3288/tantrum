
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 {

    constructor(a3) {
FuzzerInjectionPoint(3);
        Math.expm1(a3);
FuzzerInjectionPoint(4);
    }

}
FuzzerInjectionPoint(6);
new C1(Infinity);