
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [10,-16,1637200041,2147483649,536870889,41020,-536870912,9];
FuzzerInjectionPoint(2);
function f2(a3, a4) {
FuzzerInjectionPoint(3);
    return a4;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v5 = {};
FuzzerInjectionPoint(6);
v5.g = v0;
FuzzerInjectionPoint(7);
const v6 = {};
FuzzerInjectionPoint(8);
v6.f = -2112911755;
FuzzerInjectionPoint(9);
const v7 = { ...v5, ...v6 };
FuzzerInjectionPoint(10);
function f8(a9, a10, a11) {
FuzzerInjectionPoint(11);
    const v12 = { ...a10, g: f2 };
FuzzerInjectionPoint(12);
    return v0;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
f8(f8, v7);
FuzzerInjectionPoint(15);