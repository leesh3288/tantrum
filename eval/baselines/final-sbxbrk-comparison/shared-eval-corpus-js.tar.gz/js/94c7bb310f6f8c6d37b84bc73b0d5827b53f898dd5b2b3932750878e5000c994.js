
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    const v4 = ({ a: -4294967295 }).a;
FuzzerInjectionPoint(3);
    -(v4 & v4);
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f1();
FuzzerInjectionPoint(6);
f1();
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(8);
f1();
FuzzerInjectionPoint(9);