
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[1073741823,65537,17851,1645341796];
FuzzerInjectionPoint(2);
[-16,-12,40370,2147483649,-2147483649,13,-2147483649,4,5943,-2111978647];
FuzzerInjectionPoint(3);
const v2 = [-128];
FuzzerInjectionPoint(4);
function F6(a8, a9, a10, a11) {

    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(6);
    this.d = a11;
FuzzerInjectionPoint(7);
    this.h = v2;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
new F6(0.9446028495854856, -956682.8022465215, 0.9446028495854856, -1e-15);
FuzzerInjectionPoint(10);
const v15 = new Int8Array();

v15.join(BigInt64Array).toUpperCase();
FuzzerInjectionPoint(12);
new F6(-956682.8022465215, 0.9446028495854856, 0.9446028495854856, -1e-15);
FuzzerInjectionPoint(13);
new F6(-1e-15, 0.9446028495854856, 0.9446028495854856, -1e-15);
FuzzerInjectionPoint(14);
[12,3,-4294967297,-4294967296,20534228,-41715];

[723910616,257,-2,536870912,-19503,13,9];

const v22 = [-229,1073741824,9007199254740992,57834,-536870912,-729622857,16,-30692,-5,536870888];
FuzzerInjectionPoint(17);
const v26 = [1935898983];

[v26,v26,v26];
FuzzerInjectionPoint(19);
new Uint8ClampedArray(31);

class C34 {

    static #b;

}
FuzzerInjectionPoint(23);
const v35 = new C34();
FuzzerInjectionPoint(24);
const v36 = new C34();
FuzzerInjectionPoint(25);
new Uint8Array(1);
FuzzerInjectionPoint(26);
const v46 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x06,

    0x01, 0x60, 0x02, 0x7C, 0x7F, 0x00, 0x03, 0x02, 0x01, 0x00,

    0x04, 0x01, 0x00, 0x05, 0x01, 0x00, 0x06, 0x0D, 0x01, 0x7C,

    0x00, 0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x14, 0xC0,

    0x0B, 0x07, 0x0C, 0x02, 0x02, 0x77, 0x30, 0x00, 0x00, 0x03,

    0x77, 0x67, 0x30, 0x03, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x04,

    0x01, 0x02, 0x00, 0x0B,

])));
FuzzerInjectionPoint(35);
function f47(a48, a49, a50) {
FuzzerInjectionPoint(36);
    return { __proto__: a49, f: 9007199254740991, [536870888]: 1.5554632819502635e+308 };
FuzzerInjectionPoint(37);
}
FuzzerInjectionPoint(38);
f47(C34, 3.0, v36);
FuzzerInjectionPoint(39);
f47(v35);
FuzzerInjectionPoint(40);
const v57 = [-1000000.0];

const v58 = [-3.514511838138425e+307,-1.7976931348623157e+308,-1.4515033196894892e+308];
FuzzerInjectionPoint(42);
function f59(a60, a61, a62) {

    const v63 = {

        h: v57,

        ...v22,

        [2]: 268435456,

        c: a62,

        2: a62,

        b: v58,

        ...v57,

        e: -4,

    };
FuzzerInjectionPoint(53);
    return -4;
FuzzerInjectionPoint(54);
}
FuzzerInjectionPoint(55);
f59(v22, v22, -4);
FuzzerInjectionPoint(56);
new Uint8ClampedArray(Uint8ClampedArray);
FuzzerInjectionPoint(57);
const v71 = new Int16Array(268435456, 0, 2);
FuzzerInjectionPoint(58);
v71.constructor;
FuzzerInjectionPoint(59);
class C74 {

}
FuzzerInjectionPoint(61);
const v77 = new Uint32Array(4096);
FuzzerInjectionPoint(62);
new Int8Array(v77);
FuzzerInjectionPoint(63);
const v80 = [255,8,-4,1,1318086974];
FuzzerInjectionPoint(64);
const v84 = new BigInt64Array();
FuzzerInjectionPoint(65);
const v85 = v84.constructor;
FuzzerInjectionPoint(66);
let v86;
FuzzerInjectionPoint(67);
try { v86 = new v85(v80); } catch (e) {}
FuzzerInjectionPoint(68);
const v87 = [v80];
FuzzerInjectionPoint(69);
function f88() {
FuzzerInjectionPoint(70);
    const v91 = {

        a: v86,

        [v87]: 3.0,

        h: 9007199254740991,

        ...v36,

        __proto__: v87,

        valueOf() {
FuzzerInjectionPoint(77);
            const t0 = "dNd";
FuzzerInjectionPoint(78);
            t0[2699094064] -= v87;
FuzzerInjectionPoint(79);
            return this;
FuzzerInjectionPoint(80);
        },

    };
FuzzerInjectionPoint(82);
    return v91.valueOf(v91, v91, 64, v91, v91);
FuzzerInjectionPoint(83);
}
FuzzerInjectionPoint(84);
try { f88.__defineSetter__(); } catch (e) {}
FuzzerInjectionPoint(85);
for (let v94 = 0; v94 < 100; v94++) {
FuzzerInjectionPoint(86);
    f88();
FuzzerInjectionPoint(87);
}