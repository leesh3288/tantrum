
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Float32Array(Float32Array, Float32Array);
FuzzerInjectionPoint(2);
v1.buffer.transfer();
FuzzerInjectionPoint(3);
this.WebAssembly.validate(v1);
FuzzerInjectionPoint(4);