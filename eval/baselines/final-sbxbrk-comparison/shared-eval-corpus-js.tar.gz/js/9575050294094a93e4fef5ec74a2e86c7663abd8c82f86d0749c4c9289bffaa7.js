
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = ([35843,-4294967295,-1751722941,-20067,8,-1073741824,1000,536870888,32500])["fill"]();
FuzzerInjectionPoint(2);
function F3(a5, a6, a7, a8) {
FuzzerInjectionPoint(3);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
F3.collation = v2;
FuzzerInjectionPoint(6);
const v13 = {

    ["buffer"](a11) {
FuzzerInjectionPoint(8);
        a11.localeCompare(F3, F3, F3);
FuzzerInjectionPoint(9);
    },

};
FuzzerInjectionPoint(11);
try { v13.buffer("buffer"); } catch (e) {}