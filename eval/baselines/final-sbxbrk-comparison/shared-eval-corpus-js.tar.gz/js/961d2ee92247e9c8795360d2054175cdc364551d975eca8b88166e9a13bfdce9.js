
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = ("undefined").constructor.fromCharCode(undefined);
FuzzerInjectionPoint(2);
const v4 = v3.split;
FuzzerInjectionPoint(3);
try { v4.constructor(v3); } catch (e) {}
FuzzerInjectionPoint(4);