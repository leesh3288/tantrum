
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new SharedArrayBuffer(111, { maxByteLength: 1073741824 });

const v6 = new Float64Array(v4);

const v7 = [12,2010473674,0,-2147483649,-9007199254740992];

const t3 = constructor().Float16Array;

const v11 = new t3(v7);

function f12() {

    return v4;

}

function f13() {

    return v6;

}

f12[Symbol.species] = f13;

v11.constructor = f12;

v11.slice();