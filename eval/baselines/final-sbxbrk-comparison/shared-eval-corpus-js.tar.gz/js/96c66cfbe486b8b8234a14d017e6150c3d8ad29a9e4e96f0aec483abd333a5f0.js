
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
class C2 {

}
FuzzerInjectionPoint(4);
function f3(a4, a5) {
FuzzerInjectionPoint(5);
    a4[16] = a4;
FuzzerInjectionPoint(6);
    return a5;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f3(C2);
FuzzerInjectionPoint(9);
class C7 {

    constructor(a9, a10) {
FuzzerInjectionPoint(11);
        this.e(a10);
FuzzerInjectionPoint(12);
        %OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(13);
        f3(this);
FuzzerInjectionPoint(14);
    }

    e = f3;

}
FuzzerInjectionPoint(17);
new C7(Uint8ClampedArray, v0);