
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    const v3 = [-596992.2717851705,1.3656356845740762e+308];
FuzzerInjectionPoint(3);
    Object.defineProperty(v3, 3, { writable: true, enumerable: true, value: 247 });
FuzzerInjectionPoint(4);
    return v3;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
Symbol[Symbol.species] = f1;
FuzzerInjectionPoint(7);
const v6 = [f1,f1,f1,f1];
FuzzerInjectionPoint(8);
v6.constructor = Symbol;
FuzzerInjectionPoint(9);
try { v6.concat(f1, f1, Symbol); } catch (e) {}
FuzzerInjectionPoint(10);