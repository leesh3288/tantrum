
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
Int8Array.microseconds = 0.0793624049069418;
FuzzerInjectionPoint(2);
const t1 = constructor().Intl.DurationFormat;
FuzzerInjectionPoint(3);
const v6 = new t1();
FuzzerInjectionPoint(4);
try { v6.formatToParts(Int8Array); } catch (e) {}
FuzzerInjectionPoint(5);