
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Set();
FuzzerInjectionPoint(2);
function f3() {
FuzzerInjectionPoint(3);
    let [v4] = v2;
FuzzerInjectionPoint(4);
    const v18 = {

        p(a6, a7) {
FuzzerInjectionPoint(6);
            function f8(a9, a10, a11) {
FuzzerInjectionPoint(7);
                let v13;
FuzzerInjectionPoint(8);
                try { v13 = BigInt.asIntN(1, f8); } catch (e) {}
FuzzerInjectionPoint(9);
                function f14(a15) {
FuzzerInjectionPoint(10);
                    return f14;
FuzzerInjectionPoint(11);
                }
FuzzerInjectionPoint(12);
                class C16 extends f14 {

                    512 = v13;

                }
FuzzerInjectionPoint(15);
                return v4;
FuzzerInjectionPoint(16);
            }
FuzzerInjectionPoint(17);
            f8();
FuzzerInjectionPoint(18);
            return 1;
FuzzerInjectionPoint(19);
        },

    };
FuzzerInjectionPoint(21);
    v18.p();
FuzzerInjectionPoint(22);
    return f3;
FuzzerInjectionPoint(23);
}
FuzzerInjectionPoint(24);
const v20 = f3();
FuzzerInjectionPoint(25);
f3();
FuzzerInjectionPoint(26);
const v22 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(27);
function f23(a24, a25) {
FuzzerInjectionPoint(28);
    %OptimizeFunctionOnNextCall(v20);
FuzzerInjectionPoint(29);
    v20();
FuzzerInjectionPoint(30);
}
FuzzerInjectionPoint(31);
v22.toString = f23;
FuzzerInjectionPoint(32);
class C27 extends Set {

    [v22] = v22;

}