
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    d = -571411766;

    static [-571411766] = 885449245;

    h = 885449245;

    [-571411766] = 885449245;

    constructor(a5) {
FuzzerInjectionPoint(7);
        this.h;
FuzzerInjectionPoint(8);
        const v7 = 885449245 ^ -571411766;
FuzzerInjectionPoint(9);
        v7 * v7;
FuzzerInjectionPoint(10);
        -16n << -16n;
FuzzerInjectionPoint(11);
        const v13 = a5 & 885449245;
FuzzerInjectionPoint(12);
        function F14(a16, a17, a18) {
FuzzerInjectionPoint(13);
            if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(14);
            let v19 = a17[5];
FuzzerInjectionPoint(15);
            v19--;
FuzzerInjectionPoint(16);
            this.g = 885449245;
FuzzerInjectionPoint(17);
            this.h = a16;
FuzzerInjectionPoint(18);
        }
FuzzerInjectionPoint(19);
        try { Float32Array.from(v7); } catch (e) {}
FuzzerInjectionPoint(20);
        try { ("a").italics(); } catch (e) {}
FuzzerInjectionPoint(21);
        function f30(a31, a32) {
FuzzerInjectionPoint(22);
            eval(a32);
FuzzerInjectionPoint(23);
            do {
FuzzerInjectionPoint(24);
            } while ((() => {
FuzzerInjectionPoint(25);
                    const v37 = 0 < 8;
FuzzerInjectionPoint(26);
                    v37 - v37;
FuzzerInjectionPoint(27);
                    return v37;
FuzzerInjectionPoint(28);
                })())
FuzzerInjectionPoint(29);
            return a32;
FuzzerInjectionPoint(30);
        }
FuzzerInjectionPoint(31);
        false || -16n;
FuzzerInjectionPoint(32);
        const v48 = new F14("bigint", "bigint", v7);
FuzzerInjectionPoint(33);
        v48.g;
FuzzerInjectionPoint(34);
        const v50 = new F14(-16n, -1745261865n, -571411766);
FuzzerInjectionPoint(35);
        v50.g = v50;
FuzzerInjectionPoint(36);
        new F14(3n, v13, 9);
FuzzerInjectionPoint(37);
    }

}
FuzzerInjectionPoint(39);
new C3(C3);
FuzzerInjectionPoint(40);
const v53 = new C3(C3);
FuzzerInjectionPoint(41);
let v54 = new C3(v53);
FuzzerInjectionPoint(42);
v54.d;
FuzzerInjectionPoint(43);
class C56 extends C3 {

    set h(a58) {
FuzzerInjectionPoint(45);
        v54 ??= C3;
FuzzerInjectionPoint(46);
        [762.4877449003682];
FuzzerInjectionPoint(47);
        [-1000.0];
FuzzerInjectionPoint(48);
        [-4.0] ** "bigint";
FuzzerInjectionPoint(49);
    }

    c = C3;

    static [885449245] = 885449245;

}
FuzzerInjectionPoint(53);
const v64 = ("63515").constructor;
FuzzerInjectionPoint(54);
const v65 = v64.fromCodePoint("63515");
FuzzerInjectionPoint(55);
const v66 = v65.blink(v64, v64, v64, v65, v65);
FuzzerInjectionPoint(56);
("63515").blink().search(v66);