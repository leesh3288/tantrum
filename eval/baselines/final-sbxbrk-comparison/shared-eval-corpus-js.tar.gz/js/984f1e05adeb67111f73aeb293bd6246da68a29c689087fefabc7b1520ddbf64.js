
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = 1;
FuzzerInjectionPoint(2);
function f1() {
FuzzerInjectionPoint(3);
    v0 *= v0;
FuzzerInjectionPoint(4);
    return f1;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
f1();
FuzzerInjectionPoint(7);
f1();
FuzzerInjectionPoint(8);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);