
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Float64Array();
FuzzerInjectionPoint(2);
new Int32Array(644);
FuzzerInjectionPoint(3);
new Uint8ClampedArray(0);
FuzzerInjectionPoint(4);
class C10 {

}
FuzzerInjectionPoint(6);
C10.length;
FuzzerInjectionPoint(7);
const v14 = { a: -4294967295 };
FuzzerInjectionPoint(8);
new Uint8ClampedArray();
FuzzerInjectionPoint(9);
new Uint16Array();
FuzzerInjectionPoint(10);
async function f24(a25) {
FuzzerInjectionPoint(11);
    return "M63C";
FuzzerInjectionPoint(12);
    return await a25;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
f24();
FuzzerInjectionPoint(15);
try {
FuzzerInjectionPoint(16);
    class C29 extends Uint8ClampedArray {

        constructor(a31, a32) {
FuzzerInjectionPoint(18);
            super();
FuzzerInjectionPoint(19);
            function f33() {
FuzzerInjectionPoint(20);
                if (a31) {
FuzzerInjectionPoint(21);
                }
FuzzerInjectionPoint(22);
            }
FuzzerInjectionPoint(23);
            %OptimizeMaglevOnNextCall(C29);
FuzzerInjectionPoint(24);
        }

    }
FuzzerInjectionPoint(26);
    new C29();
FuzzerInjectionPoint(27);
    new C29();
FuzzerInjectionPoint(28);
    new C29();
FuzzerInjectionPoint(29);
    const v37 = {};
FuzzerInjectionPoint(30);
} catch(e38) {
FuzzerInjectionPoint(31);
}