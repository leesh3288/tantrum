
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f6() {
FuzzerInjectionPoint(2);
    Date();
FuzzerInjectionPoint(3);
    function f11(a12, a13, a14, a15) {
FuzzerInjectionPoint(4);
        return a12;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    const v22 = {

        m(a17, a18) {
FuzzerInjectionPoint(8);
            return -1242605751;
FuzzerInjectionPoint(9);
        },

    };
FuzzerInjectionPoint(11);
    v22.e = v22;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
function f23() {
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
f6[Symbol] = f23;
FuzzerInjectionPoint(16);
("undefined").fontcolor();
FuzzerInjectionPoint(17);
const v28 = Date();
FuzzerInjectionPoint(18);
for (let v29 = 0; v29 < 81; v29++) {
FuzzerInjectionPoint(19);
    Date(f6, v29, v29, Float32Array, v28, ..."undefined");
FuzzerInjectionPoint(20);
    function f31() {
FuzzerInjectionPoint(21);
        return v29;
FuzzerInjectionPoint(22);
    }
FuzzerInjectionPoint(23);
}
FuzzerInjectionPoint(24);
class C32 {

    constructor(a34, a35) {
FuzzerInjectionPoint(26);
        super.e *= { __proto__: this };
FuzzerInjectionPoint(27);
    }

}
FuzzerInjectionPoint(29);
const v39 = [0.10281860495791983,-882934.3575712838,5.086074806086066e+307,1000000000.0,477.97019146969615,-2.2250738585072014e-308,34410.487750383676,Infinity,-1.1265646683982815e+308];
FuzzerInjectionPoint(30);
const v41 = [-1000000.0];
FuzzerInjectionPoint(31);
class C42 {

}
FuzzerInjectionPoint(33);
function f43(a44, a45, a46) {
FuzzerInjectionPoint(34);
    a46 && a46;
FuzzerInjectionPoint(35);
    function F48() {
FuzzerInjectionPoint(36);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(37);
        for (const v50 in this) {
FuzzerInjectionPoint(38);
        }
FuzzerInjectionPoint(39);
    }
FuzzerInjectionPoint(40);
    Array instanceof F48;
FuzzerInjectionPoint(41);
    const v53 = a46++;
FuzzerInjectionPoint(42);
    v53 >>> v53;
FuzzerInjectionPoint(43);
    ({ h: v41, ...v39, 2: a46, e: -4 })[1];
FuzzerInjectionPoint(44);
}
FuzzerInjectionPoint(45);
f43(f43(), f43);
FuzzerInjectionPoint(46);
%OptimizeMaglevOnNextCall(f43);
FuzzerInjectionPoint(47);
f43();