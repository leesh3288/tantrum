
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v2 = 10 ** Int16Array;
FuzzerInjectionPoint(2);
function f3() {
FuzzerInjectionPoint(3);
    for (let i6 = 0, i7 = 10;

        (() => {
FuzzerInjectionPoint(5);
            const v9 = 9007199254740990n | 9007199254740990n;
FuzzerInjectionPoint(6);
            v9 % v9;
FuzzerInjectionPoint(7);
            return i6;
FuzzerInjectionPoint(8);
        })();

        v2 = i7) {
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    return v2;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f3();
FuzzerInjectionPoint(14);
f3();
FuzzerInjectionPoint(15);
%OptimizeMaglevOnNextCall(f3);
FuzzerInjectionPoint(16);
f3();