
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = [55907.27578783571,631062.035585549,-544.6690833601697,0.38135605463131816,-0.0,1.0,-5.632830740521031,-176783.07564066525,-4.582854190241215e+307];
FuzzerInjectionPoint(2);
v2[77] = 1024;
FuzzerInjectionPoint(3);
function f3(a4) {
FuzzerInjectionPoint(4);
    return Uint32Array;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
Object.defineProperty(v2, 136, { configurable: true, enumerable: true, get: f3, set: f3 });
FuzzerInjectionPoint(7);
const v5 = new Uint32Array(v2);
FuzzerInjectionPoint(8);
v5.toSorted();
FuzzerInjectionPoint(9);