
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Uint16Array(Uint16Array, Uint16Array, Uint16Array);
FuzzerInjectionPoint(2);
function f2(a3) {
FuzzerInjectionPoint(3);
    arguments.__proto__ = v1;
FuzzerInjectionPoint(4);
    Math.expm1(arguments);
FuzzerInjectionPoint(5);
    return Uint16Array;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
try { f2(f2); } catch (e) {}
FuzzerInjectionPoint(8);