
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = `
FuzzerInjectionPoint(2);
    [1e-15,[2.2250738585072014e-308,0.5659405280646757,-433.9867819857128,1000000000000.0,4.0,1.0422304090047802e+308,NaN,317.0101318599152]];
FuzzerInjectionPoint(3);
    /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(4);
`;
FuzzerInjectionPoint(5);
try { JSON.parse(v1, WeakSet); } catch (e) {}
FuzzerInjectionPoint(6);