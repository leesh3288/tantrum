
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 extends Date(Date).constructor {

}
FuzzerInjectionPoint(3);
const v4 = C3.prototype;
FuzzerInjectionPoint(4);
try { v4.toUpperCase(); } catch (e) {}