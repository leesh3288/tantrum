
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    function f2() {
FuzzerInjectionPoint(3);
        function f3(a4) {
FuzzerInjectionPoint(4);
            for (let [i8, i9] = (() => {
FuzzerInjectionPoint(5);
                    0 >>> 0;
FuzzerInjectionPoint(6);
                    return [0, 10];
FuzzerInjectionPoint(7);
                })();

                (() => {
FuzzerInjectionPoint(9);
                    let v10 = i9 % i9;
FuzzerInjectionPoint(10);
                    v10--;
FuzzerInjectionPoint(11);
                    return i8;
FuzzerInjectionPoint(12);
                })();

                ) {
FuzzerInjectionPoint(14);
            }
FuzzerInjectionPoint(15);
        }
FuzzerInjectionPoint(16);
        const v16 = f3(f0);
FuzzerInjectionPoint(17);
        for (let v17 = 0; v17 < 5; v17++) {
FuzzerInjectionPoint(18);
            function f18() {
FuzzerInjectionPoint(19);
                return f18;
FuzzerInjectionPoint(20);
            }
FuzzerInjectionPoint(21);
            const v19 = f18.__lookupSetter__;
FuzzerInjectionPoint(22);
            v19.name;
FuzzerInjectionPoint(23);
            try { v19(v16); } catch (e) {}
FuzzerInjectionPoint(24);
        }
FuzzerInjectionPoint(25);
        return f0;
FuzzerInjectionPoint(26);
    }
FuzzerInjectionPoint(27);
    f2.apply();
FuzzerInjectionPoint(28);
    const v23 = [2.220446049250313e-16,-4.0,1000000000.0,140.87970149730995,412.0040667062758,4.0,-108.9135621945137,-1.5645345025673247];
FuzzerInjectionPoint(29);
    function f26() {
FuzzerInjectionPoint(30);
        return v23 <= 536870888n;
FuzzerInjectionPoint(31);
    }
FuzzerInjectionPoint(32);
    BigUint64Array.constructor = f26;
FuzzerInjectionPoint(33);
    return f0;
FuzzerInjectionPoint(34);
}
FuzzerInjectionPoint(35);
const v28 = f0();
FuzzerInjectionPoint(36);
f0();
FuzzerInjectionPoint(37);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(38);
f0(v28);