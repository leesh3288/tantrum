
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-1.0,-2.2250738585072014e-308,0.975447237360638,-1.4220538042575317e+308,-318198.51512095344,-66.43028159543235,8.205103236405698];
FuzzerInjectionPoint(2);
const v5 = new SharedArrayBuffer(1453, { maxByteLength: 1453 });
FuzzerInjectionPoint(3);
const v7 = new Uint8Array(v5);
FuzzerInjectionPoint(4);
v7.set(v0);
FuzzerInjectionPoint(5);