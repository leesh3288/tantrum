
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = d8.test.FastCAPI;

const v5 = new t0();

v5.clamp_compare_i32(162, 207, 207);