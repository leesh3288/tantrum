
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    static 1000;

    ["h"] = -256;

    10;

    m(a5, a6) {
FuzzerInjectionPoint(6);
        const v7 = delete this?.f;
FuzzerInjectionPoint(7);
        let v8;
FuzzerInjectionPoint(8);
        try { v8 = a6(a5, -256, v7, v7, this); } catch (e) {}
FuzzerInjectionPoint(9);
        try { new v8("h", a5); } catch (e) {}
FuzzerInjectionPoint(10);
        super[super.e];
FuzzerInjectionPoint(11);
        const v13 = a5.iterator;
FuzzerInjectionPoint(12);
        const v22 = {

            [v13]() {
FuzzerInjectionPoint(14);
                let v15 = 10;
FuzzerInjectionPoint(15);
                const v21 = {

                    next() {
FuzzerInjectionPoint(17);
                        v15--;
FuzzerInjectionPoint(18);
                        const v19 = v15 == 0;
FuzzerInjectionPoint(19);
                        return { done: v19, value: v15 };
FuzzerInjectionPoint(20);
                    },

                };
FuzzerInjectionPoint(22);
                return v21;
FuzzerInjectionPoint(23);
            },

        };
FuzzerInjectionPoint(25);
        return v22;
FuzzerInjectionPoint(26);
    }

}
FuzzerInjectionPoint(28);
const v23 = new C3();
FuzzerInjectionPoint(29);
v23[10];
FuzzerInjectionPoint(30);
const v25 = new C3();
FuzzerInjectionPoint(31);
const v26 = new C3();
FuzzerInjectionPoint(32);
v26.h = v26;
FuzzerInjectionPoint(33);
v26[10] = v26;
FuzzerInjectionPoint(34);
function f27(a28, a29) {
FuzzerInjectionPoint(35);
    a28 * a28;
FuzzerInjectionPoint(36);
    a29[10] = a29;
FuzzerInjectionPoint(37);
    const v37 = {

        ...v26,

        ...v26,

        7: a28,

        c: v25,

        set g(a32) {
FuzzerInjectionPoint(43);
            let {"h":v34,"length":v35,...v36} = "48749";
FuzzerInjectionPoint(44);
        },

        a: v26,

        e: v25,

        f: "h",

        h: v25,

        d: a28,

    };
FuzzerInjectionPoint(51);
    v37.a = v37;
FuzzerInjectionPoint(52);
    return v37;
FuzzerInjectionPoint(53);
}
FuzzerInjectionPoint(54);
f27.arguments = f27;
FuzzerInjectionPoint(55);
const v38 = f27(-256, v26);
FuzzerInjectionPoint(56);
v38[10] = v38;
FuzzerInjectionPoint(57);
const v39 = f27(v25, v38);
FuzzerInjectionPoint(58);
const v40 = f27(v38, v23);
FuzzerInjectionPoint(59);
try { v40.isPrototypeOf(-256); } catch (e) {}
FuzzerInjectionPoint(60);
["h",v40,v38,"h"];
FuzzerInjectionPoint(61);
[v38,v38];
FuzzerInjectionPoint(62);
const v44 = [v39];
FuzzerInjectionPoint(63);
v44[0][10];
FuzzerInjectionPoint(64);
let v47 = 9007199254740990;
FuzzerInjectionPoint(65);
v47--;
FuzzerInjectionPoint(66);
v47 >>> v47;
FuzzerInjectionPoint(67);
const t64 = "12";
FuzzerInjectionPoint(68);
t64.d = "12";
FuzzerInjectionPoint(69);
-43 >>> -43;
FuzzerInjectionPoint(70);
try { ("function").small(); } catch (e) {}
FuzzerInjectionPoint(71);
let v59;
FuzzerInjectionPoint(72);
try { v59 = new Uint32Array("48749", "48749", "48749"); } catch (e) {}
FuzzerInjectionPoint(73);
try { v59.reduce("function"); } catch (e) {}
FuzzerInjectionPoint(74);
/[x]*/mudsg;
FuzzerInjectionPoint(75);
try { Uint8Array.of(); } catch (e) {}
FuzzerInjectionPoint(76);
let v66 = 0;
FuzzerInjectionPoint(77);
v66++;
FuzzerInjectionPoint(78);
try {
FuzzerInjectionPoint(79);
    function f69() {
FuzzerInjectionPoint(80);
        return f69;
FuzzerInjectionPoint(81);
    }
FuzzerInjectionPoint(82);
    try { new f69(); } catch (e) {}
FuzzerInjectionPoint(83);
} catch(e71) {
FuzzerInjectionPoint(84);
    new Int32Array(127);
FuzzerInjectionPoint(85);
    const v75 = {};
FuzzerInjectionPoint(86);
}
FuzzerInjectionPoint(87);
const v77 = Reflect?.preventExtensions;
FuzzerInjectionPoint(88);
try { new v77(C3); } catch (e) {}
FuzzerInjectionPoint(89);
try { Reflect.set(v44, 30899, undefined); } catch (e) {}
FuzzerInjectionPoint(90);
function F80(a82) {
FuzzerInjectionPoint(91);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(92);
    function f83() {
FuzzerInjectionPoint(93);
    }
FuzzerInjectionPoint(94);
    const v89 = {

        g: this,

        toString(a87, a88) {
FuzzerInjectionPoint(97);
            return this;
FuzzerInjectionPoint(98);
        },

        ["d"]: "length",

        6: this,

        65537: this,

        h: this,

    };
FuzzerInjectionPoint(104);
}
FuzzerInjectionPoint(105);
-25511625 >>> -25511625;
FuzzerInjectionPoint(106);
Uint8ClampedArray <= Float64Array;
FuzzerInjectionPoint(107);
"copyWithin" - -25511625;
FuzzerInjectionPoint(108);
const v98 = new Uint8ClampedArray(4096);
FuzzerInjectionPoint(109);
try { v98.set("h"); } catch (e) {}
FuzzerInjectionPoint(110);
Reflect.buffer = v98;
FuzzerInjectionPoint(111);
new Int16Array(4034);
FuzzerInjectionPoint(112);
let v104;
FuzzerInjectionPoint(113);
try { v104 = ("undefined").fixed(); } catch (e) {}
FuzzerInjectionPoint(114);
v104[16] = v104;
FuzzerInjectionPoint(115);
const v106 = [-2106628158,0,-1013819009,1328679272,6,-2,2147483648,-50134,-17205,-206592434];
FuzzerInjectionPoint(116);
const v107 = [-10,10,-2147483649,127,60744,38882,31280,-23071,255];
FuzzerInjectionPoint(117);
function F108(a110, a111, a112) {
FuzzerInjectionPoint(118);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(119);
    const v113 = this?.propertyIsEnumerable;
FuzzerInjectionPoint(120);
    try { new v113(this); } catch (e) {}
FuzzerInjectionPoint(121);
    try { a110.findLastIndex(a110); } catch (e) {}
FuzzerInjectionPoint(122);
    a111[1] = a111;
FuzzerInjectionPoint(123);
    const v116 = this?.__lookupGetter__;
FuzzerInjectionPoint(124);
    v116.length;
FuzzerInjectionPoint(125);
    let v118;
FuzzerInjectionPoint(126);
    try { v118 = new v116(a110); } catch (e) {}
FuzzerInjectionPoint(127);
    v118 ?? v118;
FuzzerInjectionPoint(128);
    try { a111.valueOf(); } catch (e) {}
FuzzerInjectionPoint(129);
    let v121;
FuzzerInjectionPoint(130);
    try { v121 = a112.lastIndexOf(a112); } catch (e) {}
FuzzerInjectionPoint(131);
    v121 | v121;
FuzzerInjectionPoint(132);
    function f123() {
FuzzerInjectionPoint(133);
        return v106;
FuzzerInjectionPoint(134);
    }
FuzzerInjectionPoint(135);
    function f124(a125) {
FuzzerInjectionPoint(136);
        for (let i = 0; i < 5; i++) {
FuzzerInjectionPoint(137);
            const v126 = [-983.5358627331157,0.5495627215473591,-1000000.0,-0.5076567772789726,0.16127806890355467];
FuzzerInjectionPoint(138);
            try { v126.flat(); } catch (e) {}
FuzzerInjectionPoint(139);
            const v128 = /\11/msgiy;
FuzzerInjectionPoint(140);
            Object.defineProperty(v128, "v17", { writable: true, configurable: true, enumerable: true, value: a125 });
FuzzerInjectionPoint(141);
            with (v128) {
FuzzerInjectionPoint(142);
                for (let v129 = 0; v129 < 12; v129++) {
FuzzerInjectionPoint(143);
                    v129 >>> v129;
FuzzerInjectionPoint(144);
                    const v131 = f123();
FuzzerInjectionPoint(145);
                    try { v131.reduce(v129); } catch (e) {}
FuzzerInjectionPoint(146);
                }
FuzzerInjectionPoint(147);
                source[2] = source;
FuzzerInjectionPoint(148);
                v126 != source;
FuzzerInjectionPoint(149);
            }
FuzzerInjectionPoint(150);
        }
FuzzerInjectionPoint(151);
    }
FuzzerInjectionPoint(152);
    try { f124(Float64Array); } catch (e) {}
FuzzerInjectionPoint(153);
    Object.defineProperty(this, "a", { configurable: true, enumerable: true, get: f123, set: f124 });
FuzzerInjectionPoint(154);
    this.a = a110;
FuzzerInjectionPoint(155);
}
FuzzerInjectionPoint(156);
try { new F108(Math, -43, -43); } catch (e) {}
FuzzerInjectionPoint(157);
const v137 = new F108(v107, "Zzj", "undefined");
FuzzerInjectionPoint(158);
v137.e = v137;
FuzzerInjectionPoint(159);
new Float32Array(F80, ...v98, 4096);