
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint8ClampedArray(9);
FuzzerInjectionPoint(2);
v2.fill();
FuzzerInjectionPoint(3);
let v4 = new WebAssembly.Global({ value: "i32", mutable: true }, -401581884);
FuzzerInjectionPoint(4);
v4.valueOf();
FuzzerInjectionPoint(5);