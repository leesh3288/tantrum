
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0(a2, a3, a4) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    function f5() {
FuzzerInjectionPoint(4);
        return f5;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    class C6 {

        constructor(a8, a9, a10, a11) {
FuzzerInjectionPoint(8);
            const v12 = this.constructor;
FuzzerInjectionPoint(9);
            try { new v12(); } catch (e) {}
FuzzerInjectionPoint(10);
            this.constructor = f5;
FuzzerInjectionPoint(11);
            const v14 = this.constructor;
FuzzerInjectionPoint(12);
            let v15;
FuzzerInjectionPoint(13);
            try { v15 = new v14(); } catch (e) {}
FuzzerInjectionPoint(14);
            function f16() {
FuzzerInjectionPoint(15);
                const v17 = /\P{gc=Decimal_Number}abc|def|ghixabc?/mvsy;
FuzzerInjectionPoint(16);
                v17.f = v17;
FuzzerInjectionPoint(17);
                return f5;
FuzzerInjectionPoint(18);
            }
FuzzerInjectionPoint(19);
            v15.length;
FuzzerInjectionPoint(20);
        }

    }
FuzzerInjectionPoint(22);
    new C6();
FuzzerInjectionPoint(23);
}
FuzzerInjectionPoint(24);
new F0();