
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = ([0.9900538262948212,0.3952241299829816,1000000.0,-2.220446049250313e-16,NaN,-1.7976931348623157e+308,0.4042036939312619,-1.0,-5.0])[4];
FuzzerInjectionPoint(2);
const v4 = this.Intl.NumberFormat;
FuzzerInjectionPoint(3);
v4.useGrouping = v1;
FuzzerInjectionPoint(4);
v4(v4, v4).resolvedOptions();
FuzzerInjectionPoint(5);