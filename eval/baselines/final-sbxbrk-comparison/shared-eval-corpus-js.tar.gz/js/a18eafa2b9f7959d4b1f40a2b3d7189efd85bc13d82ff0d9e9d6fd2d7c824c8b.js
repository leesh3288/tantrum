
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C2 {

    constructor(a4) {

        function f5() {

            function f7(a8) {

                a8.pow(a8, a8);

            }

            this.onmessage = f7;

            const v10 = %WasmArray();

        }

        new Worker(f5, { type: "function" });

    }

}

new C2();

new C2("atan2");

new Int8Array();

function f21() {

    [536870912,4];

    return Symbol;

    /a(?!bbb|bb)c*/vgiy;

    const t18 = 257;

    t18(129, 1409203643);

    class C29 {

    }

    return f21;

}