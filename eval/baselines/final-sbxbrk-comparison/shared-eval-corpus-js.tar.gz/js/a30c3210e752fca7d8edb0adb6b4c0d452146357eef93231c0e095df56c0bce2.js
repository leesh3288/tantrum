
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [];
FuzzerInjectionPoint(2);
class C1 {

    o(a3) {
FuzzerInjectionPoint(4);
        try { this.o(); } catch (e) {}
FuzzerInjectionPoint(5);
        let v5 = 9007199254740991;
FuzzerInjectionPoint(6);
        for (let i = 0; i < 5; i++) {
FuzzerInjectionPoint(7);
            for (const v6 of v0) {
FuzzerInjectionPoint(8);
            }
FuzzerInjectionPoint(9);
            v5++;
FuzzerInjectionPoint(10);
        }
FuzzerInjectionPoint(11);
    }

}
FuzzerInjectionPoint(13);
const v8 = new C1();
FuzzerInjectionPoint(14);
v8.o();