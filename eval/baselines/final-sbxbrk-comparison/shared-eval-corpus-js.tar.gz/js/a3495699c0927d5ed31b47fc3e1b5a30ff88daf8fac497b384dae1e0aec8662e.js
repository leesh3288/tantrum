
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
this.console.trace(Uint32Array);
FuzzerInjectionPoint(2);