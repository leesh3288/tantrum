
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2) {
FuzzerInjectionPoint(2);
    return f0;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f3(a4, a5, a6) {
FuzzerInjectionPoint(5);
    try { a5(); } catch (e) {}
FuzzerInjectionPoint(6);
    let v9 = new WebAssembly.Memory({ initial: 6, maximum: 53563, address: 'i32' });
FuzzerInjectionPoint(7);
    c = v9;
FuzzerInjectionPoint(8);
    Array[194] = c;
FuzzerInjectionPoint(9);
    return f3;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f3(f0, f3);
FuzzerInjectionPoint(12);
%OptimizeFunctionOnNextCall(f3);
FuzzerInjectionPoint(13);
f3(f0, f3, f0);
FuzzerInjectionPoint(14);