
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    const v2 = {};
FuzzerInjectionPoint(3);
    try {
FuzzerInjectionPoint(4);
        v2.o(a1);
FuzzerInjectionPoint(5);
    } catch(e4) {
FuzzerInjectionPoint(6);
        function f5(a6, a7) {
FuzzerInjectionPoint(7);
            return v2;
FuzzerInjectionPoint(8);
        }
FuzzerInjectionPoint(9);
        const v8 = new f5(f0, e4);
FuzzerInjectionPoint(10);
        v8.length = e4;
FuzzerInjectionPoint(11);
        v8.length;
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    return v2;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
f0(f0(f0));
FuzzerInjectionPoint(16);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(17);
f0();
FuzzerInjectionPoint(18);