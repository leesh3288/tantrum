
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Float64Array(1024);
FuzzerInjectionPoint(2);
new Int32Array(817);
FuzzerInjectionPoint(3);
new Uint8ClampedArray(139);
FuzzerInjectionPoint(4);
function f12() {
FuzzerInjectionPoint(5);
    return 1390497500;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
/(x)(x)(x)(x)(x)(x)(x)(x)(x)(x)\10/md;
FuzzerInjectionPoint(8);
/((((.).).).)/udi;
FuzzerInjectionPoint(9);
/(?:a+){0,0}(?<!a)2a{0,1}?/mvgiy;
FuzzerInjectionPoint(10);
function f16() {
FuzzerInjectionPoint(11);
    function f18() {
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    const v19 = [f18];
FuzzerInjectionPoint(14);
    const v21 = [[f18,v19,v19,f18],f18,v19];
FuzzerInjectionPoint(15);
    class C22 {

        #c;

        set a(a24) {
FuzzerInjectionPoint(18);
            Math.clz32();
FuzzerInjectionPoint(19);
            (57661).entries;
FuzzerInjectionPoint(20);
            function F31() {
FuzzerInjectionPoint(21);
                if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(22);
                this?.__lookupGetter__;
FuzzerInjectionPoint(23);
            }
FuzzerInjectionPoint(24);
            2 ^ a24;
FuzzerInjectionPoint(25);
            const v35 = 16 % 16;
FuzzerInjectionPoint(26);
            if (Uint8ClampedArray <= Float64Array) {
FuzzerInjectionPoint(27);
                function F41(a43, a44) {
FuzzerInjectionPoint(28);
                    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(29);
                }
FuzzerInjectionPoint(30);
            } else {
FuzzerInjectionPoint(31);
                "copyWithin" - -25511625;
FuzzerInjectionPoint(32);
            }
FuzzerInjectionPoint(33);
            const v46 = v35 & a24;
FuzzerInjectionPoint(34);
            const v48 = { maxByteLength: 862 };
FuzzerInjectionPoint(35);
            (57661).entries;
FuzzerInjectionPoint(36);
            ~v46;
FuzzerInjectionPoint(37);
            v35.expm1();
FuzzerInjectionPoint(38);
            a24 % 2;
FuzzerInjectionPoint(39);
        }

        g = v19;

        static 182;

    }
FuzzerInjectionPoint(43);
    const v54 = new C22();
FuzzerInjectionPoint(44);
    const v55 = new C22();
FuzzerInjectionPoint(45);
    const v56 = new C22();
FuzzerInjectionPoint(46);
    const v58 = new WeakMap();
FuzzerInjectionPoint(47);
    function f59(a60, a61, a62) {
FuzzerInjectionPoint(48);
        const v74 = {

            c: v21,

            toString(a64, a65) {
FuzzerInjectionPoint(51);
                new Set();
FuzzerInjectionPoint(52);
                a64 -= v56;
FuzzerInjectionPoint(53);
                return WeakMap;
FuzzerInjectionPoint(54);
            },

            [f18]: v19,

            valueOf(a69, a70) {
FuzzerInjectionPoint(57);
                /\ud808\udf45*/musiy;
FuzzerInjectionPoint(58);
                /foo(?!bar)baz/vsgy;
FuzzerInjectionPoint(59);
                const t0 = /[^123]+/muds;
FuzzerInjectionPoint(60);
                t0[5] ^= a60;
FuzzerInjectionPoint(61);
                return a60;
FuzzerInjectionPoint(62);
            },

        };
FuzzerInjectionPoint(64);
        return v74;
FuzzerInjectionPoint(65);
    }
FuzzerInjectionPoint(66);
    f59(v55, C22, v54);
FuzzerInjectionPoint(67);
    f59();
FuzzerInjectionPoint(68);
    f59(C22, v55, v58);
FuzzerInjectionPoint(69);
    new Int8Array(5);
FuzzerInjectionPoint(70);
    new Int8Array(5);
FuzzerInjectionPoint(71);
    new Float64Array(256);
FuzzerInjectionPoint(72);
    const v87 = [4,129,4294967295,127,536870888,65537,-34973,-2147483648,-58606,-2147483647];
FuzzerInjectionPoint(73);
    const v88 = [-16787,-1098236850];
FuzzerInjectionPoint(74);
    [1073741824,36407,-29042,-10,-39735];
FuzzerInjectionPoint(75);
    function F90(a92, a93) {
FuzzerInjectionPoint(76);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(77);
        this.f = a92;
FuzzerInjectionPoint(78);
        this.g = a92;
FuzzerInjectionPoint(79);
    }
FuzzerInjectionPoint(80);
    new F90(v88, v87);
FuzzerInjectionPoint(81);
    new C22(v87, v87);
FuzzerInjectionPoint(82);
    const v96 = new F90(v87, v87);
FuzzerInjectionPoint(83);
    [v96,v88,[v87,1e-15,0.7445986454425726,v88,-207.33561035990272],-207.33561035990272];
FuzzerInjectionPoint(84);
    [-207.33561035990272,v88];
FuzzerInjectionPoint(85);
    const v106 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

        0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0E,

        0x02, 0x60, 0x06, 0x7D, 0x7E, 0x7E, 0x7E, 0x7D, 0x7E, 0x00,

        0x60, 0x01, 0x7C, 0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00,

        0x05, 0x03, 0x01, 0x04, 0x07, 0x0D, 0x05, 0x02, 0x00, 0x00,

        0x00, 0x01, 0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01,

        0x00, 0x0A, 0x01, 0x00,

    ])));
FuzzerInjectionPoint(93);
    v106.exports;
FuzzerInjectionPoint(94);
    gc();
FuzzerInjectionPoint(95);
    const v116 = {

        [0.0](a114, a115) {
FuzzerInjectionPoint(97);
        },

    };
FuzzerInjectionPoint(99);
    return v116;
FuzzerInjectionPoint(100);
}
FuzzerInjectionPoint(101);
const v117 = f16();
FuzzerInjectionPoint(102);
const v118 = { ...v117, 268435456: f16 };