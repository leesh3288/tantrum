
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Int32Array(579);
FuzzerInjectionPoint(2);
new Int32Array(93);
FuzzerInjectionPoint(3);
new Int8Array(5);
FuzzerInjectionPoint(4);
[29297,-4294967297,2147483647,-617135204,9,-10,1370097103,-46886,536870887];
FuzzerInjectionPoint(5);
[-103572078,10,1073741825];
FuzzerInjectionPoint(6);
[4096,505651117,8];
FuzzerInjectionPoint(7);
[-65537,536870888,8,-1073741824,-40273,439523837,-10,1024,129];
FuzzerInjectionPoint(8);
[3,-1,512,9082,4294967295,-3,-2147483647,129];
FuzzerInjectionPoint(9);
[129,-4294967296,1165285361,10000,4294967297,-9223372036854775807,-9932,5];

function f20() {
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
const v24 = { 15: -532849.2521237191, ..."TeAz", 1065736410: 1000000000.0 };
FuzzerInjectionPoint(13);
function f26() {
FuzzerInjectionPoint(14);
    return 1073741824;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
[-926.9040540719922];
FuzzerInjectionPoint(17);
[-576934.4303782897,1.0316715503680758e+308,-1000000000.0,-4.4213448011375393e+307,-2.2250738585072014e-308,Infinity,Infinity,2.220446049250313e-16,2.2250738585072014e-308,-1000.0];
FuzzerInjectionPoint(18);
[679243.0110809095];
FuzzerInjectionPoint(19);
new Uint8Array(Uint8Array);
FuzzerInjectionPoint(20);
new BigInt64Array(128);
FuzzerInjectionPoint(21);
const v40 = new Uint8ClampedArray(2);
FuzzerInjectionPoint(22);
const v43 = { ...v40 };
FuzzerInjectionPoint(23);
function f44() {
FuzzerInjectionPoint(24);
    const v45 = [11,-46062,11,8402];
FuzzerInjectionPoint(25);
    for (let v46 = 0; v46 < 5; v46++) {
FuzzerInjectionPoint(26);
        v45[v46];
FuzzerInjectionPoint(27);
    }
FuzzerInjectionPoint(28);
    function f49(a50) {
FuzzerInjectionPoint(29);
        a50 != a50;
FuzzerInjectionPoint(30);
        const v54 = {

            set b(a53) {
FuzzerInjectionPoint(32);
                super[a53] = this;
FuzzerInjectionPoint(33);
                Uint8ClampedArray.c = a50;
FuzzerInjectionPoint(34);
            },

        };
FuzzerInjectionPoint(36);
        return -4294967295;
FuzzerInjectionPoint(37);
    }
FuzzerInjectionPoint(38);
    f49(-4294967295);
FuzzerInjectionPoint(39);
}
FuzzerInjectionPoint(40);
const v58 = new Uint8Array(3118);
FuzzerInjectionPoint(41);
Uint8ClampedArray.d = Uint8ClampedArray;
FuzzerInjectionPoint(42);
const v63 = new Uint16Array(2713);
FuzzerInjectionPoint(43);
try { new Uint8ClampedArray(2713, v63); } catch (e) {}
FuzzerInjectionPoint(44);
const v66 = new Date();
FuzzerInjectionPoint(45);
function f67() {
FuzzerInjectionPoint(46);
    return v66;
FuzzerInjectionPoint(47);
}
FuzzerInjectionPoint(48);
Uint8ClampedArray.d = Uint8ClampedArray;
FuzzerInjectionPoint(49);
const v68 = new Uint8ClampedArray(257);
FuzzerInjectionPoint(50);
new Uint8ClampedArray(1);
FuzzerInjectionPoint(51);
const v76 = new Date();
FuzzerInjectionPoint(52);
v76.setUTCSeconds(v76, 4294967296);
FuzzerInjectionPoint(53);
new Uint16Array(4096);
FuzzerInjectionPoint(54);
try { new Array(Uint8ClampedArray); } catch (e) {}
FuzzerInjectionPoint(55);
const v88 = Array(122);
FuzzerInjectionPoint(56);
v88[40] = v88;
FuzzerInjectionPoint(57);
const v89 = [-1000000000000.0,2.0,-1e-15,-5.0050640670918645];
FuzzerInjectionPoint(58);
const v90 = [3.0,-4.0,1.7976931348623157e+308,-1.0,-7.081833756406592];
FuzzerInjectionPoint(59);
try { v90.slice(3118, 1); } catch (e) {}
FuzzerInjectionPoint(60);
const v92 = [-596992.2717851705,1.3656356845740762e+308];
FuzzerInjectionPoint(61);
const v93 = v92[1];
FuzzerInjectionPoint(62);
const v96 = gc();
FuzzerInjectionPoint(63);
const v98 = {

    [v96]: v96,

    d: WeakSet,

    [WeakSet]: 1073741824,

    h: v96,

    [1073741824]: WeakSet,

    b: WeakSet,

};
FuzzerInjectionPoint(71);
function f99(a100, a101) {
FuzzerInjectionPoint(72);
    a100[79] = v68;
FuzzerInjectionPoint(73);
    a100[1] = a100;
FuzzerInjectionPoint(74);
    a101 / a101;
FuzzerInjectionPoint(75);
    Object.defineProperty(a100, 82, { writable: true, enumerable: true, value: -4294967295 });
FuzzerInjectionPoint(76);
    const v103 = { 3: v90, [v88]: v89, __proto__: v88, ...v92 };
FuzzerInjectionPoint(77);
    v103[24] = 549187200;
FuzzerInjectionPoint(78);
    return v103;
FuzzerInjectionPoint(79);
}
FuzzerInjectionPoint(80);
v93.length;
FuzzerInjectionPoint(81);
f99(v92);
FuzzerInjectionPoint(82);
const v106 = f99(v88);
FuzzerInjectionPoint(83);
let v107 = 1.821795989686298e+307;
FuzzerInjectionPoint(84);
--v107;
FuzzerInjectionPoint(85);
function F110() {
FuzzerInjectionPoint(86);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(87);
    function* f114(a115, a116, a117, a118) {
FuzzerInjectionPoint(88);
        yield* Int8Array;
FuzzerInjectionPoint(89);
        return arguments;
FuzzerInjectionPoint(90);
    }
FuzzerInjectionPoint(91);
    const t90 = f114();
FuzzerInjectionPoint(92);
    t90[Symbol] = 1073741823;
FuzzerInjectionPoint(93);
}
FuzzerInjectionPoint(94);
const v129 = f99(v89);
FuzzerInjectionPoint(95);
try { v129.slice(v106, v129); } catch (e) {}
FuzzerInjectionPoint(96);
f44(undefined, v58);
FuzzerInjectionPoint(97);
f44();
FuzzerInjectionPoint(98);
%OptimizeMaglevOnNextCall(f44);
FuzzerInjectionPoint(99);
f44();