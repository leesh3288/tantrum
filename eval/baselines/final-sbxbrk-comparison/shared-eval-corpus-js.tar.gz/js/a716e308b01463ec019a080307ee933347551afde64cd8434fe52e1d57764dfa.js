
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    function f5(a6) {
FuzzerInjectionPoint(3);
        const v7 = a6 / a6;
FuzzerInjectionPoint(4);
        const v8 = %WasmStruct();
FuzzerInjectionPoint(5);
        return v7;
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    return f5(10);
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v11 = f0(f0(), f0, f0);
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(11);
f0(v11, f0, f0);
FuzzerInjectionPoint(12);