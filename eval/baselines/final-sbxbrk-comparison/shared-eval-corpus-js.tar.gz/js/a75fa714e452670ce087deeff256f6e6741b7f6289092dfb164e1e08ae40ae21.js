
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new SharedArrayBuffer(491);
FuzzerInjectionPoint(2);
const v4 = new Uint8ClampedArray(v2);
FuzzerInjectionPoint(3);
v4.reverse();
FuzzerInjectionPoint(4);