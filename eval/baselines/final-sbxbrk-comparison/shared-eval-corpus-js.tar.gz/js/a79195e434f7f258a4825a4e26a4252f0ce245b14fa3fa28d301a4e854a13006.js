
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [268435439,-35508,8,65537,-1024,29403,4294967297,47867,129,5];
FuzzerInjectionPoint(2);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(3);
    const v5 = [-1000000000000.0,-367.81301734010196,-476.74454452527516,-2.6076772957175923e+306,1.7976931348623157e+308,0.11176331082589741,Infinity,1000000.0];
FuzzerInjectionPoint(4);
    let v6;
FuzzerInjectionPoint(5);
    try { v6 = v5.every(); } catch (e) {}
FuzzerInjectionPoint(6);
    v6 || v0;
FuzzerInjectionPoint(7);
    return f1;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f1(f1(v0, v0, v0), v0, v0);
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(11);
f1(f1, v0, f1);
FuzzerInjectionPoint(12);