
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
WeakSet.length = WeakSet;
FuzzerInjectionPoint(2);
new WeakSet();
FuzzerInjectionPoint(3);
const t2 = "n";
FuzzerInjectionPoint(4);
t2[0] = "n";
FuzzerInjectionPoint(5);
function F6() {
FuzzerInjectionPoint(6);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(7);
    const v8 = this.constructor;
FuzzerInjectionPoint(8);
    try { new v8(); } catch (e) {}
FuzzerInjectionPoint(9);
    constructor.e = 4;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
class C11 extends F6 {

}
FuzzerInjectionPoint(13);
try { SharedArrayBuffer.bind(F6); } catch (e) {}
FuzzerInjectionPoint(14);
function f19() {
FuzzerInjectionPoint(15);
    const v20 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(16);
    for (let v21 = 0; v21 < 5; v21++) {
FuzzerInjectionPoint(17);
        const v22 = v20[v21];
FuzzerInjectionPoint(18);
        const v23 = v22 ^ v22;
FuzzerInjectionPoint(19);
        v23 & v23;
FuzzerInjectionPoint(20);
        v22 * v22;
FuzzerInjectionPoint(21);
    }
FuzzerInjectionPoint(22);
}
FuzzerInjectionPoint(23);
const v26 = f19();
FuzzerInjectionPoint(24);
v26 ?? v26;
FuzzerInjectionPoint(25);
f19();
FuzzerInjectionPoint(26);
class C29 {

}
FuzzerInjectionPoint(28);
try { C29.apply(Map, WeakMap); } catch (e) {}
FuzzerInjectionPoint(29);
class C31 extends WeakSet {

    static #g = "bigint";

    #d = "oUN";

}
FuzzerInjectionPoint(33);
128 - 128;
FuzzerInjectionPoint(34);
class C36 {

    static 221 = "f";

    6;

    static ["bigint"] = "f";

    static g = 128;

    [-1];

}
FuzzerInjectionPoint(41);
const v37 = new C36();
FuzzerInjectionPoint(42);
v37[6];
FuzzerInjectionPoint(43);
try { new C31(); } catch (e) {}
FuzzerInjectionPoint(44);
const v40 = new C31();
FuzzerInjectionPoint(45);
try { v40.has("oUN"); } catch (e) {}
FuzzerInjectionPoint(46);
new C31();
FuzzerInjectionPoint(47);
new C31();
FuzzerInjectionPoint(48);
2371 >> 2371;
FuzzerInjectionPoint(49);
-2371;
FuzzerInjectionPoint(50);
function f47() {
FuzzerInjectionPoint(51);
    -163530867 === -163530867;
FuzzerInjectionPoint(52);
    function f50(a51) {
FuzzerInjectionPoint(53);
        a51 / a51;
FuzzerInjectionPoint(54);
        return -163530867;
FuzzerInjectionPoint(55);
    }
FuzzerInjectionPoint(56);
    const v53 = f50?.constructor;
FuzzerInjectionPoint(57);
    try { new v53(-2); } catch (e) {}
FuzzerInjectionPoint(58);
    let v55;
FuzzerInjectionPoint(59);
    try { v55 = new v53("oUN"); } catch (e) {}
FuzzerInjectionPoint(60);
    const v56 = v55?.constructor;
FuzzerInjectionPoint(61);
    try { new v56(C11); } catch (e) {}
FuzzerInjectionPoint(62);
    f50.arguments;
FuzzerInjectionPoint(63);
    let v59;
FuzzerInjectionPoint(64);
    try {
FuzzerInjectionPoint(65);
    const t0 = 2371;
FuzzerInjectionPoint(66);
    v59 = t0();
FuzzerInjectionPoint(67);
    } catch (e) {}
FuzzerInjectionPoint(68);
    v59 ?? v59;
FuzzerInjectionPoint(69);
    const v61 = v59 ?? v59;
FuzzerInjectionPoint(70);
    v61 ?? v61;
FuzzerInjectionPoint(71);
    const v65 = new Uint32Array(3127);
FuzzerInjectionPoint(72);
    return v65;
FuzzerInjectionPoint(73);
    for (let v66 = 0; v66 < 5; v66++) {
FuzzerInjectionPoint(74);
    }
FuzzerInjectionPoint(75);
}
FuzzerInjectionPoint(76);
f47();
FuzzerInjectionPoint(77);
let v68;
FuzzerInjectionPoint(78);
try { v68 = f47(); } catch (e) {}
FuzzerInjectionPoint(79);
v68 ?? v68;
FuzzerInjectionPoint(80);
%OptimizeMaglevOnNextCall(f47);
FuzzerInjectionPoint(81);
const v70 = f47();
FuzzerInjectionPoint(82);
v70.h = v70;