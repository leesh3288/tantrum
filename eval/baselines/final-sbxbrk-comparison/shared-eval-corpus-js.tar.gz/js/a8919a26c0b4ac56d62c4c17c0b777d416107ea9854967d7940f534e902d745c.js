
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    try {
FuzzerInjectionPoint(3);
        f0();
FuzzerInjectionPoint(4);
    } catch(e2) {
FuzzerInjectionPoint(5);
        function f3() {
FuzzerInjectionPoint(6);
            return f3;
FuzzerInjectionPoint(7);
        }
FuzzerInjectionPoint(8);
        class C4 extends f3 {

            static {
FuzzerInjectionPoint(10);
                const v7 = new Uint8ClampedArray();
FuzzerInjectionPoint(11);
                function f8(a9, a10) {
FuzzerInjectionPoint(12);
                    const v13 = ("63515").constructor.fromCodePoint("63515");
FuzzerInjectionPoint(13);
                    const v14 = v13.padStart("63515");
FuzzerInjectionPoint(14);
                    return v14.replace(v13, v14);
FuzzerInjectionPoint(15);
                }
FuzzerInjectionPoint(16);
                v7.toString = f8;
FuzzerInjectionPoint(17);
                v7[643] = v7;
FuzzerInjectionPoint(18);
            }

        }
FuzzerInjectionPoint(20);
    }
FuzzerInjectionPoint(21);
    return f0;
FuzzerInjectionPoint(22);
}
FuzzerInjectionPoint(23);
f0();