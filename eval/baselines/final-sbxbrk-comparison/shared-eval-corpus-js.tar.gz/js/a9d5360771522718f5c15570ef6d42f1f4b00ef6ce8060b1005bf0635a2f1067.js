
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Int32Array(268435439);
FuzzerInjectionPoint(2);
class C4 extends Date {

}