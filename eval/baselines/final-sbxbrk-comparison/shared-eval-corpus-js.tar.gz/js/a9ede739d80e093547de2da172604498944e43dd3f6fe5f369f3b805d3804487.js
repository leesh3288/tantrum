
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f2(a3) {
FuzzerInjectionPoint(5);
    return Date;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
F0.toString = f2;
FuzzerInjectionPoint(8);
function f5() {
FuzzerInjectionPoint(9);
    return F0;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
function f6(a7) {
FuzzerInjectionPoint(12);
    return a7;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
Object.defineProperty(F0, "length", { get: f5, set: f6 });
FuzzerInjectionPoint(15);
F0.raw = F0;
FuzzerInjectionPoint(16);
class C11 extends Date().constructor {

}
FuzzerInjectionPoint(18);
try { C11.raw(F0); } catch (e) {}