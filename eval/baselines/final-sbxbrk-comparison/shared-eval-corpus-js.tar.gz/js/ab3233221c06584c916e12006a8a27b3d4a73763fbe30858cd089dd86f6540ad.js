
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-1000000000000.0,-134743.2420800618,-1000000000000.0,1000.0,-460121.2231126975];
FuzzerInjectionPoint(2);
function f1() {
FuzzerInjectionPoint(3);
    const v3 = [103381.42790501681,544.4174032405106,655.9290303272815];
FuzzerInjectionPoint(4);
    function f4(a5, a6) {
FuzzerInjectionPoint(5);
        const v7 = { __proto__: v0, b: v3 };
FuzzerInjectionPoint(6);
        v3[a5];
FuzzerInjectionPoint(7);
        return v0;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    f4("-256");
FuzzerInjectionPoint(10);
    f4();
FuzzerInjectionPoint(11);
    return f1;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f1();
FuzzerInjectionPoint(14);
f1();
FuzzerInjectionPoint(15);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(16);
f1();
FuzzerInjectionPoint(17);