
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
SharedArrayBuffer[0] = -6.070706725569826e+306;
FuzzerInjectionPoint(2);
const v6 = new SharedArrayBuffer(153, { maxByteLength: 153 });
FuzzerInjectionPoint(3);
const v7 = new Float32Array(v6);
FuzzerInjectionPoint(4);
const v9 = new Float64Array(SharedArrayBuffer);
FuzzerInjectionPoint(5);
v7.set(v9);
FuzzerInjectionPoint(6);