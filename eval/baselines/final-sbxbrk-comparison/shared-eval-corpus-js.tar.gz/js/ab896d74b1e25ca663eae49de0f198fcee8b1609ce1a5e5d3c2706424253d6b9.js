
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v5 = [536870912,4];
FuzzerInjectionPoint(3);
    v5 >> 45324;
FuzzerInjectionPoint(4);
    const v9 = Date();
FuzzerInjectionPoint(5);
    const v15 = {

        [Symbol]() {
FuzzerInjectionPoint(7);
            const v14 = {

                [v9](a12) {
FuzzerInjectionPoint(9);
                    v9(v5);
FuzzerInjectionPoint(10);
                },

            };
FuzzerInjectionPoint(12);
        },

    };
FuzzerInjectionPoint(14);
    return Date;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
const v16 = f0(f0, f0, f0);
FuzzerInjectionPoint(17);
f0(f0, f0, f0);
FuzzerInjectionPoint(18);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(19);
f0(f0, v16, v16);