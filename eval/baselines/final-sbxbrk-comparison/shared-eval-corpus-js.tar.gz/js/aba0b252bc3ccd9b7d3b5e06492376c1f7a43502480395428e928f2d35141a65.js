
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3) {
FuzzerInjectionPoint(2);
    const v5 = Array(a3);
FuzzerInjectionPoint(3);
    const v7 = {

        __proto__: v5,

        get a() {
FuzzerInjectionPoint(6);
            return this;
FuzzerInjectionPoint(7);
        },

    };
FuzzerInjectionPoint(9);
    return a2;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
WeakSet[Symbol.toPrimitive] = f1;
FuzzerInjectionPoint(12);
function f10(a11, a12) {
FuzzerInjectionPoint(13);
    const v13 = { [WeakSet]: a12 };
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
const v16 = new Uint8Array(255);
FuzzerInjectionPoint(16);
v16.find(f10);