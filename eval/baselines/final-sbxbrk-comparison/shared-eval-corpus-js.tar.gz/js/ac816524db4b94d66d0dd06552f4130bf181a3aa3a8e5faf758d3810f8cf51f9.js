
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = Uint8ClampedArray.__proto__;
FuzzerInjectionPoint(2);
try { v1(); } catch (e) {}
FuzzerInjectionPoint(3);