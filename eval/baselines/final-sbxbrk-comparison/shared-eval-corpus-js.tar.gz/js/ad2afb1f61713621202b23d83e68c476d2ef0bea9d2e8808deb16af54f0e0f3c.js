
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    class C2 {

    }
FuzzerInjectionPoint(4);
    C2.name = C2;
FuzzerInjectionPoint(5);
    Math.abs(-1000.0);
FuzzerInjectionPoint(6);
    eval();
FuzzerInjectionPoint(7);
    return -1000.0;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);
f1();
FuzzerInjectionPoint(11);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(12);
f1();