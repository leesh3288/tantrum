
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Date();
FuzzerInjectionPoint(2);
const v3 = WeakMap.constructor;
FuzzerInjectionPoint(3);
try { v3(v1); } catch (e) {}
FuzzerInjectionPoint(4);