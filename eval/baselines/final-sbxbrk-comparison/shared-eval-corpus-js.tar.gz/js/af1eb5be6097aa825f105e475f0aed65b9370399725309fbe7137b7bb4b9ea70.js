
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = 25176;
FuzzerInjectionPoint(2);
v0--;
FuzzerInjectionPoint(3);
const v3 = Math.acosh();
FuzzerInjectionPoint(4);
function f6(a7, a8, a9) {
FuzzerInjectionPoint(5);
    for (let v10 = 0; v10 < 5; v10++) {
FuzzerInjectionPoint(6);
        const v11 = v10 % v0;
FuzzerInjectionPoint(7);
        let v12;
FuzzerInjectionPoint(8);
        try { v12 = ("55855").repeat(v3); } catch (e) {}
FuzzerInjectionPoint(9);
        const v13 = v12.slice(v12);
FuzzerInjectionPoint(10);
        try { v13(v11); } catch (e) {}
FuzzerInjectionPoint(11);
    }
FuzzerInjectionPoint(12);
    return a8;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
const t13 = f6(4, f6);
FuzzerInjectionPoint(15);
const v16 = t13();
FuzzerInjectionPoint(16);
%OptimizeFunctionOnNextCall(f6);
FuzzerInjectionPoint(17);
f6("55855", Math, v16);
FuzzerInjectionPoint(18);