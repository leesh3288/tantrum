
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[-5.076625675905135,-4.2693864251855666e+307,-4.0,1.2082040232537916e+308,2.0,-3.0,-2.220446049250313e-16];
FuzzerInjectionPoint(2);
[-101929.16008780431,-2.220446049250313e-16,0.3922064203833532,-940589.2954094579];
FuzzerInjectionPoint(3);
[-1000000000.0];
FuzzerInjectionPoint(4);
new BigUint64Array(2355);
FuzzerInjectionPoint(5);
new Float32Array(4082);
FuzzerInjectionPoint(6);
new Uint8Array(199);
FuzzerInjectionPoint(7);
class C15 {

    #e;

    static #c;

    get c() {
FuzzerInjectionPoint(11);
        this != this;
FuzzerInjectionPoint(12);
        new Uint16Array(10);
FuzzerInjectionPoint(13);
        new Uint32Array(128);
FuzzerInjectionPoint(14);
        new BigUint64Array(16);
FuzzerInjectionPoint(15);
        return "d";
FuzzerInjectionPoint(16);
    }

}
FuzzerInjectionPoint(18);
const v26 = new C15();
FuzzerInjectionPoint(19);
let v27 = new C15();
FuzzerInjectionPoint(20);
const v28 = new C15();
FuzzerInjectionPoint(21);
class C29 extends C15 {

    static #valueOf(a31, a32) {
FuzzerInjectionPoint(23);
        super[v27 = C15] = v28;
FuzzerInjectionPoint(24);
        ("b")[a32];
FuzzerInjectionPoint(25);
        typeof this === "undefined";
FuzzerInjectionPoint(26);
        return "b";
FuzzerInjectionPoint(27);
    }

    [v26] = v26;

    static ["d"];

    ["a"] = "a";

    static 16;

    static #d;

    [v27];

}
FuzzerInjectionPoint(35);
const v37 = new C29();
FuzzerInjectionPoint(36);
const v38 = new C29();
FuzzerInjectionPoint(37);
new C29();
FuzzerInjectionPoint(38);
function f40(a41, a42) {
FuzzerInjectionPoint(39);
    const v55 = {

        ...a41,

        c: v38,

        e: v38,

        __proto__: C15,

        [a41]: C15,

        ...a42,

        ["a"](a44, a45, a46, a47) {
FuzzerInjectionPoint(47);
            const v48 = (a49, a50, a51) => {
FuzzerInjectionPoint(48);
                return a44;
FuzzerInjectionPoint(49);
            };
FuzzerInjectionPoint(50);
            try { a44(); } catch (e) {}
FuzzerInjectionPoint(51);
            a47 = this;
FuzzerInjectionPoint(52);
            super[v37];
FuzzerInjectionPoint(53);
            /A(?:ab)|cde(ab|cde)(?=)/musi;
FuzzerInjectionPoint(54);
        },

    };
FuzzerInjectionPoint(56);
}
FuzzerInjectionPoint(57);
const v56 = f40(C29);
FuzzerInjectionPoint(58);
f40(C29, "b");
FuzzerInjectionPoint(59);
const v58 = f40("a", "b");
FuzzerInjectionPoint(60);
try { v58.expm1(v58, v27, v56, "a", "b"); } catch (e) {}
FuzzerInjectionPoint(61);
[-1000000.0,1.0,-683984.3733051163,-1000000000000.0,-4.0,-1000000000000.0];
FuzzerInjectionPoint(62);
[1.3487828874046755e+307,1000.0,0.8769554921247963,0.8450726927579159,0.7372829988312185,8.297456442527127e+306,-7.196878599047346e+307,5.0,-781133.9843141905];
FuzzerInjectionPoint(63);
[171260.72483048798,-1.0,1.5757540821742578e+308,-6.9440018870925595,0.5644057724267428,6.928324867534705,0.7740005607149084,-1000000000000.0,-1.7976931348623157e+308,4.0];
FuzzerInjectionPoint(64);
new f40();
FuzzerInjectionPoint(65);
function F64() {
FuzzerInjectionPoint(66);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(67);
}
FuzzerInjectionPoint(68);
new F64();
FuzzerInjectionPoint(69);
new F64();
FuzzerInjectionPoint(70);
new F64();
FuzzerInjectionPoint(71);
const v71 = [];
FuzzerInjectionPoint(72);
[];
FuzzerInjectionPoint(73);
[];
FuzzerInjectionPoint(74);
delete v71[10];
FuzzerInjectionPoint(75);
const v75 = 0.060497403807598715 ?? -0.0;
FuzzerInjectionPoint(76);
try { v75(); } catch (e) {}
FuzzerInjectionPoint(77);
/xyz{1,}?/dvgy;
FuzzerInjectionPoint(78);
/01P(x)(x)(x)\3*\u0060/mvsgy;