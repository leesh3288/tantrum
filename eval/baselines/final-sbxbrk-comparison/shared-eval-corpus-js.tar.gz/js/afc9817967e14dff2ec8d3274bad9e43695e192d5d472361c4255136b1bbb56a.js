
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [-4.0640450553924473e+307,1.7033827326478033e+308,1000.0,-5.0];
FuzzerInjectionPoint(2);
function f2(a3) {
FuzzerInjectionPoint(3);
    const t2 = v1.constructor;
FuzzerInjectionPoint(4);
    t2(-65536, 8.380593020132356);
FuzzerInjectionPoint(5);
    return 8.380593020132356;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f2(v1);
FuzzerInjectionPoint(8);
f2();
FuzzerInjectionPoint(9);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(10);
f2();
FuzzerInjectionPoint(11);