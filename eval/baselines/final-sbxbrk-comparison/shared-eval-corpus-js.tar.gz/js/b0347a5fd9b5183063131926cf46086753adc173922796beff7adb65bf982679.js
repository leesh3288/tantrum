
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0(a2, a3, a4) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    ("63515").constructor.fromCodePoint("63515").strike();
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
new F0(F0, F0, F0);
FuzzerInjectionPoint(6);