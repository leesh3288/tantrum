
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    let v1 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(3);
    const v2 = [];
FuzzerInjectionPoint(4);
    function f5(a6, a7) {
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    const v8 = f5();
FuzzerInjectionPoint(7);
    function f10(a11, a12, a13) {
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    const v14 = f10();
FuzzerInjectionPoint(10);
    let v15 = f10(v8, -19990, v8);
FuzzerInjectionPoint(11);
    const v21 = {

        ["-2057276655"](a19) {
FuzzerInjectionPoint(13);
            ({"b":v15,"c":a19,} = this);
FuzzerInjectionPoint(14);
            f10(-19990, 268435456, v14);
FuzzerInjectionPoint(15);
            super.c = v2;
FuzzerInjectionPoint(16);
        },

    };
FuzzerInjectionPoint(18);
    new Int8Array();
FuzzerInjectionPoint(19);
    try { f5(-19990, WeakMap, ...v2, ...v21); } catch (e) {}
FuzzerInjectionPoint(20);
    for (let v25 = 0; v25 < 5; v25++) {
FuzzerInjectionPoint(21);
        v1[v25];
FuzzerInjectionPoint(22);
        v1++;
FuzzerInjectionPoint(23);
    }
FuzzerInjectionPoint(24);
}
FuzzerInjectionPoint(25);
f0();
FuzzerInjectionPoint(26);
f0();
FuzzerInjectionPoint(27);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(28);
f0();