
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F1(a3, a4, a5) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    function f6(a7, a8) {
FuzzerInjectionPoint(4);
        const v10 = new Date();
FuzzerInjectionPoint(5);
        v10.timeZone = a3;
FuzzerInjectionPoint(6);
        v10.toLocaleTimeString(-2391, v10);
FuzzerInjectionPoint(7);
        return F1;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    this.constructor = f6;
FuzzerInjectionPoint(10);
    const v12 = this.constructor;
FuzzerInjectionPoint(11);
    try { v12(); } catch (e) {}
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
new F1(-2391);
FuzzerInjectionPoint(14);