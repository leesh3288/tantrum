
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Uint16Array(255);
FuzzerInjectionPoint(2);
try { Float32Array.from(Uint16Array); } catch (e) {}
FuzzerInjectionPoint(3);
const v6 = new Float32Array(1337);
FuzzerInjectionPoint(4);
try { v6.indexOf(Uint16Array); } catch (e) {}
FuzzerInjectionPoint(5);
let v8 = 2640;
FuzzerInjectionPoint(6);
v8++;
FuzzerInjectionPoint(7);
Uint8Array.BYTES_PER_ELEMENT = Uint8Array;
FuzzerInjectionPoint(8);
const v11 = new Uint8Array(v8);
FuzzerInjectionPoint(9);
try { v11.join(Uint8Array); } catch (e) {}
FuzzerInjectionPoint(10);
[-1756939485,-9007199254740992,64634,-536870912,9007199254740992,4294967296,-2147483649,14,-9223372036854775808];
FuzzerInjectionPoint(11);
[-9223372036854775808,-4294967296];
FuzzerInjectionPoint(12);
try { BigUint64Array.from(BigUint64Array); } catch (e) {}
FuzzerInjectionPoint(13);
const v20 = ([BigUint64Array,Int16Array,v8,1979,BigUint64Array])?.constructor;
FuzzerInjectionPoint(14);
try { new v20(Uint16Array); } catch (e) {}
FuzzerInjectionPoint(15);
const v23 = [[-65535,-65536,15,-4096,-9223372036854775808,1073741823,-39861,8,-50702,39914]];
FuzzerInjectionPoint(16);
let v25;
FuzzerInjectionPoint(17);
try { v25 = new BigInt64Array(v23); } catch (e) {}
FuzzerInjectionPoint(18);
v25 ?? v25;
FuzzerInjectionPoint(19);
[536870912,-22602,192962231,10000,11,-65536,-57066,629459192,-1];
FuzzerInjectionPoint(20);
-1685124192 / -1685124192;
FuzzerInjectionPoint(21);
BigInt64Array.BYTES_PER_ELEMENT;
FuzzerInjectionPoint(22);
function f35() {
FuzzerInjectionPoint(23);
    return f35;
FuzzerInjectionPoint(24);
}
FuzzerInjectionPoint(25);
class C36 {

    static [f35];

    #p(a38, a39) {
FuzzerInjectionPoint(28);
        a38.#p();
FuzzerInjectionPoint(29);
    }

    static {
FuzzerInjectionPoint(31);
        this.name;
FuzzerInjectionPoint(32);
        try {
FuzzerInjectionPoint(33);
            super.p();
FuzzerInjectionPoint(34);
        } catch(e44) {
FuzzerInjectionPoint(35);
            e44.f = e44;
FuzzerInjectionPoint(36);
        }
FuzzerInjectionPoint(37);
    }

}
FuzzerInjectionPoint(39);
const v51 = new Uint32Array(518);
FuzzerInjectionPoint(40);
function f52() {
FuzzerInjectionPoint(41);
    function f55() {
FuzzerInjectionPoint(42);
        const v58 = new Uint32Array();
FuzzerInjectionPoint(43);
        v58?.entries;
FuzzerInjectionPoint(44);
        v58[0] = v58;
FuzzerInjectionPoint(45);
        const v61 = !9;
FuzzerInjectionPoint(46);
        v61 && v61;
FuzzerInjectionPoint(47);
        const v63 = Math.sinh(v61);
FuzzerInjectionPoint(48);
        v63 * v63;
FuzzerInjectionPoint(49);
    }
FuzzerInjectionPoint(50);
    f55();
FuzzerInjectionPoint(51);
    f55();
FuzzerInjectionPoint(52);
    const v67 = Int8Array.from(v51);
FuzzerInjectionPoint(53);
    const v68 = new Int8Array(1354);
FuzzerInjectionPoint(54);
    v68[352] = v68;
FuzzerInjectionPoint(55);
    v68[1269] = v68;
FuzzerInjectionPoint(56);
    const v70 = new Int16Array(v67);
FuzzerInjectionPoint(57);
    return v70;
FuzzerInjectionPoint(58);
}
FuzzerInjectionPoint(59);
const v71 = f52();
FuzzerInjectionPoint(60);
f52();
FuzzerInjectionPoint(61);
%OptimizeMaglevOnNextCall(f52);
FuzzerInjectionPoint(62);
f52();
FuzzerInjectionPoint(63);
function f76(a77, a78, a79) {
FuzzerInjectionPoint(64);
    const v80 = [0.29320029455058827,169.47044626769048,293.3291998537377,-1.7976931348623157e+308,2.220446049250313e-16,1.7112838441019946e+308,918.5317832226006];
FuzzerInjectionPoint(65);
    const v96 = {

        [a77](a82, a83) {
FuzzerInjectionPoint(67);
        },

        p(a85, a86) {
FuzzerInjectionPoint(69);
        },

        get e() {
FuzzerInjectionPoint(71);
        },

        n(a89, a90, a91, a92) {
FuzzerInjectionPoint(73);
            v80.splice(0);
FuzzerInjectionPoint(74);
            return a91;
FuzzerInjectionPoint(75);
        },

        10: 1172,

        get f() {
FuzzerInjectionPoint(78);
        },

        get a() {
FuzzerInjectionPoint(80);
        },

    };
FuzzerInjectionPoint(82);
}
FuzzerInjectionPoint(83);
const v97 = f76(BigUint64Array);
FuzzerInjectionPoint(84);
try { v97.toSpliced(v71, f52); } catch (e) {}