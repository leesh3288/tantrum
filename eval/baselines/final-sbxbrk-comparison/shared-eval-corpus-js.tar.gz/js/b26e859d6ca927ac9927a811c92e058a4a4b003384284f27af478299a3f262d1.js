
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v1 = -1000.0;
FuzzerInjectionPoint(2);
class C4 {

    static {
FuzzerInjectionPoint(4);
        this.f = "a";
FuzzerInjectionPoint(5);
        try { new this(); } catch (e) {}
FuzzerInjectionPoint(6);
        let v8;
FuzzerInjectionPoint(7);
        try {
FuzzerInjectionPoint(8);
        const t0 = "a";
FuzzerInjectionPoint(9);
        v8 = t0(false, -2.0, -2.0, "a");
FuzzerInjectionPoint(10);
        } catch (e) {}
FuzzerInjectionPoint(11);
        v8 ?? v8;
FuzzerInjectionPoint(12);
        super.f = this;
FuzzerInjectionPoint(13);
    }

    set e(a11) {
FuzzerInjectionPoint(15);
        Object.defineProperty(this, "h", { configurable: true, value: "a" });
FuzzerInjectionPoint(16);
        const v15 = %WasmArray();
FuzzerInjectionPoint(17);
        const v20 = new ArrayBuffer(1024, { maxByteLength: 1073741825 });
FuzzerInjectionPoint(18);
        6n & -268435456n;
FuzzerInjectionPoint(19);
        new WeakSet();
FuzzerInjectionPoint(20);
        try {
FuzzerInjectionPoint(21);
            new WeakSet(v20);
FuzzerInjectionPoint(22);
        } catch(e26) {
FuzzerInjectionPoint(23);
        }
FuzzerInjectionPoint(24);
        new Uint8ClampedArray(v20);
FuzzerInjectionPoint(25);
    }

}
FuzzerInjectionPoint(27);
const v31 = Array(v1 = C4[3300]);
FuzzerInjectionPoint(28);
class C34 {

    1189984680;

    ["268435456"] = "268435456";

}
FuzzerInjectionPoint(32);
class C35 extends C34 {

    static #a = 11;

    1 = v31;

    d = C34;

    static #d = Array;

    static #f = Uint16Array;

}
FuzzerInjectionPoint(39);
new Uint16Array(16);
FuzzerInjectionPoint(40);
class C42 {

}
FuzzerInjectionPoint(42);
const v44 = {

    get c() {
FuzzerInjectionPoint(44);
        return this;
FuzzerInjectionPoint(45);
    },

};
FuzzerInjectionPoint(47);
for (const v45 in v44) {
FuzzerInjectionPoint(48);
}
FuzzerInjectionPoint(49);
new Int32Array(2617);
FuzzerInjectionPoint(50);
const v50 = new Date();
FuzzerInjectionPoint(51);
v50.valueOf = Array;
FuzzerInjectionPoint(52);
v50.setUTCDate(v50);
FuzzerInjectionPoint(53);
function f52(a53, a54, a55) {
FuzzerInjectionPoint(54);
    const v56 = {};
FuzzerInjectionPoint(55);
    v56[1] = -2.0;
FuzzerInjectionPoint(56);
    let v57 = v56[1];
FuzzerInjectionPoint(57);
    const v58 = v57--;
FuzzerInjectionPoint(58);
    return v58 / v58;
FuzzerInjectionPoint(59);
}
FuzzerInjectionPoint(60);
f52();
FuzzerInjectionPoint(61);
new Uint32Array(204);
FuzzerInjectionPoint(62);
[-595626508,1073741825,512,-2147483649,-1073741824,268686883,7,314064236];
FuzzerInjectionPoint(63);
[-31412,-65535,1024,1232227];
FuzzerInjectionPoint(64);
[-268435456,1024,-1498469657,-1,763716898,268435441,536870887,-2];
FuzzerInjectionPoint(65);
function f67() {
FuzzerInjectionPoint(66);
    const v77 = {

        m(a72) {
FuzzerInjectionPoint(68);
            for (let v74 = 0; v74 < 10; v74++) {
FuzzerInjectionPoint(69);
                "p" + v74;
FuzzerInjectionPoint(70);
            }
FuzzerInjectionPoint(71);
            return this;
FuzzerInjectionPoint(72);
        },

        ...-1.0,

        d: -1000000000.0,

        [-1.0]: 5.0,

        h: 5.0,

    };
FuzzerInjectionPoint(78);
    return v77;
FuzzerInjectionPoint(79);
}
FuzzerInjectionPoint(80);
const v78 = f67();
FuzzerInjectionPoint(81);
const v79 = f67(f67);
FuzzerInjectionPoint(82);
v79.constructor = f67;
FuzzerInjectionPoint(83);
const v80 = [4.690655618266559,-877078.1595718999,0.0];
FuzzerInjectionPoint(84);
const v83 = new Uint16Array(2983);
FuzzerInjectionPoint(85);
try { v83.lastIndexOf(v80); } catch (e) {}
FuzzerInjectionPoint(86);
new BigUint64Array();
FuzzerInjectionPoint(87);
174 + 174;
FuzzerInjectionPoint(88);
new Uint8ClampedArray();
FuzzerInjectionPoint(89);
const v92 = [];
FuzzerInjectionPoint(90);
let v94 = Infinity;
FuzzerInjectionPoint(91);
const v96 = -520.4720784109506 & -520.4720784109506;
FuzzerInjectionPoint(92);
function f97(a98) {
FuzzerInjectionPoint(93);
    -a98;
FuzzerInjectionPoint(94);
    const v108 = {

        valueOf(a101) {
FuzzerInjectionPoint(96);
            %VerifyType(v92);
FuzzerInjectionPoint(97);
            const v102 = a101(a98);
FuzzerInjectionPoint(98);
            v92[this] = a98;
FuzzerInjectionPoint(99);
            v102[8];
FuzzerInjectionPoint(100);
            return -353980.3709317227;
FuzzerInjectionPoint(101);
        },

        get a() {
FuzzerInjectionPoint(103);
            const v105 = [a98];
FuzzerInjectionPoint(104);
            return [[-353980.3709317227,v92,v94,v105,-353980.3709317227],v105];
FuzzerInjectionPoint(105);
        },

        ...v92,

        4147777986: a98,

    };
FuzzerInjectionPoint(109);
    return v108;
FuzzerInjectionPoint(110);
}
FuzzerInjectionPoint(111);
f97.length;
FuzzerInjectionPoint(112);
f97(-520.4720784109506);
FuzzerInjectionPoint(113);
f97(-353980.3709317227);
FuzzerInjectionPoint(114);
function f112() {
FuzzerInjectionPoint(115);
    function F113(a115, a116) {
FuzzerInjectionPoint(116);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(117);
        const v117 = [27100,3260,5];
FuzzerInjectionPoint(118);
        function f118() {
FuzzerInjectionPoint(119);
            function f119(a120) {
FuzzerInjectionPoint(120);
            }
FuzzerInjectionPoint(121);
            if (!(v117 == f118)) {
FuzzerInjectionPoint(122);
                a = f119;
FuzzerInjectionPoint(123);
            }
FuzzerInjectionPoint(124);
            return F113;
FuzzerInjectionPoint(125);
        }
FuzzerInjectionPoint(126);
        f118();
FuzzerInjectionPoint(127);
        f118();
FuzzerInjectionPoint(128);
        %OptimizeMaglevOnNextCall(f118);
FuzzerInjectionPoint(129);
        f118();
FuzzerInjectionPoint(130);
    }
FuzzerInjectionPoint(131);
    return v94;
FuzzerInjectionPoint(132);
}
FuzzerInjectionPoint(133);
f112.d = v92;
FuzzerInjectionPoint(134);
f112.d;
FuzzerInjectionPoint(135);
("bigint").trimEnd;
FuzzerInjectionPoint(136);
const v129 = [1.7976931348623157e+308,-4.0,-4.2175881447095165,NaN,9.488495122270616e+306,0.815559973799258,-1000000000.0,1000.0,1000.0,2.220446049250313e-16];
FuzzerInjectionPoint(137);
v129.g = v129;
FuzzerInjectionPoint(138);
v129[7] = v129;
FuzzerInjectionPoint(139);
class C130 {

    valueOf(a132, a133) {
FuzzerInjectionPoint(141);
        [v94,a133];
FuzzerInjectionPoint(142);
        -4;
FuzzerInjectionPoint(143);
        v94--;
FuzzerInjectionPoint(144);
        function f141(a142) {
FuzzerInjectionPoint(145);
            a142 / a142;
FuzzerInjectionPoint(146);
            return -163530867;
FuzzerInjectionPoint(147);
        }
FuzzerInjectionPoint(148);
        f141.arguments;
FuzzerInjectionPoint(149);
    }

}
FuzzerInjectionPoint(151);
new C130();
FuzzerInjectionPoint(152);
new C130();
FuzzerInjectionPoint(153);
new C130();
FuzzerInjectionPoint(154);
gc();
FuzzerInjectionPoint(155);
const v152 = new BigInt64Array(128);
FuzzerInjectionPoint(156);
const v153 = v152.constructor;
FuzzerInjectionPoint(157);
try { v153(v80, v78, v78); } catch (e) {}
FuzzerInjectionPoint(158);
const v155 = v152[7];
FuzzerInjectionPoint(159);
v155 * v155;
FuzzerInjectionPoint(160);
const v157 = v79.constructor;
FuzzerInjectionPoint(161);
let v158;
FuzzerInjectionPoint(162);
try { v158 = new v157(); } catch (e) {}
FuzzerInjectionPoint(163);
class C160 {

    static toString(a162) {
FuzzerInjectionPoint(165);
        this.valueOf = super.c;
FuzzerInjectionPoint(166);
        [9007199254740991,-1307076998,2,-1604490127,53672,-4294967296,1024328638,-29124,5685];
FuzzerInjectionPoint(167);
        [106959626,-5,10000,-32800,268435439];
FuzzerInjectionPoint(168);
    }

    static #a;

    static [8015] = v96;

    d;

}
FuzzerInjectionPoint(173);
const v166 = new C160();
FuzzerInjectionPoint(174);
function F167(a169, a170, a171, a172) {
FuzzerInjectionPoint(175);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(176);
    this.c = BigInt64Array;
FuzzerInjectionPoint(177);
    this.c = a171;
FuzzerInjectionPoint(178);
}
FuzzerInjectionPoint(179);
new F167(v96, v158, v78, v166);
FuzzerInjectionPoint(180);
function f175() {
FuzzerInjectionPoint(181);
    class C176 {

    }
FuzzerInjectionPoint(183);
    class C177 extends C176 {

    }
FuzzerInjectionPoint(185);
    function f178(a179, a180) {
FuzzerInjectionPoint(186);
        const v181 = { c: C177 };
FuzzerInjectionPoint(187);
        return f178;
FuzzerInjectionPoint(188);
    }
FuzzerInjectionPoint(189);
    f178(f178(C176, f175), f175);
FuzzerInjectionPoint(190);
    %OptimizeMaglevOnNextCall(f178);
FuzzerInjectionPoint(191);
    f178();
FuzzerInjectionPoint(192);
    return f178;
FuzzerInjectionPoint(193);
}
FuzzerInjectionPoint(194);
f175();
FuzzerInjectionPoint(195);
f175();
FuzzerInjectionPoint(196);
const v188 = new Uint32Array(3127);
FuzzerInjectionPoint(197);
v188.lastIndexOf(3.0);