
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
-4294967295 !== -4294967295;
FuzzerInjectionPoint(2);
class C5 {

    g;

    h = "1073741823";

    123;

    c = -4.221877022850638;

}
FuzzerInjectionPoint(8);
new C5();
FuzzerInjectionPoint(9);
try { Array.isArray(-4294967295); } catch (e) {}
FuzzerInjectionPoint(10);
const v10 = new Array(1);
FuzzerInjectionPoint(11);
try { v10.at(v10); } catch (e) {}
FuzzerInjectionPoint(12);
const v15 = [Array,"e","e"];
FuzzerInjectionPoint(13);
const v16 = [2,2,v10,v15,"return"];
FuzzerInjectionPoint(14);
const t12 = /()7/dvsgi;
FuzzerInjectionPoint(15);
t12[268435439] ??= -2028408876;
FuzzerInjectionPoint(16);
class C23 {

    static {
FuzzerInjectionPoint(18);
        let v25;
FuzzerInjectionPoint(19);
        try {
FuzzerInjectionPoint(20);
        const t0 = 1000;
FuzzerInjectionPoint(21);
        v25 = t0(1000, this, -2147483648, 1000, -9223372036854775807);
FuzzerInjectionPoint(22);
        } catch (e) {}
FuzzerInjectionPoint(23);
        const v26 = ("message").match(v25);
FuzzerInjectionPoint(24);
        this.g = v26;
FuzzerInjectionPoint(25);
        try { v26(v25, this, this); } catch (e) {}
FuzzerInjectionPoint(26);
    }

}
FuzzerInjectionPoint(28);
const v28 = ["e"];
FuzzerInjectionPoint(29);
try { v28.filter(v10); } catch (e) {}
FuzzerInjectionPoint(30);
class C33 {

    #e;

    static #c;

    get c() {
FuzzerInjectionPoint(34);
        this != this;
FuzzerInjectionPoint(35);
        new Uint16Array(10);
FuzzerInjectionPoint(36);
        new Uint32Array(128);
FuzzerInjectionPoint(37);
        const v44 = new BigUint64Array(16);
FuzzerInjectionPoint(38);
        const v45 = new v44();
FuzzerInjectionPoint(39);
        for (let v46 = 0; v46 < 10; v46++) {
FuzzerInjectionPoint(40);
            v45["p" + v46] = v46;
FuzzerInjectionPoint(41);
        }
FuzzerInjectionPoint(42);
        return "d";
FuzzerInjectionPoint(43);
    }

}
FuzzerInjectionPoint(45);
C33.length = C33;
FuzzerInjectionPoint(46);
const v49 = new C33();
FuzzerInjectionPoint(47);
let v50 = new C33();
FuzzerInjectionPoint(48);
const v51 = v50?.constructor;
FuzzerInjectionPoint(49);
try { new v51(); } catch (e) {}
FuzzerInjectionPoint(50);
const v53 = new C33();
FuzzerInjectionPoint(51);
class C54 extends C33 {

    static #valueOf(a56, a57) {
FuzzerInjectionPoint(53);
        super[v50 = C33] = v53;
FuzzerInjectionPoint(54);
        ("b")[a57];
FuzzerInjectionPoint(55);
        typeof this === "undefined";
FuzzerInjectionPoint(56);
        return "b";
FuzzerInjectionPoint(57);
    }

    [v49] = v49;

    static ["d"];

    [v50] = "a";

    static 16;

    static #d;

    [v50];

}
FuzzerInjectionPoint(65);
try { new C54(); } catch (e) {}
FuzzerInjectionPoint(66);
const v63 = new C54();
FuzzerInjectionPoint(67);
const v64 = new C54();
FuzzerInjectionPoint(68);
new C54();
FuzzerInjectionPoint(69);
const v68 = new Float32Array();
FuzzerInjectionPoint(70);
v68[1073741824] = Uint16Array;
FuzzerInjectionPoint(71);
class C69 {

}
FuzzerInjectionPoint(73);
function f70(a71, a72) {
FuzzerInjectionPoint(74);
    const v88 = {

        ...a71,

        c: v63,

        e: v64,

        __proto__: C33,

        [a71]: C33,

        ...a72,

        [a71](a74, a75, a76, a77) {
FuzzerInjectionPoint(82);
            const v78 = (a79, a80, a81) => {
FuzzerInjectionPoint(83);
                a81--;
FuzzerInjectionPoint(84);
                return a74;
FuzzerInjectionPoint(85);
            };
FuzzerInjectionPoint(86);
            try { a74(); } catch (e) {}
FuzzerInjectionPoint(87);
            a77 = this;
FuzzerInjectionPoint(88);
            super[v63];
FuzzerInjectionPoint(89);
            /A(?:ab)|cde(ab|cde)(?=)/musi;
FuzzerInjectionPoint(90);
            /Ua\Sc/udgiy;
FuzzerInjectionPoint(91);
            /[\0]/mdvsgiy;
FuzzerInjectionPoint(92);
            return v50;
FuzzerInjectionPoint(93);
        },

        ..."okGl",

        b: a72,

        ...v15,

        b: "1073741823",

        d: "1073741823",

    };
FuzzerInjectionPoint(100);
}
FuzzerInjectionPoint(101);
try { f70.bind(1); } catch (e) {}
FuzzerInjectionPoint(102);
const v90 = f70(C54, v50);
FuzzerInjectionPoint(103);
f70(C54, "b");
FuzzerInjectionPoint(104);
const v92 = f70("a", "b");
FuzzerInjectionPoint(105);
try { v92.expm1(v92, v50, v90, "a", "b"); } catch (e) {}
FuzzerInjectionPoint(106);
const v94 = [-1000000.0,1.0,-683984.3733051163,-1000000000000.0,-4.0,-1000000000000.0];
FuzzerInjectionPoint(107);
try { v94.flat(); } catch (e) {}
FuzzerInjectionPoint(108);
[1.3487828874046755e+307,1000.0,0.8769554921247963,0.8450726927579159,0.7372829988312185,8.297456442527127e+306,-7.196878599047346e+307,5.0,-781133.9843141905];
FuzzerInjectionPoint(109);
[171260.72483048798,-1.0,1.5757540821742578e+308,-6.9440018870925595,0.5644057724267428,6.928324867534705,0.7740005607149084,-1000000000000.0,-1.7976931348623157e+308,4.0];
FuzzerInjectionPoint(110);
function f101(a102, a103, a104) {
FuzzerInjectionPoint(111);
    const v105 = {

        3947: a102,

        [1467691842n]: a102,

        68: a103,

        256: -65536n,

        [a102]: "exec",

    };
FuzzerInjectionPoint(118);
}
FuzzerInjectionPoint(119);
f101(1467691842n);
FuzzerInjectionPoint(120);
function f107() {
FuzzerInjectionPoint(121);
    return "a";
FuzzerInjectionPoint(122);
}
FuzzerInjectionPoint(123);
f70(C54, v16);