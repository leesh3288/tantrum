
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

    constructor(a2, a3) {
FuzzerInjectionPoint(3);
        try {
FuzzerInjectionPoint(4);
            super.p();
FuzzerInjectionPoint(5);
        } catch(e5) {
FuzzerInjectionPoint(6);
            const t5 = e5.constructor;
FuzzerInjectionPoint(7);
            this.b = t5();
FuzzerInjectionPoint(8);
        }
FuzzerInjectionPoint(9);
    }

}
FuzzerInjectionPoint(11);
const v8 = new C0(C0, C0);
FuzzerInjectionPoint(12);
d8.serializer.serialize(v8);