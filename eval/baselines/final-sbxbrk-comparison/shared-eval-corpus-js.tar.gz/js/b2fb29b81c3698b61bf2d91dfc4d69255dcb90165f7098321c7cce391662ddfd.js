
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    function f4() {

        const v5 = {};

        return a2;

    }

    f0(f4, f4(), a3);

    return f0;

}

const v11 = new Worker(f0, { type: "function" });

v11.getMessage();