
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = "boolean" + -Infinity;
FuzzerInjectionPoint(2);
const v5 = this.Intl.Locale;
FuzzerInjectionPoint(3);
v5.numeric = v5;
FuzzerInjectionPoint(4);
const v6 = new v5(v3, v5);
FuzzerInjectionPoint(5);
const t4 = v6.constructor;
FuzzerInjectionPoint(6);
new t4(v6);
FuzzerInjectionPoint(7);