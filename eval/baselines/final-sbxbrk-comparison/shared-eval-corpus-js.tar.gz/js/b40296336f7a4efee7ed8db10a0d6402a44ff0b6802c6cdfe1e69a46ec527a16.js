
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    class C2 {

    }
FuzzerInjectionPoint(4);
    a = C2.toString(f0, C2);
FuzzerInjectionPoint(5);
    const t4 = {};
FuzzerInjectionPoint(6);
    t4.g = a;
FuzzerInjectionPoint(7);
    return f0;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f0(f0);
FuzzerInjectionPoint(10);
const v7 = f0(f0);
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(12);
f0(v7);