
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = Array(7);
FuzzerInjectionPoint(2);
const v8 = new SharedArrayBuffer(1453, { maxByteLength: 1453 });
FuzzerInjectionPoint(3);
const v9 = new Uint8Array(v8);
FuzzerInjectionPoint(4);
v9.set(v3);
FuzzerInjectionPoint(5);