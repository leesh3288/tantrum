
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = Array(109);

const t0 = d8.test.FastCAPI;

const v6 = new t0();

v6.add_all_overload(v2);