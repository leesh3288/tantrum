
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2(a3, a4) {
FuzzerInjectionPoint(2);
    return 2147483647;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
Object.defineProperty(Int16Array, "toString", { writable: true, configurable: true, value: f2 });
FuzzerInjectionPoint(5);
const v5 = [-379.63557389864764,-9969.356563432724,1.7976931348623157e+308,7.635636502150863,1.0,-Infinity,1.075075513877374e+308];
FuzzerInjectionPoint(6);
v5[4] = Int16Array;
FuzzerInjectionPoint(7);
v5.toLocaleString(f2).match(/48/vg);
FuzzerInjectionPoint(8);