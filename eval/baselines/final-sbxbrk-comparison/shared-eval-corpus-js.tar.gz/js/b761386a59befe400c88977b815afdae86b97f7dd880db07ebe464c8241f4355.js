
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Int32Array(Int32Array, Int32Array, Int32Array);
FuzzerInjectionPoint(2);
function f2(a3, a4, a5) {
FuzzerInjectionPoint(3);
    for (let v6 = 0; v6 < 5; v6++) {
FuzzerInjectionPoint(4);
        v1[v6] = v6;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    return a5;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f2();
FuzzerInjectionPoint(9);
const v8 = f2();
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(11);
f2(f2, v8, v1);
FuzzerInjectionPoint(12);