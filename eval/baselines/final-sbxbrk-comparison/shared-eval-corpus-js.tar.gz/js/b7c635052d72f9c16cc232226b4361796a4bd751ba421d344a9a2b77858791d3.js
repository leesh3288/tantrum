
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    return f0;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
class C2 extends f0 {

    constructor(a4, a5) {
FuzzerInjectionPoint(6);
        super();
FuzzerInjectionPoint(7);
        for (let v6 = 0; v6 < 5; v6++) {
FuzzerInjectionPoint(8);
            delete arguments[v6];
FuzzerInjectionPoint(9);
        }
FuzzerInjectionPoint(10);
    }

}
FuzzerInjectionPoint(12);
new C2(-1000000000.0, -1000000000.0);