
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new SharedArrayBuffer(2162);
FuzzerInjectionPoint(2);
const v4 = new Int16Array(v2);
FuzzerInjectionPoint(3);
new Uint32Array(v4);
FuzzerInjectionPoint(4);