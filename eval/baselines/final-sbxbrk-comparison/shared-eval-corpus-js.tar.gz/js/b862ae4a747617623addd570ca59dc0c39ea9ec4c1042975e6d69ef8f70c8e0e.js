
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    function f2() {
FuzzerInjectionPoint(3);
        function f3(a4) {
FuzzerInjectionPoint(4);
            function f5() {
FuzzerInjectionPoint(5);
                return eval(a4);
FuzzerInjectionPoint(6);
            }
FuzzerInjectionPoint(7);
            return f3;
FuzzerInjectionPoint(8);
        }
FuzzerInjectionPoint(9);
        const v8 = Array(Array);
FuzzerInjectionPoint(10);
        const v9 = { __proto__: v8 };
FuzzerInjectionPoint(11);
        f3(v8);
FuzzerInjectionPoint(12);
        Object.defineProperty([-128,2038265685,9,-3], 4294967295, { enumerable: true, set: eval });
FuzzerInjectionPoint(13);
    }
FuzzerInjectionPoint(14);
    function f13() {
FuzzerInjectionPoint(15);
        const v14 = new f2();
FuzzerInjectionPoint(16);
        const t15 = v14.constructor;
FuzzerInjectionPoint(17);
        t15();
FuzzerInjectionPoint(18);
        return Array;
FuzzerInjectionPoint(19);
    }
FuzzerInjectionPoint(20);
    f13();
FuzzerInjectionPoint(21);
    %OptimizeFunctionOnNextCall(f13);
FuzzerInjectionPoint(22);
    return f13();
FuzzerInjectionPoint(23);
}
FuzzerInjectionPoint(24);
f0();
FuzzerInjectionPoint(25);
f0();
FuzzerInjectionPoint(26);