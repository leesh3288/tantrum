
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Map();
FuzzerInjectionPoint(2);
const v2 = { f: v1 };
FuzzerInjectionPoint(3);
const v4 = d8.serializer;
FuzzerInjectionPoint(4);
const t3 = v4.serialize;
FuzzerInjectionPoint(5);
v4.deserialize(t3(v2));
FuzzerInjectionPoint(6);