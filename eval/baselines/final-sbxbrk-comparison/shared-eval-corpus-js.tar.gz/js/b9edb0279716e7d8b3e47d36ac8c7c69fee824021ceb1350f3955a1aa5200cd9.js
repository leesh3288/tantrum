
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = new Float32Array(256);
FuzzerInjectionPoint(2);
v3[231] = v3;
FuzzerInjectionPoint(3);
const v8 = new SharedArrayBuffer(2938, { maxByteLength: 1179478500 });
FuzzerInjectionPoint(4);
const v9 = new Uint8Array(v8);
FuzzerInjectionPoint(5);
v9.set(v3);
FuzzerInjectionPoint(6);