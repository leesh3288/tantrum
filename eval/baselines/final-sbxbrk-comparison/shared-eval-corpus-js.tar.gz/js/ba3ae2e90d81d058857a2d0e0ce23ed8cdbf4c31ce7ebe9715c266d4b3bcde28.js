
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [0.29320029455058827,169.47044626769048,293.3291998537377,-1.7976931348623157e+308,2.220446049250313e-16,1.7112838441019946e+308,918.5317832226006];
FuzzerInjectionPoint(2);
let v1;
FuzzerInjectionPoint(3);
try { v1 = v0.every(); } catch (e) {}
FuzzerInjectionPoint(4);
function f2() {
FuzzerInjectionPoint(5);
    const v3 = [-150175.65700318338,41357.99614778522,-7.925147192383583e+307,-1e-15,-310.002061066736,-1.0753367136516623,1.0];
FuzzerInjectionPoint(6);
    let v4;
FuzzerInjectionPoint(7);
    try { v4 = v3.toPrecision(v0, v1, v3, f2); } catch (e) {}
FuzzerInjectionPoint(8);
    for (let v5 = 0; v5 < 5; v5++) {
FuzzerInjectionPoint(9);
        v1 = v4;
FuzzerInjectionPoint(10);
    }
FuzzerInjectionPoint(11);
    return v4;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f2();
FuzzerInjectionPoint(14);
f2();
FuzzerInjectionPoint(15);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(16);
f2();
FuzzerInjectionPoint(17);