
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
-9973n ^ -9973n;
FuzzerInjectionPoint(2);
new Float32Array(9);
FuzzerInjectionPoint(3);
new Int16Array("string", 7n, "string");
FuzzerInjectionPoint(4);
1020 % 1020;
FuzzerInjectionPoint(5);
const v16 = Math.cos();
FuzzerInjectionPoint(6);
class C18 {

    h = "1073741823";

}
FuzzerInjectionPoint(9);
const v19 = new C18();
FuzzerInjectionPoint(10);
const v20 = { h: -8.667501055480269, ...v19, 2147483649: v16, f: v16 };
FuzzerInjectionPoint(11);
~256;
FuzzerInjectionPoint(12);
(256).BYTES_PER_ELEMENT;
FuzzerInjectionPoint(13);
let v25 = 0;
FuzzerInjectionPoint(14);
v25++;
FuzzerInjectionPoint(15);
v25 < 10;
FuzzerInjectionPoint(16);
const v31 = new Uint32Array(3127);
FuzzerInjectionPoint(17);
v31.BYTES_PER_ELEMENT;
FuzzerInjectionPoint(18);
const v34 = -2455;
FuzzerInjectionPoint(19);
v34 >> v34;
FuzzerInjectionPoint(20);
new BigInt64Array(2455);
FuzzerInjectionPoint(21);
function f38() {
FuzzerInjectionPoint(22);
    return v31;
FuzzerInjectionPoint(23);
}
FuzzerInjectionPoint(24);
function f39(a40, a41, a42, a43) {
FuzzerInjectionPoint(25);
    a42[127];
FuzzerInjectionPoint(26);
    ({})?.__defineGetter__;
FuzzerInjectionPoint(27);
}
FuzzerInjectionPoint(28);
const v47 = /[x]*/mudsg;
FuzzerInjectionPoint(29);
class C48 {

    constructor(a50) {
FuzzerInjectionPoint(31);
        const v51 = v47.exec();
FuzzerInjectionPoint(32);
        try { v51.filter(v51); } catch (e) {}
FuzzerInjectionPoint(33);
    }

}
FuzzerInjectionPoint(35);
class C53 extends C48 {

    static get a() {
FuzzerInjectionPoint(37);
    }

}
FuzzerInjectionPoint(39);
const v55 = new C53();
FuzzerInjectionPoint(40);
f39(3127, 256, f39, 2455);
FuzzerInjectionPoint(41);
const v58 = f38();
FuzzerInjectionPoint(42);
const v59 = f38();
FuzzerInjectionPoint(43);
try { v59.toString(); } catch (e) {}
FuzzerInjectionPoint(44);
const v61 = f38();
FuzzerInjectionPoint(45);
let v62 = f38();
FuzzerInjectionPoint(46);
[f39,v62,...BigInt64Array] = v58;
FuzzerInjectionPoint(47);
const v63 = new Uint32Array(v61, 2455);
FuzzerInjectionPoint(48);
v63[69] = v63;
FuzzerInjectionPoint(49);
new Date(v55, Math, -8.667501055480269, v55, Math, v55);
FuzzerInjectionPoint(50);
v55.length = Date;
FuzzerInjectionPoint(51);
let v66 = new Date();
FuzzerInjectionPoint(52);
try { v66(f39, v66); } catch (e) {}
FuzzerInjectionPoint(53);
v66++;
FuzzerInjectionPoint(54);
new WeakMap();
FuzzerInjectionPoint(55);
[-16,331888118,52077,536870912,-2147483649,536870887,-1565868922,0,-21341,7];
FuzzerInjectionPoint(56);
[8,1000,-128,-2147483648,245275931,-14];
FuzzerInjectionPoint(57);
const v73 = [536870888,697999288,4,-16,1000,6,127];
FuzzerInjectionPoint(58);
try { v73.reduceRight(v19); } catch (e) {}
FuzzerInjectionPoint(59);
[4096,-25476,-1845216104,747368961,536870888,10,1754060307];
FuzzerInjectionPoint(60);
class C76 {

    static set h(a78) {
FuzzerInjectionPoint(62);
    }

}
FuzzerInjectionPoint(64);
for (let v79 = 0; v79 < 5; v79++) {
FuzzerInjectionPoint(65);
    "p" == "p";
FuzzerInjectionPoint(66);
    const v82 = "p" + v79;
FuzzerInjectionPoint(67);
    v82 == v82;
FuzzerInjectionPoint(68);
}
FuzzerInjectionPoint(69);
[512,-2147483647,-65535,65535,7];
FuzzerInjectionPoint(70);
try { ("exec").trimEnd(); } catch (e) {}
FuzzerInjectionPoint(71);
function f88(a89, a90, a91) {
FuzzerInjectionPoint(72);
    a91 ?? a91;
FuzzerInjectionPoint(73);
    a91 ?? a91;
FuzzerInjectionPoint(74);
    const v94 = { [1467691842n]: a89, 256: a91, [a89]: "exec" };
FuzzerInjectionPoint(75);
}
FuzzerInjectionPoint(76);
f88();
FuzzerInjectionPoint(77);
/()7/dvsgi;
FuzzerInjectionPoint(78);
const v97 = [65537,5115,2147483647,64,-256,-9223372036854775807,-268435456,0];
FuzzerInjectionPoint(79);
const v99 = 4294967295n ^ 4294967295n;
FuzzerInjectionPoint(80);
v99 ^ v99;
FuzzerInjectionPoint(81);
const v102 = [536870912,1979792005,-1024];
FuzzerInjectionPoint(82);
const v103 = [43680,-536870912,4294967297,9332,9223372036854775807,-9223372036854775808,-9,43727,1175231882];
FuzzerInjectionPoint(83);
const v104 = [-58284,14,-1073741824,7947,-1,255];
FuzzerInjectionPoint(84);
class C105 {

    2981 = v97;

    static #o(a107, a108, a109, a110) {
FuzzerInjectionPoint(87);
        for (let v111 = 0; v111 < 5; v111++) {
FuzzerInjectionPoint(88);
            v102["p" + v111] = v111;
FuzzerInjectionPoint(89);
        }
FuzzerInjectionPoint(90);
    }

    9 = 4294967295n;

    static 9 = v104;

}
FuzzerInjectionPoint(94);
const v114 = %WasmArray();
FuzzerInjectionPoint(95);
let v115 = 0;
FuzzerInjectionPoint(96);
while ((() => {
FuzzerInjectionPoint(97);
        9 != 9;
FuzzerInjectionPoint(98);
        const v118 = v115 < 9;
FuzzerInjectionPoint(99);
        v118 && v118;
FuzzerInjectionPoint(100);
        try { Reflect.construct(v118); } catch (e) {}
FuzzerInjectionPoint(101);
        const v122 = [v25];
FuzzerInjectionPoint(102);
        v122[0];
FuzzerInjectionPoint(103);
        v102[128] = 9;
FuzzerInjectionPoint(104);
        for (let v124 = 0; v124 < 32; v124++) {
FuzzerInjectionPoint(105);
            v73["p" + v124] = v124;
FuzzerInjectionPoint(106);
        }
FuzzerInjectionPoint(107);
        Reflect.construct(Date, v122, C18);
FuzzerInjectionPoint(108);
        v118 && v118;
FuzzerInjectionPoint(109);
        return v118;
FuzzerInjectionPoint(110);
    })()) {
FuzzerInjectionPoint(111);
    let v129;
FuzzerInjectionPoint(112);
    try { v129 = v104.toSpliced(C105, ...v103, ...4294967295n, v114); } catch (e) {}
FuzzerInjectionPoint(113);
    v129 ?? v129;
FuzzerInjectionPoint(114);
    function F133(a135, a136, a137) {
FuzzerInjectionPoint(115);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(116);
        a136 ?? a136;
FuzzerInjectionPoint(117);
        this.a = 1137335585n;
FuzzerInjectionPoint(118);
    }
FuzzerInjectionPoint(119);
    try { Array.constructor("7u0", Array); } catch (e) {}
FuzzerInjectionPoint(120);
    const v140 = new F133(Array, 4294967295n, v129);
FuzzerInjectionPoint(121);
    v140.c = v140;
FuzzerInjectionPoint(122);
    new F133(v20, v129, v104);
FuzzerInjectionPoint(123);
    v115++;
FuzzerInjectionPoint(124);
}
FuzzerInjectionPoint(125);
"random" == "random";
FuzzerInjectionPoint(126);
[-12,-54485,-646522833,-2147483649,2129450216,10278,-4294967297];
FuzzerInjectionPoint(127);
const v147 = [-12,127,-9007199254740992,1000,19700,-256,0,17757];
FuzzerInjectionPoint(128);
const v148 = new WeakMap();
FuzzerInjectionPoint(129);
function f149(a150, a151, a152) {
FuzzerInjectionPoint(130);
    const v153 = {

        ..."random",

        [v148]: a151,

        d: v147,

        10000: "1073741823",

        ...a151,

        g: a150,

        c: a151,

        ...v147,

    };
FuzzerInjectionPoint(140);
}
FuzzerInjectionPoint(141);
%PrepareFunctionForOptimization(f149);
FuzzerInjectionPoint(142);
%OptimizeMaglevOnNextCall(f149);
FuzzerInjectionPoint(143);
f149(Math, 128, C18);
FuzzerInjectionPoint(144);
class C155 {

}
FuzzerInjectionPoint(146);
const t145 = C155.constructor;
FuzzerInjectionPoint(147);
t145();
FuzzerInjectionPoint(148);
class C158 {

}
FuzzerInjectionPoint(150);
class C159 extends C158 {

}
FuzzerInjectionPoint(152);
const v160 = C159?.apply;
FuzzerInjectionPoint(153);
try { v160(256); } catch (e) {}
FuzzerInjectionPoint(154);
let v162;
FuzzerInjectionPoint(155);
try { v162 = v160(v31, 1467691842n); } catch (e) {}
FuzzerInjectionPoint(156);
v162 ?? v162;
FuzzerInjectionPoint(157);
const v164 = { c: C155, __proto__: C158 };