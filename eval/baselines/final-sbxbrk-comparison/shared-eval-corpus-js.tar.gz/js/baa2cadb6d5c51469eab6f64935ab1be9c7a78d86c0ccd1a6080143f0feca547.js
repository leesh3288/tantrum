
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = {};
FuzzerInjectionPoint(2);
Object.defineProperty(v2, "ownKeys", { value: 65536 });
FuzzerInjectionPoint(3);
const v4 = new Proxy(BigInt64Array, v2);
FuzzerInjectionPoint(4);
try { Object.defineProperties(Proxy, v4); } catch (e) {}
FuzzerInjectionPoint(5);