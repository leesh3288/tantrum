
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F4() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    this.f = 54768;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
class C7 extends F4 {

    static {
FuzzerInjectionPoint(7);
        const v9 = {};
FuzzerInjectionPoint(8);
        const v10 = {};
FuzzerInjectionPoint(9);
        const v11 = {};
FuzzerInjectionPoint(10);
        const v12 = {};
FuzzerInjectionPoint(11);
    }

}
FuzzerInjectionPoint(13);
new C7();
FuzzerInjectionPoint(14);
new C7();
FuzzerInjectionPoint(15);
class C15 extends F4 {

}
FuzzerInjectionPoint(17);
new C15();
FuzzerInjectionPoint(18);
const v17 = [1024];
FuzzerInjectionPoint(19);
function f19() {
FuzzerInjectionPoint(20);
}
FuzzerInjectionPoint(21);
class C20 extends f19 {

}
FuzzerInjectionPoint(23);
new C20();
FuzzerInjectionPoint(24);
try { ("Mu").blink(); } catch (e) {}
FuzzerInjectionPoint(25);
function f24() {
FuzzerInjectionPoint(26);
    const v25 = {};
FuzzerInjectionPoint(27);
    v25.b = v25;
FuzzerInjectionPoint(28);
    return v25;
FuzzerInjectionPoint(29);
}
FuzzerInjectionPoint(30);
const v27 = f24()?.b;
FuzzerInjectionPoint(31);
v27.valueOf = f24;
FuzzerInjectionPoint(32);
let v28;
FuzzerInjectionPoint(33);
try { v28 = new v27(); } catch (e) {}
FuzzerInjectionPoint(34);
v28 ?? v28;
FuzzerInjectionPoint(35);
[-865879.4747004735];
FuzzerInjectionPoint(36);
BigUint64Array.c = BigUint64Array;
FuzzerInjectionPoint(37);
const v34 = new Float32Array(Float32Array);
FuzzerInjectionPoint(38);
function f35() {
FuzzerInjectionPoint(39);
    ([4,-61572,9,1957989437,1073741824,128,-2])[0];
FuzzerInjectionPoint(40);
    for (let v39 = 0; v39 < 5; v39++) {
FuzzerInjectionPoint(41);
        -v39;
FuzzerInjectionPoint(42);
        let v41 = [];
FuzzerInjectionPoint(43);
        v41.push(v17);
FuzzerInjectionPoint(44);
        v41++;
FuzzerInjectionPoint(45);
    }
FuzzerInjectionPoint(46);
    function f44(a45) {
FuzzerInjectionPoint(47);
        const v46 = {};
FuzzerInjectionPoint(48);
    }
FuzzerInjectionPoint(49);
    Symbol ?? Symbol;
FuzzerInjectionPoint(50);
    const v50 = v34[2];
FuzzerInjectionPoint(51);
    v50 % v50;
FuzzerInjectionPoint(52);
    1 !== 1;
FuzzerInjectionPoint(53);
    function f54() {
FuzzerInjectionPoint(54);
    }
FuzzerInjectionPoint(55);
    Uint8ClampedArray[Symbol] = f54;
FuzzerInjectionPoint(56);
    Uint8ClampedArray[0] = Uint8ClampedArray;
FuzzerInjectionPoint(57);
}
FuzzerInjectionPoint(58);
f35();
FuzzerInjectionPoint(59);
f35();
FuzzerInjectionPoint(60);
%OptimizeMaglevOnNextCall(f35);
FuzzerInjectionPoint(61);
f35();