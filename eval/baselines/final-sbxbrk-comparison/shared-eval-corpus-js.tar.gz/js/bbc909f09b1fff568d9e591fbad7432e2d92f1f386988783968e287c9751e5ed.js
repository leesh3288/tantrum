
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = -5n;
FuzzerInjectionPoint(2);
v0 **= 65536n;
FuzzerInjectionPoint(3);
constructor().decodeURI(v0);
FuzzerInjectionPoint(4);