
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = new Float64Array(89);
FuzzerInjectionPoint(2);
function f4(a5) {
FuzzerInjectionPoint(3);
    return 89;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
function f6(a7) {
FuzzerInjectionPoint(6);
    const v11 = new SharedArrayBuffer(1446, { maxByteLength: 1446 });
FuzzerInjectionPoint(7);
    const v12 = new Uint8ClampedArray(v11);
FuzzerInjectionPoint(8);
    return v12;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f4[Symbol.species] = f6;
FuzzerInjectionPoint(11);
v3.constructor = f4;
FuzzerInjectionPoint(12);
v3.slice();
FuzzerInjectionPoint(13);