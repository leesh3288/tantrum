
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    const v5 = ("object").valueOf();

    function f6() {

        typeof v5;

        eval(a1);

        const v10 = {};

        using v11 = v10;

        return v10;

    }

    f6();

    f6();

    %OptimizeMaglevOnNextCall(f6);

    f6();

    return v5;

}

f0();