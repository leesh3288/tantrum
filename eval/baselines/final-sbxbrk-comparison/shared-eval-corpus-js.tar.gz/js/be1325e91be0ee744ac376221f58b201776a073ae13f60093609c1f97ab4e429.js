
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {

    const v2 = [4,-61572,9,1957989437,1073741824,128,-2];

    using v4 = {};

    for (let v5 = 0; v5 < 5; v5++) {

        class C8 {

        }

        const v9 = new C8();

        class C10 extends C8 {

            [2026702522];

            #valueOf(a12, a13, a14, a15) {

                v9[4294967296] /= 4;

            }

            static [v9];

            static n(a17, a18) {

                this.d = v4;

            }

        }

        function f19() {

        }

        v2[v5];

    }

    function f21(a22) {

        return 0;

    }

    f21();

    class C24 {

    }

    C24["p" + 0] = 0;

    return 0;

}

f1();

f1();

%OptimizeMaglevOnNextCall(f1);

f1();