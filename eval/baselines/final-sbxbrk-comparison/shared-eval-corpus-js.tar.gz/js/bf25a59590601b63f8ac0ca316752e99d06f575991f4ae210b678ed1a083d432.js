
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Float64Array();
FuzzerInjectionPoint(2);
new BigUint64Array();
FuzzerInjectionPoint(3);
const v10 = new Uint16Array(3654);
FuzzerInjectionPoint(4);
const v11 = v10.join(BigInt64Array);
FuzzerInjectionPoint(5);
[-16787,-1098236850];
FuzzerInjectionPoint(6);
[v11];
FuzzerInjectionPoint(7);
function f15(a16, a17, a18) {
FuzzerInjectionPoint(8);
    const v21 = Array(43280);
FuzzerInjectionPoint(9);
    const v22 = { __proto__: v21 };
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f15.call();
FuzzerInjectionPoint(12);
f15();
FuzzerInjectionPoint(13);
gc("async");
FuzzerInjectionPoint(14);
gc();
FuzzerInjectionPoint(15);