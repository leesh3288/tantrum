
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C2 {

}
FuzzerInjectionPoint(3);
const v3 = [-226385.0575558031,966138.5165299489,2.220446049250313e-16,186.98172740097766,-2.6741623747933634,360.5219311105077,2.814481889966999e+307];
FuzzerInjectionPoint(4);
function f4(a5, a6, a7) {
FuzzerInjectionPoint(5);
    Object.defineProperty(arguments, 1073741825, { configurable: true, value: arguments });
FuzzerInjectionPoint(6);
    function f9() {
FuzzerInjectionPoint(7);
        return a7;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    gc();
FuzzerInjectionPoint(10);
    function f12(a13) {
FuzzerInjectionPoint(11);
        return a13;
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    Object.defineProperty(arguments, 1, { enumerable: true, get: f9, set: f12 });
FuzzerInjectionPoint(14);
    return C2;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
f4(C2, C2, C2, 1684, v3, Uint8Array);