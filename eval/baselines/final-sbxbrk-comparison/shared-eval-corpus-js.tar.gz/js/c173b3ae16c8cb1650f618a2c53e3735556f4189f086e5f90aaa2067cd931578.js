
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new BigInt64Array(10);
FuzzerInjectionPoint(2);
v2.sort();
FuzzerInjectionPoint(3);