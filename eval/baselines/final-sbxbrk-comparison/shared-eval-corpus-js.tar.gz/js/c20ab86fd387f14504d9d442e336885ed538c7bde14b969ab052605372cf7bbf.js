
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    const v9 = {

        c: "255",

        set d(a5) {
FuzzerInjectionPoint(5);
            for (let v6 = 0; v6 < 32; v6++) {
FuzzerInjectionPoint(6);
                this["p" + v6] = 10;
FuzzerInjectionPoint(7);
            }
FuzzerInjectionPoint(8);
        },

        h: -1073741824,

        execution: "255",

        e: -1073741824,

    };
FuzzerInjectionPoint(13);
    v9.d = v9;
FuzzerInjectionPoint(14);
    return v9;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
const v10 = f1();
FuzzerInjectionPoint(17);
function f11(a12, a13) {
FuzzerInjectionPoint(18);
    const v19 = {

        set f(a15) {
FuzzerInjectionPoint(20);
        },

        ...a13,

        [a13]: a12,

        get a() {
FuzzerInjectionPoint(24);
            return this;
FuzzerInjectionPoint(25);
        },

        g: f1,

        b: f1,

        valueOf(a18) {
FuzzerInjectionPoint(29);
            return 10;
FuzzerInjectionPoint(30);
        },

        has: f1,

    };
FuzzerInjectionPoint(33);
    return v19;
FuzzerInjectionPoint(34);
}
FuzzerInjectionPoint(35);
f11(f1, f11(f1, v10));