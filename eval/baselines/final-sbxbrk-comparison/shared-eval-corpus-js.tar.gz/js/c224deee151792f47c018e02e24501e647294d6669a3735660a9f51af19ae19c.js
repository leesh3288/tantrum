
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = 16;
FuzzerInjectionPoint(2);
v0++;
FuzzerInjectionPoint(3);
function f3(a4) {
FuzzerInjectionPoint(4);
    const v5 = `
FuzzerInjectionPoint(5);
        9007199254740992n * 9007199254740992n;
FuzzerInjectionPoint(6);
        /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(7);
    `;
FuzzerInjectionPoint(8);
    return v5;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
Number.toString = f3;
FuzzerInjectionPoint(11);
Number.parseInt(Number, v0);
FuzzerInjectionPoint(12);