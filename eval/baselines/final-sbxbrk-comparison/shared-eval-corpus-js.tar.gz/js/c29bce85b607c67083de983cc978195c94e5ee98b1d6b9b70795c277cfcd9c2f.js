
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3) {

    function f4(a5) {

        function f6(a7) {

            const v17 = {

                [Symbol]() {

                    let v10 = 10;

                    const v16 = {

                        next() {

                            v10--;

                            v10 == 0;

                            const v15 = { value: v10 };

                            return this;

                        },

                    };

                },

            };

            return a3;

        }

        f6 ** "symbol";

        return f1;

    }

    const v21 = [a2];

    const v23 = new Worker(f4, { arguments: v21, type: "function" });

    return v23;

}

class C24 extends f1 {

}

new C24();