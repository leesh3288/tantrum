
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v6 = {

    toString(a2, a3) {
FuzzerInjectionPoint(3);
        try {
FuzzerInjectionPoint(4);
            super.p();
FuzzerInjectionPoint(5);
        } catch(e5) {
FuzzerInjectionPoint(6);
        }
FuzzerInjectionPoint(7);
        return a3;
FuzzerInjectionPoint(8);
    },

};
FuzzerInjectionPoint(10);
function f7(a8, a9) {
FuzzerInjectionPoint(11);
    const v10 = { [v6]: a8 };
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
const v12 = new Uint8Array(255);
FuzzerInjectionPoint(14);
v12.find(f7);