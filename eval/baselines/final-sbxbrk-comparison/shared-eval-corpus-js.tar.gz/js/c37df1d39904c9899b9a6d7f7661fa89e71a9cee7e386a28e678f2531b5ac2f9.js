
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [17759,65536,4,1024,508750168,-10];
FuzzerInjectionPoint(2);
[7,15,-9007199254740991,9223372036854775807,439302271,512,12,-11,3,268435456];
FuzzerInjectionPoint(3);
const v2 = [257];
FuzzerInjectionPoint(4);
[v2];
FuzzerInjectionPoint(5);
const v4 = [v2];
FuzzerInjectionPoint(6);
function F5(a7, a8) {
FuzzerInjectionPoint(7);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(8);
    this.e = a7;
FuzzerInjectionPoint(9);
    this.b = a7;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
new F5();
FuzzerInjectionPoint(12);
new F5();
FuzzerInjectionPoint(13);
class C11 extends F5 {

    static #n(a13, a14, a15) {
FuzzerInjectionPoint(15);
        const f = a14;
FuzzerInjectionPoint(16);
        return v2;
FuzzerInjectionPoint(17);
    }

    h = v2;

    static m(a18, a19, a20) {
FuzzerInjectionPoint(20);
        let v21 = new WebAssembly.Tag({parameters: ["f64"]});
FuzzerInjectionPoint(21);
        try {
FuzzerInjectionPoint(22);
            F5(v4);
FuzzerInjectionPoint(23);
        } catch(e23) {
FuzzerInjectionPoint(24);
        }
FuzzerInjectionPoint(25);
        return v0;
FuzzerInjectionPoint(26);
    }

}
FuzzerInjectionPoint(28);
new C11();
FuzzerInjectionPoint(29);
new C11();
FuzzerInjectionPoint(30);
new C11();
FuzzerInjectionPoint(31);
const v30 = Math.cos();
FuzzerInjectionPoint(32);
class C33 {

    g;

    h = "1073741823";

    123;

    c = -4.221877022850638;

}
FuzzerInjectionPoint(38);
C33.b = C33;
FuzzerInjectionPoint(39);
const v34 = new C33();
FuzzerInjectionPoint(40);
const v35 = {

    [C33]: v30,

    [v30]: "1073741823",

    ...v34,

    ...v30,

    2147483649: v30,

    a: WeakMap,

    f: v30,

    b: v30,

};
FuzzerInjectionPoint(50);
~256;
FuzzerInjectionPoint(51);
const v39 = new Int8Array();
FuzzerInjectionPoint(52);
const v40 = v39.global;
FuzzerInjectionPoint(53);
let v42 = 0;
FuzzerInjectionPoint(54);
for (let i = 0; i < 5; i++) {
FuzzerInjectionPoint(55);
    v42++;
FuzzerInjectionPoint(56);
    v42 < 10;
FuzzerInjectionPoint(57);
}
FuzzerInjectionPoint(58);
3127 | 3127;
FuzzerInjectionPoint(59);
const v49 = new Uint32Array(3127);
FuzzerInjectionPoint(60);
-2455;
FuzzerInjectionPoint(61);
const v53 = new BigInt64Array();
FuzzerInjectionPoint(62);
function f54() {
FuzzerInjectionPoint(63);
    return v49;
FuzzerInjectionPoint(64);
}
FuzzerInjectionPoint(65);
function f55(a56, a57, a58, a59) {
FuzzerInjectionPoint(66);
    a57 & a57;
FuzzerInjectionPoint(67);
    a59.BYTES_PER_ELEMENT;
FuzzerInjectionPoint(68);
    const v74 = {

        get g() {
FuzzerInjectionPoint(70);
            !this;
FuzzerInjectionPoint(71);
            Math.sqrt();
FuzzerInjectionPoint(72);
            6 >>> 3;
FuzzerInjectionPoint(73);
            for (let [v69,...v70] of "1073741823") {
FuzzerInjectionPoint(74);
                C33[v70] = v39;
FuzzerInjectionPoint(75);
                C33.b;
FuzzerInjectionPoint(76);
            }
FuzzerInjectionPoint(77);
            v40.f;
FuzzerInjectionPoint(78);
            Math.log();
FuzzerInjectionPoint(79);
            return 3;
FuzzerInjectionPoint(80);
        },

    };
FuzzerInjectionPoint(82);
    return v74;
FuzzerInjectionPoint(83);
}
FuzzerInjectionPoint(84);
let v75 = f55(256, 256, v53, v49);
FuzzerInjectionPoint(85);
f55(2455, 3127, BigInt64Array, v75);
FuzzerInjectionPoint(86);
const v77 = /MjL/mdvi;
FuzzerInjectionPoint(87);
const v78 = /[x]*/mudsg;
FuzzerInjectionPoint(88);
class C79 {

    static set d(a81) {
FuzzerInjectionPoint(90);
    }

    constructor(a83) {
FuzzerInjectionPoint(92);
    }

}
FuzzerInjectionPoint(94);
v77[4] = v78;
FuzzerInjectionPoint(95);
v78.exec();
FuzzerInjectionPoint(96);
class C85 extends C79 {

}
FuzzerInjectionPoint(98);
const v86 = new C85();
FuzzerInjectionPoint(99);
128 ** (v86 >> v86);
FuzzerInjectionPoint(100);
f55(3127, 256, f55, 2455);
FuzzerInjectionPoint(101);
const v91 = f54();
FuzzerInjectionPoint(102);
%PrepareFunctionForOptimization(f54);
FuzzerInjectionPoint(103);
const v92 = f54();
FuzzerInjectionPoint(104);
try { v92.toString(); } catch (e) {}
FuzzerInjectionPoint(105);
f54();
FuzzerInjectionPoint(106);
%OptimizeMaglevOnNextCall(f54);
FuzzerInjectionPoint(107);
[v75,f54,...BigInt64Array] = v91;
FuzzerInjectionPoint(108);
const v95 = new Uint32Array();
FuzzerInjectionPoint(109);
v95[69] = v95;
FuzzerInjectionPoint(110);
Date.length = Date;
FuzzerInjectionPoint(111);
const v97 = new Date();
FuzzerInjectionPoint(112);
v97.getUTCHours();
FuzzerInjectionPoint(113);
new WeakMap();
FuzzerInjectionPoint(114);
[-16,331888118,52077,536870912,-2147483649,536870887,-1565868922,0,-21341,7];
FuzzerInjectionPoint(115);
[8,1000,-128,-2147483648,245275931,-14];
FuzzerInjectionPoint(116);
[-11,1024,15,3];
FuzzerInjectionPoint(117);
408410.1076219119 >>> 408410.1076219119;
FuzzerInjectionPoint(118);
const v108 = [536870888,697999288,4,-16,1000,6,127];
FuzzerInjectionPoint(119);
try { v108.reduceRight(); } catch (e) {}
FuzzerInjectionPoint(120);
[4096,-25476,-1845216104,747368961,536870888,10,1754060307];
FuzzerInjectionPoint(121);
class C112 {

}
FuzzerInjectionPoint(123);
C112.prototype = C112;
FuzzerInjectionPoint(124);
for (let v113 = 0; v113 < 5; v113++) {
FuzzerInjectionPoint(125);
    ("p").small();
FuzzerInjectionPoint(126);
    const v116 = "p" % v113;
FuzzerInjectionPoint(127);
    v116 == v116;
FuzzerInjectionPoint(128);
    C112[v116] = v113;
FuzzerInjectionPoint(129);
}
FuzzerInjectionPoint(130);
Date.parse();
FuzzerInjectionPoint(131);
1467691842n === 1467691842n;
FuzzerInjectionPoint(132);
function f121(a122, a123, a124) {
FuzzerInjectionPoint(133);
}
FuzzerInjectionPoint(134);
f121.arguments = f121;
FuzzerInjectionPoint(135);
f121();
FuzzerInjectionPoint(136);
const v126 = /()7/dvsgi;
FuzzerInjectionPoint(137);
v126.h = v126;
FuzzerInjectionPoint(138);
[65537,5115,2147483647,64,-256,-9223372036854775807,-268435456,0];
FuzzerInjectionPoint(139);
([536870912,1979792005,-1024]).concat();
FuzzerInjectionPoint(140);
const v132 = [43680,-536870912,4294967297,9332,9223372036854775807,-9223372036854775808,-9,43727,1175231882];
FuzzerInjectionPoint(141);
const v133 = [-58284,14,-1073741824,7947,-1,255];
FuzzerInjectionPoint(142);
class C134 {

    2981 = v132;

    static 9 = v133;

}
FuzzerInjectionPoint(146);
C134.name = C134;
FuzzerInjectionPoint(147);
const v135 = new C134();
FuzzerInjectionPoint(148);
const v136 = %WasmArray();
FuzzerInjectionPoint(149);
let v137 = 0;
FuzzerInjectionPoint(150);
9 != 9;
FuzzerInjectionPoint(151);
v137 < 9;
FuzzerInjectionPoint(152);
let v141;
FuzzerInjectionPoint(153);
try { v141 = v133.toSpliced(v135, ...v132, ...4294967295n); } catch (e) {}
FuzzerInjectionPoint(154);
let v143 = 36;
FuzzerInjectionPoint(155);
v143++;
FuzzerInjectionPoint(156);
Array();
FuzzerInjectionPoint(157);
function F146(a148, a149, a150) {
FuzzerInjectionPoint(158);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(159);
}
FuzzerInjectionPoint(160);
new F146(Array, v141);
FuzzerInjectionPoint(161);
new F146();
FuzzerInjectionPoint(162);
new F146();
FuzzerInjectionPoint(163);
v137++;
FuzzerInjectionPoint(164);
v126[268435439] ??= -2028408876;
FuzzerInjectionPoint(165);
class C155 {

}
FuzzerInjectionPoint(167);
const v156 = {};