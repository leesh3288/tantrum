
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint8ClampedArray(127);
FuzzerInjectionPoint(2);
let v3 = 255;
FuzzerInjectionPoint(3);
const v4 = new Uint8ClampedArray(v3);
FuzzerInjectionPoint(4);
for (const v5 of v4) {
FuzzerInjectionPoint(5);
    [,,...v3] = v2;
FuzzerInjectionPoint(6);
    v3?.g;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
new BigUint64Array();
FuzzerInjectionPoint(9);