
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [2.0,-610.4436715778097,-1000000000000.0,-127716.62729961157,2.2250738585072014e-308,-1000000000000.0,-0.0,5.0,3.576246732822314,-2.220446049250313e-16];
FuzzerInjectionPoint(2);
function f1(a2, a3) {
FuzzerInjectionPoint(3);
    a2[9] = a3;
FuzzerInjectionPoint(4);
    a2.includes(a3, f1);
FuzzerInjectionPoint(5);
    return f1;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f1(v0);
FuzzerInjectionPoint(8);