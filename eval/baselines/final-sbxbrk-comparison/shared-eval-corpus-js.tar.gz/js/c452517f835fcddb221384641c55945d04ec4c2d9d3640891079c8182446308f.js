
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v4 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(3);
    function f5() {
FuzzerInjectionPoint(4);
        return a3;
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    function f6(a7) {
FuzzerInjectionPoint(7);
        return a1;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    Object.defineProperty(v4, Symbol, { enumerable: true, get: f5, set: f6 });
FuzzerInjectionPoint(10);
    for (let v9 = 0; v9 < 5; v9++) {
FuzzerInjectionPoint(11);
        v4[v9];
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    return f0;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
f0();
FuzzerInjectionPoint(16);
const v12 = f0();
FuzzerInjectionPoint(17);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(18);
f0(v12, v12, v12);
FuzzerInjectionPoint(19);