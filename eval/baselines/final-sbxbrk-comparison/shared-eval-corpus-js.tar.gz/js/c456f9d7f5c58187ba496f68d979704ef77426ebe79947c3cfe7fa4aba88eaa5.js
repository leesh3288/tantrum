
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0(a2, a3, a4, a5) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f6(a7, a8, a9) {
FuzzerInjectionPoint(5);
    for (let i = 0; i < 5; i++) {
FuzzerInjectionPoint(6);
        typeof F0;
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    eval();
FuzzerInjectionPoint(9);
    return a9;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f6(f6, F0, f6());
FuzzerInjectionPoint(12);
%OptimizeMaglevOnNextCall(f6);
FuzzerInjectionPoint(13);
f6();
FuzzerInjectionPoint(14);