
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = constructor(constructor, constructor, constructor, constructor, constructor).Intl;
FuzzerInjectionPoint(2);
const v3 = v2.DisplayNames;
FuzzerInjectionPoint(3);
const v4 = v3.prototype;
FuzzerInjectionPoint(4);
try { v4.resolvedOptions(v4, v3, v2); } catch (e) {}
FuzzerInjectionPoint(5);