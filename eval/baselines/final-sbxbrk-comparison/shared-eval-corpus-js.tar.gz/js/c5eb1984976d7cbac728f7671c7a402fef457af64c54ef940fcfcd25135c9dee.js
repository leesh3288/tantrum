
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Float32Array(3878);
FuzzerInjectionPoint(2);
function f3() {
FuzzerInjectionPoint(3);
    Reflect.defineProperty(v2, 3271, Reflect);
FuzzerInjectionPoint(4);
    f3.prototype &= 14;
FuzzerInjectionPoint(5);
    return 3271;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f3();
FuzzerInjectionPoint(8);
f3();
FuzzerInjectionPoint(9);
%OptimizeMaglevOnNextCall(f3);
FuzzerInjectionPoint(10);
f3();
FuzzerInjectionPoint(11);