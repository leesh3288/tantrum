
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint8Array(2747);
FuzzerInjectionPoint(2);
function f3(a4) {
FuzzerInjectionPoint(3);
    return 2747;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
v2.valueOf = f3;
FuzzerInjectionPoint(6);
v2[32] = v2;
FuzzerInjectionPoint(7);
class C5 {

    static n(a7, a8) {
FuzzerInjectionPoint(9);
        this.toString();
FuzzerInjectionPoint(10);
    }

}
FuzzerInjectionPoint(12);
function f10() {
FuzzerInjectionPoint(13);
    v2.toSorted();
FuzzerInjectionPoint(14);
    return Uint8Array;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
C5.toString = f10;
FuzzerInjectionPoint(17);
C5.n();