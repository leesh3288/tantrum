
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-2.0,0.4687064970083057,1.7976931348623157e+308,2.0];
FuzzerInjectionPoint(2);
const v1 = [0.7284011768201828,-1000000.0,0.035274165649744726,276392.70502625196,-2.2250738585072014e-308,-Infinity];
FuzzerInjectionPoint(3);
const v2 = [-1.7976931348623157e+308,-3.9691683430800033,-5.0,-2.2250738585072014e-308];
FuzzerInjectionPoint(4);
const v3 = [337.05924815727985,859.1644951519327,2.220446049250313e-16,3.0,918.804032388844];
FuzzerInjectionPoint(5);
class C6 {

    2147483647;

    [v3] = v2;

    g = v3;

    2981 = v0;

    [536870888] = -472338630;

}
FuzzerInjectionPoint(12);
const v7 = new C6();
FuzzerInjectionPoint(13);
v2.e = delete v2[v1];
FuzzerInjectionPoint(14);
d8.serializer.serialize(v7);