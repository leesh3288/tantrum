
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 extends ({}).constructor {

}
FuzzerInjectionPoint(3);
function f4() {
FuzzerInjectionPoint(4);
    new C3(f4, 1345);
FuzzerInjectionPoint(5);
    return f4;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v6 = f4();
FuzzerInjectionPoint(8);
v6();
FuzzerInjectionPoint(9);
const v9 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(10);
function f10(a11, a12) {
FuzzerInjectionPoint(11);
    %OptimizeFunctionOnNextCall(v6);
FuzzerInjectionPoint(12);
    v6();
FuzzerInjectionPoint(13);
    return a11;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
v9.toString = f10;
FuzzerInjectionPoint(16);
class C14 extends Set {

    [v9] = v9;

}