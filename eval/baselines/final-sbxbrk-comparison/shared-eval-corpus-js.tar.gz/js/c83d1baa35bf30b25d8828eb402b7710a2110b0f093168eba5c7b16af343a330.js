
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = ++Int16Array;
FuzzerInjectionPoint(2);
const v7 = new ArrayBuffer(211, { maxByteLength: 1024 });
FuzzerInjectionPoint(3);
const v8 = new Float64Array(v7);
FuzzerInjectionPoint(4);
v8.lastIndexOf(v2);
FuzzerInjectionPoint(5);