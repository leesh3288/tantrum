
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    this.e = 1000;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v3 = new F0();
FuzzerInjectionPoint(6);
const v4 = new F0();
FuzzerInjectionPoint(7);
const v5 = new F0();
FuzzerInjectionPoint(8);
class C6 {

    #d;

    4294967296;

    static #b;

    m(a8) {
FuzzerInjectionPoint(13);
        function f9(a10, a11) {
FuzzerInjectionPoint(14);
            return a10;
FuzzerInjectionPoint(15);
        }
FuzzerInjectionPoint(16);
        const v14 = ["function",this];
FuzzerInjectionPoint(17);
        Worker(f9, { arguments: v14 }, Worker, "function", a8);
FuzzerInjectionPoint(18);
    }

    5;

}
FuzzerInjectionPoint(21);
const v17 = new C6();
FuzzerInjectionPoint(22);
const v18 = new C6();
FuzzerInjectionPoint(23);
[F0,C6,v4,C6,v3];
FuzzerInjectionPoint(24);
[v3,v5,v4,v18,F0];
FuzzerInjectionPoint(25);
[C6,v17,C6];
FuzzerInjectionPoint(26);
function f22(a23, a24) {
FuzzerInjectionPoint(27);
    const v25 = [12,64,-268435456,-4096,12611,-65537];
FuzzerInjectionPoint(28);
    const v26 = [2147483647,1074076221,-1453867915,4,13,2,64,550066037,-6,-3];
FuzzerInjectionPoint(29);
    const v27 = [4294967296,-8,127,-9007199254740992,-9223372036854775807,10,-14];
FuzzerInjectionPoint(30);
    const v29 = ("-9").toString(f22, f22, f22, f22);
FuzzerInjectionPoint(31);
    v29.substr(v29);
FuzzerInjectionPoint(32);
    const v33 = ("boolean").trimEnd();
FuzzerInjectionPoint(33);
    let v34;
FuzzerInjectionPoint(34);
    try { v34 = v33.split(v33, v29); } catch (e) {}
FuzzerInjectionPoint(35);
    const v35 = [v29];
FuzzerInjectionPoint(36);
    const v38 = ("p").link(v27);
FuzzerInjectionPoint(37);
    v38[31] = v38;
FuzzerInjectionPoint(38);
    const v40 = -16847 | -16847;
FuzzerInjectionPoint(39);
    v40 + v40;
FuzzerInjectionPoint(40);
    const t38 = "m";
FuzzerInjectionPoint(41);
    t38[0] = "m";
FuzzerInjectionPoint(42);
    ("toString").d;
FuzzerInjectionPoint(43);
    ("toString").length;
FuzzerInjectionPoint(44);
    const v44 = %WasmArray();
FuzzerInjectionPoint(45);
    function f45() {
FuzzerInjectionPoint(46);
    }
FuzzerInjectionPoint(47);
    class C46 extends f45 {

    }
FuzzerInjectionPoint(49);
    const v47 = new C46();
FuzzerInjectionPoint(50);
    const v48 = new C46();
FuzzerInjectionPoint(51);
    const v49 = v48.constructor;
FuzzerInjectionPoint(52);
    new v49();
FuzzerInjectionPoint(53);
    const v51 = v48.constructor;
FuzzerInjectionPoint(54);
    const v52 = v3.constructor;
FuzzerInjectionPoint(55);
    const v53 = new v52();
FuzzerInjectionPoint(56);
    v53.constructor;
FuzzerInjectionPoint(57);
    const t55 = C46.constructor;
FuzzerInjectionPoint(58);
    new t55();
FuzzerInjectionPoint(59);
    const t58 = v53.constructor;
FuzzerInjectionPoint(60);
    const v58 = new t58(v47);
FuzzerInjectionPoint(61);
    const t60 = v58.constructor;
FuzzerInjectionPoint(62);
    new t60(f22, v58, -16847, v52, v33);
FuzzerInjectionPoint(63);
    try { v58.n("boolean", v35); } catch (e) {}
FuzzerInjectionPoint(64);
    new C46();
FuzzerInjectionPoint(65);
    const t64 = C46.constructor;
FuzzerInjectionPoint(66);
    const v64 = new t64();
FuzzerInjectionPoint(67);
    const t66 = v64.constructor;
FuzzerInjectionPoint(68);
    new t66();
FuzzerInjectionPoint(69);
    function f67() {
FuzzerInjectionPoint(70);
    }
FuzzerInjectionPoint(71);
    class C68 {

    }
FuzzerInjectionPoint(73);
    const v69 = C68.dispose;
FuzzerInjectionPoint(74);
    try { v69(v34); } catch (e) {}
FuzzerInjectionPoint(75);
    const v71 = [v25];
FuzzerInjectionPoint(76);
    function f72() {
FuzzerInjectionPoint(77);
        typeof null === "function";
FuzzerInjectionPoint(78);
    }
FuzzerInjectionPoint(79);
    %OptimizeMaglevOnNextCall(f72);
FuzzerInjectionPoint(80);
    f72();
FuzzerInjectionPoint(81);
    const v78 = [f22,f22];
FuzzerInjectionPoint(82);
    let v79;
FuzzerInjectionPoint(83);
    try { v79 = v78.some(v26); } catch (e) {}
FuzzerInjectionPoint(84);
    const v80 = v79 ?? v79;
FuzzerInjectionPoint(85);
    v80 ?? v80;
FuzzerInjectionPoint(86);
    [v71];
FuzzerInjectionPoint(87);
    class C83 extends f67 {

    }
FuzzerInjectionPoint(89);
    const v84 = new C83();
FuzzerInjectionPoint(90);
    Array(3038);
FuzzerInjectionPoint(91);
    class C90 {

        constructor(a92) {
FuzzerInjectionPoint(93);
            a92 < 0.6460206421979412;
FuzzerInjectionPoint(94);
        }

    }
FuzzerInjectionPoint(96);
    const v94 = new C90(8n);
FuzzerInjectionPoint(97);
    let v95;
FuzzerInjectionPoint(98);
    try { v95 = v84(v49, C68, v38, v94, v94); } catch (e) {}
FuzzerInjectionPoint(99);
    const v96 = v95 ?? v95;
FuzzerInjectionPoint(100);
    const v97 = v96 ?? v96;
FuzzerInjectionPoint(101);
    v97 ?? v97;
FuzzerInjectionPoint(102);
    const v99 = new C83();
FuzzerInjectionPoint(103);
    const t102 = v99.constructor;
FuzzerInjectionPoint(104);
    new t102(C46);
FuzzerInjectionPoint(105);
    const v104 = Int8Array.length;
FuzzerInjectionPoint(106);
    const v105 = v104 >> v104;
FuzzerInjectionPoint(107);
    (v105 % v105) - v40;
FuzzerInjectionPoint(108);
    const v108 = new Int8Array("m", v49);
FuzzerInjectionPoint(109);
    const v112 = new Float32Array([Infinity,0.4761088559953277,1.775746044000269e+308,-5.0,121.20958743215851]);
FuzzerInjectionPoint(110);
    v112[1351697117] = v112;
FuzzerInjectionPoint(111);
    new Float32Array(6);
FuzzerInjectionPoint(112);
    const v116 = new WeakSet();
FuzzerInjectionPoint(113);
    const v118 = new Uint32Array();
FuzzerInjectionPoint(114);
    const v120 = new BigInt64Array(v47);
FuzzerInjectionPoint(115);
    const v121 = v120.values();
FuzzerInjectionPoint(116);
    try { v121.reduce(); } catch (e) {}
FuzzerInjectionPoint(117);
    function f123(a124, a125, a126, a127) {
FuzzerInjectionPoint(118);
        ~a124;
FuzzerInjectionPoint(119);
        return f22;
FuzzerInjectionPoint(120);
    }
FuzzerInjectionPoint(121);
    f123(v51, v116, C83);
FuzzerInjectionPoint(122);
    const v130 = ~v99;
FuzzerInjectionPoint(123);
    v130 >> v130;
FuzzerInjectionPoint(124);
    ~v108;
FuzzerInjectionPoint(125);
    f123(256, 256, v120, v118);
FuzzerInjectionPoint(126);
    return v104;
FuzzerInjectionPoint(127);
}
FuzzerInjectionPoint(128);
const v134 = f22(f22, f22);
FuzzerInjectionPoint(129);
f22(v134, v134);
FuzzerInjectionPoint(130);
%OptimizeMaglevOnNextCall(f22);
FuzzerInjectionPoint(131);
f22();