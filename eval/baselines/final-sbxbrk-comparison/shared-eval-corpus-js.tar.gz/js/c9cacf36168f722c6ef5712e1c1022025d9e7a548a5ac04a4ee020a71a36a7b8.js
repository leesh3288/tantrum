
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(4);
    const v6 = Array(a4);
FuzzerInjectionPoint(5);
    v6[103] = C0;
FuzzerInjectionPoint(6);
    v6.includes();
FuzzerInjectionPoint(7);
    return C0;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f1(C0, f1(f1, f1, C0), C0);
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(11);
f1();