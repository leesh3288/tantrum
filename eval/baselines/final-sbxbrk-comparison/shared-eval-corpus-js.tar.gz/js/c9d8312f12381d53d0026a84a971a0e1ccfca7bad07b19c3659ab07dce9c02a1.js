
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    function f2() {
FuzzerInjectionPoint(3);
        const v3 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(4);
        v3.fill(v3);
FuzzerInjectionPoint(5);
        const v5 = v3.pop();
FuzzerInjectionPoint(6);
        v5.flat();
FuzzerInjectionPoint(7);
        const v7 = v5.fill(f2);
FuzzerInjectionPoint(8);
        v7[4] = v7;
FuzzerInjectionPoint(9);
        v5[1].arguments;
FuzzerInjectionPoint(10);
        for (let v10 = 0; v10 < 5; v10++) {
FuzzerInjectionPoint(11);
        }
FuzzerInjectionPoint(12);
        return f0;
FuzzerInjectionPoint(13);
    }
FuzzerInjectionPoint(14);
    f2();
FuzzerInjectionPoint(15);
    f2();
FuzzerInjectionPoint(16);
    return a1;
FuzzerInjectionPoint(17);
}
FuzzerInjectionPoint(18);
f0(f0());
FuzzerInjectionPoint(19);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(20);
f0(f0);
FuzzerInjectionPoint(21);