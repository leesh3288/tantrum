
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new BigUint64Array(138);
FuzzerInjectionPoint(2);
function f3(a4) {
FuzzerInjectionPoint(3);
    const v5 = [536870888,-3];
FuzzerInjectionPoint(4);
    v5.fill();
FuzzerInjectionPoint(5);
    Object.defineProperty(v2, 1, { writable: true, configurable: true, enumerable: true, value: v5.join(1073741825) });
FuzzerInjectionPoint(6);
    v2["sort"]();
FuzzerInjectionPoint(7);
    return v2;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f3(f3());
FuzzerInjectionPoint(10);
f3();
FuzzerInjectionPoint(11);