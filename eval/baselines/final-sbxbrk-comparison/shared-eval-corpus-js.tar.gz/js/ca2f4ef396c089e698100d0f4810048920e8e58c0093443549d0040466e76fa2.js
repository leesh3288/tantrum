
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}
FuzzerInjectionPoint(3);
function f1() {
FuzzerInjectionPoint(4);
    const v4 = new Uint8ClampedArray(1);
FuzzerInjectionPoint(5);
    v4[0] = C0;
FuzzerInjectionPoint(6);
    return C0;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f1();
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);
%OptimizeMaglevOnNextCall(f1);
FuzzerInjectionPoint(11);
f1();