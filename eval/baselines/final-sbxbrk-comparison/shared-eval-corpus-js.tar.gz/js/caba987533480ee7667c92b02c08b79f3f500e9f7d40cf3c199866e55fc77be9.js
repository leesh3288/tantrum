
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [0.2852872233913738,0.0,0.6082738598103906,-516896.39061594807,-1000000000.0,1.905922599748635,2.220446049250313e-16,-57.64243055992631,0.6277016736591534,-1.0];
FuzzerInjectionPoint(2);
function f1(a2, a3) {
FuzzerInjectionPoint(3);
    v0.length;
FuzzerInjectionPoint(4);
    return f1;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
const v5 = f1(v0, v0);
FuzzerInjectionPoint(7);
f1(v5, v5);
FuzzerInjectionPoint(8);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);