
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v8 = new SharedArrayBuffer(9, { maxByteLength: 2649272740 });
FuzzerInjectionPoint(3);
    const v10 = new Int8Array(v8);
FuzzerInjectionPoint(4);
    v10[8] = v10;
FuzzerInjectionPoint(5);
    return a3;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v11 = f0();
FuzzerInjectionPoint(8);
const v12 = f0(v11, v11, v11);
FuzzerInjectionPoint(9);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(10);
f0(v12, f0, v12);
FuzzerInjectionPoint(11);