
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    /a(?:b)xa\ud808\udf45*/musy;
FuzzerInjectionPoint(3);
    const v5 = Array(122);
FuzzerInjectionPoint(4);
    const v6 = v5.fill(f0);
FuzzerInjectionPoint(5);
    const v7 = [1000000000.0,185453.66805808875,887.1083108101639,-Infinity,2.2250738585072014e-308,-9.96501636426367e+307];
FuzzerInjectionPoint(6);
    const v9 = ({ __proto__: v5, ...v7 }).toLocaleString(Array, f0);
FuzzerInjectionPoint(7);
    v9.match(v9);
FuzzerInjectionPoint(8);
    return v6;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
try { f0(); } catch (e) {}
FuzzerInjectionPoint(11);