
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 {

    static set e(a5) {
FuzzerInjectionPoint(3);
        Uint32Array();
FuzzerInjectionPoint(4);
        ("b").o(a5, NaN);
FuzzerInjectionPoint(5);
        15591 >>> this;
FuzzerInjectionPoint(6);
        this || -438224154;
FuzzerInjectionPoint(7);
        Math.acos(-438224154);
FuzzerInjectionPoint(8);
    }

    static [15591];

    [15591];

    static 6;

    3 = NaN;

}
FuzzerInjectionPoint(14);
C3[15591] = C3;
FuzzerInjectionPoint(15);
C3[3] = C3;
FuzzerInjectionPoint(16);
C3[15591] = C3;
FuzzerInjectionPoint(17);
[4096,47489];
FuzzerInjectionPoint(18);
const v22 = [10948,1431711097,-1073741824,-65536,1024,16,4294967296];
FuzzerInjectionPoint(19);
v22[6] = v22;
FuzzerInjectionPoint(20);
function f25() {
FuzzerInjectionPoint(21);
    class C26 {

    }
FuzzerInjectionPoint(23);
    const v27 = new C26();
FuzzerInjectionPoint(24);
    function f29() {
FuzzerInjectionPoint(25);
        class C33 {

            [v27] = undefined;

            static [Float32Array] = f29;

        }
FuzzerInjectionPoint(29);
        return undefined;
FuzzerInjectionPoint(30);
    }
FuzzerInjectionPoint(31);
    for (let v34 = 0; v34 < 5; v34++) {
FuzzerInjectionPoint(32);
        ([Infinity]).unshift(4);
FuzzerInjectionPoint(33);
        function f38() {
FuzzerInjectionPoint(34);
            return f38;
FuzzerInjectionPoint(35);
        }
FuzzerInjectionPoint(36);
        const v40 = new C3();
FuzzerInjectionPoint(37);
        v40[15591];
FuzzerInjectionPoint(38);
        const v45 = new Uint32Array(2175);
FuzzerInjectionPoint(39);
        [v45];
FuzzerInjectionPoint(40);
        new Float32Array(v27, -65519, 2175);
FuzzerInjectionPoint(41);
    }
FuzzerInjectionPoint(42);
    return f25;
FuzzerInjectionPoint(43);
}
FuzzerInjectionPoint(44);
f25();
FuzzerInjectionPoint(45);
const v49 = f25();
FuzzerInjectionPoint(46);
%OptimizeMaglevOnNextCall(f25);
FuzzerInjectionPoint(47);
v49();