
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = this.Intl;
FuzzerInjectionPoint(2);
v1.v8BreakIterator(v1);
FuzzerInjectionPoint(3);