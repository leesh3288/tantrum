
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
class C2 extends F0 {

}
FuzzerInjectionPoint(6);
const v4 = this.Intl;
FuzzerInjectionPoint(7);
const v5 = v4.NumberFormat;
FuzzerInjectionPoint(8);
const v6 = v5(v4, F0, v5, v5, this);
FuzzerInjectionPoint(9);
try { v6.formatRangeToParts(C2); } catch (e) {}