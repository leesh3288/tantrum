
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint8ClampedArray([4.3518649687541,-8.888729705637502e+307,1.0928757339437217e+308,-4.0,-1.0,-5.0,-763.4605671258337,-6.057863720667753e+307]);
FuzzerInjectionPoint(2);
v2.toSorted();
FuzzerInjectionPoint(3);