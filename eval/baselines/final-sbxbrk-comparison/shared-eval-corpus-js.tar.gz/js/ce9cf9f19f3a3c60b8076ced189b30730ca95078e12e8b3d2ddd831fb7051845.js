
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
new Uint16Array(64);
FuzzerInjectionPoint(2);
new Int32Array(5);
FuzzerInjectionPoint(3);
new Float64Array(5);
FuzzerInjectionPoint(4);
function f9() {
FuzzerInjectionPoint(5);
    return { __proto__: "P", f: 1e-15 };
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f9[Symbol.search] = f9;
FuzzerInjectionPoint(8);
[1.8171555894011941,3.0,-1000000000.0,-1.677746549563205e+308,-479372.31639536313,1e-15,-3.0,-7.923591600145845];
FuzzerInjectionPoint(9);
[-942327.1585093158,-1000000.0,-9.864533000504721,-1.4278897788152544e+308,0.12550696040394704,-0.4710129953268769,2.0];
FuzzerInjectionPoint(10);
const v18 = [-5.725933889588806e+307,-365.12833680858887,NaN,-1.7976931348623157e+308];
FuzzerInjectionPoint(11);
[-116719.70005562599,-1000000000.0];
FuzzerInjectionPoint(12);
class C20 {

    #e;

    128;

    5 = 64;

    constructor(a22) {
FuzzerInjectionPoint(17);
        v18.toReversed();
FuzzerInjectionPoint(18);
        function f25() {
FuzzerInjectionPoint(19);
            const v31 = {

                c: null,

                f: f25,

                __proto__: null,

                b: null,

                [null]: null,

                e: null,

                n() {
FuzzerInjectionPoint(27);
                    super.a &= this;
FuzzerInjectionPoint(28);
                    new WeakMap();
FuzzerInjectionPoint(29);
                    const v29 = super.b;
FuzzerInjectionPoint(30);
                    new f25(this);
FuzzerInjectionPoint(31);
                    return v29;
FuzzerInjectionPoint(32);
                },

            };
FuzzerInjectionPoint(34);
            return v31;
FuzzerInjectionPoint(35);
        }
FuzzerInjectionPoint(36);
        return f25();
FuzzerInjectionPoint(37);
        for (let v33 = 0; v33 < 32; v33++) {
FuzzerInjectionPoint(38);
            let v35;
FuzzerInjectionPoint(39);
            try { v35 = ("p").search(f9); } catch (e) {}
FuzzerInjectionPoint(40);
            this[v35 + v33] = v33;
FuzzerInjectionPoint(41);
        }
FuzzerInjectionPoint(42);
        let v37 = -36123;
FuzzerInjectionPoint(43);
        v37++;
FuzzerInjectionPoint(44);
        const v43 = {

            [1000000000000.0]: 8,

            set e(a42) {
FuzzerInjectionPoint(47);
            },

        };
FuzzerInjectionPoint(49);
    }

}
FuzzerInjectionPoint(51);
new C20(f9);
FuzzerInjectionPoint(52);
new Uint16Array();
FuzzerInjectionPoint(53);
const v47 = new Float64Array();
FuzzerInjectionPoint(54);
const v51 = 536870889n + 536870889n;
FuzzerInjectionPoint(55);
const v52 = [-58284,14,-1073741824,7947,-1,255];
FuzzerInjectionPoint(56);
class C53 {

}
FuzzerInjectionPoint(58);
for (let i = 0; i < 25; i++) {
FuzzerInjectionPoint(59);
    const v54 = v52.toSpliced();
FuzzerInjectionPoint(60);
    function F55(a57, a58, a59) {
FuzzerInjectionPoint(61);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(62);
        const v60 = a59?.entries;
FuzzerInjectionPoint(63);
        try { new v60(Uint32Array, v51, 257, v60, v47); } catch (e) {}
FuzzerInjectionPoint(64);
        this.c = v54;
FuzzerInjectionPoint(65);
    }
FuzzerInjectionPoint(66);
    new F55();
FuzzerInjectionPoint(67);
    new F55(C53, v54);
FuzzerInjectionPoint(68);
}
FuzzerInjectionPoint(69);
class C64 extends C20 {

}
FuzzerInjectionPoint(71);
new C64();