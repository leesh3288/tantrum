
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

    0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00,

    0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A,

    0x01, 0x00,

])));
FuzzerInjectionPoint(7);
function f2(a3) {
FuzzerInjectionPoint(8);
    let v5;
FuzzerInjectionPoint(9);
    try { v5 = a3(v0, a3, 6, arguments); } catch (e) {}
FuzzerInjectionPoint(10);
    function f7(a8) {
FuzzerInjectionPoint(11);
        for (let [i12, i13] = (() => {
FuzzerInjectionPoint(12);
                0 >> 0;
FuzzerInjectionPoint(13);
                return [0, a8];
FuzzerInjectionPoint(14);
            })();

            (() => {
FuzzerInjectionPoint(16);
                const v14 = -4 + i12;
FuzzerInjectionPoint(17);
                v14 > v14;
FuzzerInjectionPoint(18);
                return i12;
FuzzerInjectionPoint(19);
            })();

            ) {
FuzzerInjectionPoint(21);
        }
FuzzerInjectionPoint(22);
        return 9223372036854775807;
FuzzerInjectionPoint(23);
    }
FuzzerInjectionPoint(24);
    f7(9223372036854775807);
FuzzerInjectionPoint(25);
    f7(v0);
FuzzerInjectionPoint(26);
    f7(v0);
FuzzerInjectionPoint(27);
    return v5;
FuzzerInjectionPoint(28);
}
FuzzerInjectionPoint(29);
f2(f2);
FuzzerInjectionPoint(30);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(31);
f2(6);