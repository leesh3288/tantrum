
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [0.7284011768201828,-1000000.0,0.035274165649744726,276392.70502625196,-2.2250738585072014e-308,-Infinity];
FuzzerInjectionPoint(2);
const v1 = [-1.7976931348623157e+308,-3.9691683430800033,-5.0,-2.2250738585072014e-308];
FuzzerInjectionPoint(3);
v1[1] = v0;
FuzzerInjectionPoint(4);
const v2 = [337.05924815727985,859.1644951519327,2.220446049250313e-16,3.0,918.804032388844];
FuzzerInjectionPoint(5);
v2[1] = v2;
FuzzerInjectionPoint(6);
class C3 {

    [v2] = v1;

    NEGATIVE_INFINITY = v2;

}
FuzzerInjectionPoint(10);
const v4 = new C3();
FuzzerInjectionPoint(11);
d8.serializer.serialize(v4);