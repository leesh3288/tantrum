
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    const v5 = [a1];
FuzzerInjectionPoint(3);
    const v6 = [a2,a2,a2];
FuzzerInjectionPoint(4);
    new Map(a1);
FuzzerInjectionPoint(5);
    let v8;
FuzzerInjectionPoint(6);
    try { v8 = v6(Map, ...v5, ...v6); } catch (e) {}
FuzzerInjectionPoint(7);
    return v8;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v9 = f0();
FuzzerInjectionPoint(10);
f0(v9, v9, f0);
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(12);
f0();
FuzzerInjectionPoint(13);