
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    for (let i4 = 0, i5 = 10;

        i4 - i4, i5 / i5, i5;

        (() => {
FuzzerInjectionPoint(5);
            i4++;
FuzzerInjectionPoint(6);
            const v11 = i5--;
FuzzerInjectionPoint(7);
            v11 + v11;
FuzzerInjectionPoint(8);
        })()) {
FuzzerInjectionPoint(9);
        const v15 = i5 >> i5;
FuzzerInjectionPoint(10);
        const v16 = v15 + v15;
FuzzerInjectionPoint(11);
        const v17 = { 536870889: v16 };
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    return a1;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
const t14 = f0(f0);
FuzzerInjectionPoint(16);
t14(f0);
FuzzerInjectionPoint(17);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(18);
f0();