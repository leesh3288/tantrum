
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = /\p{Script_Extensions=Greek}/g;
FuzzerInjectionPoint(2);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(3);
    Symbol.name.replace(v0, a2);
FuzzerInjectionPoint(4);
    return Symbol;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
f1(f1);
FuzzerInjectionPoint(7);