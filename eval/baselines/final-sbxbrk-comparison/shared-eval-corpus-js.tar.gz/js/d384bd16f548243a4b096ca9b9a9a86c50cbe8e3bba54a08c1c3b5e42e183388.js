
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);
function F1() {
FuzzerInjectionPoint(4);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(5);
    this.b = f0;
FuzzerInjectionPoint(6);
    this.h = f0;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
new F1();
FuzzerInjectionPoint(9);
new F1();
FuzzerInjectionPoint(10);
new F1();
FuzzerInjectionPoint(11);
[NaN,0.6205073476811465,-8.242381376362574e+307,-3.0];
FuzzerInjectionPoint(12);
[-0.08724859824846476,-1000000.0,849.729220817673,135219.31436507497];
FuzzerInjectionPoint(13);
function f12() {
FuzzerInjectionPoint(14);
    Object.defineProperty([4,-61572,9,1957989437,1073741824,128,-2], -2, { get: Array, set: f0 });
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
f12();
FuzzerInjectionPoint(17);
[-1000000000.0,-1000.0,6.86222964311461,0.16414617482700067,9.335114409829803,-1.0,-1000000000000.0,1000000.0];
FuzzerInjectionPoint(18);
const v17 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(19);
v17.toString = f12;
FuzzerInjectionPoint(20);
class C18 extends Set {

    [v17] = v17;

}
FuzzerInjectionPoint(23);
new Uint32Array(7);
FuzzerInjectionPoint(24);
new Uint16Array(9);
FuzzerInjectionPoint(25);
const v27 = new BigUint64Array(128);
FuzzerInjectionPoint(26);
const v28 = /(?:a*)*(?:a*)*/siy;
FuzzerInjectionPoint(27);
/[E?]/dvsiy;
FuzzerInjectionPoint(28);
/a+?/vgy;
FuzzerInjectionPoint(29);
class C31 {

    static o(a33) {
FuzzerInjectionPoint(31);
        C31 *= F1;
FuzzerInjectionPoint(32);
        const v35 = %WasmStruct();
FuzzerInjectionPoint(33);
        -3.0 & v27;
FuzzerInjectionPoint(34);
        try {
FuzzerInjectionPoint(35);
            f0();
FuzzerInjectionPoint(36);
        } catch(e38) {
FuzzerInjectionPoint(37);
        }
FuzzerInjectionPoint(38);
        new Uint32Array(235);
FuzzerInjectionPoint(39);
        let v43 = new WebAssembly.Memory({ initial: 6, address: 'i32' });
FuzzerInjectionPoint(40);
        try { v43.grow(724637.1538278793); } catch (e) {}
FuzzerInjectionPoint(41);
        d8.test;
FuzzerInjectionPoint(42);
        new BigUint64Array(15);
FuzzerInjectionPoint(43);
        new Float32Array(9);
FuzzerInjectionPoint(44);
        return Float32Array;
FuzzerInjectionPoint(45);
    }

}
FuzzerInjectionPoint(47);
const v52 = new C31(v28);
FuzzerInjectionPoint(48);
v52.constructor = Array;
FuzzerInjectionPoint(49);
const v53 = v52?.constructor;
FuzzerInjectionPoint(50);
try { new v53(); } catch (e) {}
FuzzerInjectionPoint(51);
const v55 = new C31();
FuzzerInjectionPoint(52);
v55.constructor = f0;
FuzzerInjectionPoint(53);
const v56 = v55?.constructor;
FuzzerInjectionPoint(54);
const v69 = {

    valueOf(a58) {
FuzzerInjectionPoint(56);
        const v68 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

            0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0D,

            0x02, 0x60, 0x00, 0x00, 0x60, 0x05, 0x7D, 0x7F, 0x7F, 0x7F,

            0x7C, 0x01, 0x7D, 0x03, 0x02, 0x01, 0x01, 0x04, 0x01, 0x00,

            0x05, 0x01, 0x00, 0x06, 0x01, 0x00, 0x07, 0x06, 0x01, 0x02,

            0x77, 0x30, 0x00, 0x00, 0x09, 0x01, 0x00, 0x0A, 0x15, 0x01,

            0x13, 0x01, 0x01, 0x7F, 0x20, 0x01, 0x04, 0x00, 0x05, 0x0C,

            0x00, 0x20, 0x01, 0x20, 0x03, 0x6C, 0x21, 0x05, 0x0B, 0x0B,

        ])));
FuzzerInjectionPoint(65);
        return this;
FuzzerInjectionPoint(66);
    },

};
FuzzerInjectionPoint(68);
try { new v56(); } catch (e) {}
FuzzerInjectionPoint(69);
const v71 = new C31();
FuzzerInjectionPoint(70);
function f72() {
FuzzerInjectionPoint(71);
    let v75 = -4.0;
FuzzerInjectionPoint(72);
    Math.abs(f12);
FuzzerInjectionPoint(73);
    const v77 = v75--;
FuzzerInjectionPoint(74);
    const v78 = f12--;
FuzzerInjectionPoint(75);
    +-9223372036854775808;
FuzzerInjectionPoint(76);
    Math.acosh(v78);
FuzzerInjectionPoint(77);
    f12 * +v77;
FuzzerInjectionPoint(78);
    return -9223372036854775808;
FuzzerInjectionPoint(79);
}
FuzzerInjectionPoint(80);
v71.constructor = f72;
FuzzerInjectionPoint(81);
function f84() {
FuzzerInjectionPoint(82);
    4096 === (undefined % undefined);
FuzzerInjectionPoint(83);
    return 4096;
FuzzerInjectionPoint(84);
}
FuzzerInjectionPoint(85);
f84();
FuzzerInjectionPoint(86);
const v89 = v71?.constructor;
FuzzerInjectionPoint(87);
try { new v89(); } catch (e) {}
FuzzerInjectionPoint(88);
class C91 extends C31 {

    static set c(a93) {
FuzzerInjectionPoint(90);
        v71.d;
FuzzerInjectionPoint(91);
        super[this] = v55;
FuzzerInjectionPoint(92);
        super[this] = v52;
FuzzerInjectionPoint(93);
    }

    static valueOf(a96, a97, a98) {
FuzzerInjectionPoint(95);
        const t105 = {};
FuzzerInjectionPoint(96);
        t105.b = v71;
FuzzerInjectionPoint(97);
        const v100 = {};
FuzzerInjectionPoint(98);
        v100.b = v71;
FuzzerInjectionPoint(99);
        v100.d = v52;
FuzzerInjectionPoint(100);
        const t110 = {};
FuzzerInjectionPoint(101);
        t110.b = v71;
FuzzerInjectionPoint(102);
        const v102 = {};
FuzzerInjectionPoint(103);
    }

}
FuzzerInjectionPoint(105);
const v104 = this.console;
FuzzerInjectionPoint(106);
const v106 = this.console;
FuzzerInjectionPoint(107);
try { v106.time(); } catch (e) {}
FuzzerInjectionPoint(108);
function f108() {
FuzzerInjectionPoint(109);
}
FuzzerInjectionPoint(110);
function f109(a110, a111) {
FuzzerInjectionPoint(111);
}
FuzzerInjectionPoint(112);
v104.timeEnd();