
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
new F0();
FuzzerInjectionPoint(5);
new F0();
FuzzerInjectionPoint(6);
new F0();
FuzzerInjectionPoint(7);
new Uint8Array(8);
FuzzerInjectionPoint(8);
new Uint16Array(10);
FuzzerInjectionPoint(9);
new BigInt64Array(117);
FuzzerInjectionPoint(10);
function f18() {
FuzzerInjectionPoint(11);
    let v19 = "number";
FuzzerInjectionPoint(12);
    const v30 = {

        [v19]: "bigint",

        f: 44461,

        b: "bigint",

        e: 44461,

        get c() {
FuzzerInjectionPoint(18);
            v19 ??= "bigint";
FuzzerInjectionPoint(19);
            let v23;
FuzzerInjectionPoint(20);
            try { v23 = this.toString(this, 44461, this, 44461, 44461); } catch (e) {}
FuzzerInjectionPoint(21);
            const v27 = 10000 * 44461;
FuzzerInjectionPoint(22);
            v23--;
FuzzerInjectionPoint(23);
            10000 && v27;
FuzzerInjectionPoint(24);
            return 10000;
FuzzerInjectionPoint(25);
        },

    };
FuzzerInjectionPoint(27);
    return v30;
FuzzerInjectionPoint(28);
}
FuzzerInjectionPoint(29);
f18();
FuzzerInjectionPoint(30);
f18();
FuzzerInjectionPoint(31);
f18();
FuzzerInjectionPoint(32);
try { BigInt64Array(BigInt64Array, BigInt64Array, 1760); } catch (e) {}
FuzzerInjectionPoint(33);
new BigInt64Array(2564);
FuzzerInjectionPoint(34);
new Uint8ClampedArray(129);
FuzzerInjectionPoint(35);
function F44() {
FuzzerInjectionPoint(36);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(37);
}
FuzzerInjectionPoint(38);
const v46 = new F44();
FuzzerInjectionPoint(39);
class C47 {

    o(a49) {
FuzzerInjectionPoint(41);
        let v50 = 0;
FuzzerInjectionPoint(42);
        while ((() => {
FuzzerInjectionPoint(43);
                const v52 = v50 < 30271;
FuzzerInjectionPoint(44);
                new Float32Array();
FuzzerInjectionPoint(45);
                return v52;
FuzzerInjectionPoint(46);
            })()) {
FuzzerInjectionPoint(47);
            v46 || a49;
FuzzerInjectionPoint(48);
            v50++;
FuzzerInjectionPoint(49);
        }
FuzzerInjectionPoint(50);
        return this;
FuzzerInjectionPoint(51);
    }

}
FuzzerInjectionPoint(53);
const v57 = new C47();
FuzzerInjectionPoint(54);
v57.o();
FuzzerInjectionPoint(55);
new BigInt64Array();
FuzzerInjectionPoint(56);
/Aa|bc/mdi;
FuzzerInjectionPoint(57);
function f65(a66, a67) {
FuzzerInjectionPoint(58);
    a66[Symbol] = f65;
FuzzerInjectionPoint(59);
    a67 ?? a67;
FuzzerInjectionPoint(60);
    const v71 = Array();
FuzzerInjectionPoint(61);
    const v72 = { __proto__: v71 };
FuzzerInjectionPoint(62);
    return -1n;
FuzzerInjectionPoint(63);
}
FuzzerInjectionPoint(64);
Symbol.toPrimitive.description;
FuzzerInjectionPoint(65);
function f77(a78, a79) {
FuzzerInjectionPoint(66);
    const v80 = {};
FuzzerInjectionPoint(67);
}
FuzzerInjectionPoint(68);
const v83 = new Uint8Array(255);
FuzzerInjectionPoint(69);
v83.find(f77);
FuzzerInjectionPoint(70);
[-1024,64,51519,1,11,744156910,256,536870912,1595533594,-300300815];
FuzzerInjectionPoint(71);
[15257,-2147483649,59990];
FuzzerInjectionPoint(72);
function F87(a89, a90, a91) {
FuzzerInjectionPoint(73);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(74);
    this.a = a90;
FuzzerInjectionPoint(75);
    this.c = a89;
FuzzerInjectionPoint(76);
    this.f = "h";
FuzzerInjectionPoint(77);
}
FuzzerInjectionPoint(78);
const t77 = "256";
FuzzerInjectionPoint(79);
t77.c = "256";
FuzzerInjectionPoint(80);
function f92() {
FuzzerInjectionPoint(81);
}
FuzzerInjectionPoint(82);
([-865879.4747004735]).fill;
FuzzerInjectionPoint(83);
const v98 = new Uint16Array(2991);
FuzzerInjectionPoint(84);
try { Array(); } catch (e) {}
FuzzerInjectionPoint(85);
let v105;
FuzzerInjectionPoint(86);
try { v105 = Array.toReversed(); } catch (e) {}
FuzzerInjectionPoint(87);
Array[1949] = v105;
FuzzerInjectionPoint(88);
function f106() {
FuzzerInjectionPoint(89);
}
FuzzerInjectionPoint(90);
function f107() {
FuzzerInjectionPoint(91);
}
FuzzerInjectionPoint(92);
function f109() {
FuzzerInjectionPoint(93);
    -2.0 * -2.0;
FuzzerInjectionPoint(94);
    f106();
FuzzerInjectionPoint(95);
    undefined ?? undefined;
FuzzerInjectionPoint(96);
    function f117(a118) {
FuzzerInjectionPoint(97);
        const v119 = { a: -163530867 };
FuzzerInjectionPoint(98);
        v119.f = v119;
FuzzerInjectionPoint(99);
    }
FuzzerInjectionPoint(100);
}
FuzzerInjectionPoint(101);
f109();
FuzzerInjectionPoint(102);
f109();
FuzzerInjectionPoint(103);
const v126 = new Uint32Array(3127);
FuzzerInjectionPoint(104);
function f127() {
FuzzerInjectionPoint(105);
    function f128(a129) {
FuzzerInjectionPoint(106);
        a129 << a129;
FuzzerInjectionPoint(107);
        const v133 = {

            set b(a132) {
FuzzerInjectionPoint(109);
            },

        };
FuzzerInjectionPoint(111);
    }
FuzzerInjectionPoint(112);
    try { f128(v98); } catch (e) {}
FuzzerInjectionPoint(113);
    return v126;
FuzzerInjectionPoint(114);
}
FuzzerInjectionPoint(115);
function f135(a136, a137, a138, a139) {
FuzzerInjectionPoint(116);
}
FuzzerInjectionPoint(117);
class C140 {

}
FuzzerInjectionPoint(119);
class C141 {

}
FuzzerInjectionPoint(121);
class C142 {

}
FuzzerInjectionPoint(123);
C142.b = C142;
FuzzerInjectionPoint(124);
f127().reduce(f135);
FuzzerInjectionPoint(125);
f127();