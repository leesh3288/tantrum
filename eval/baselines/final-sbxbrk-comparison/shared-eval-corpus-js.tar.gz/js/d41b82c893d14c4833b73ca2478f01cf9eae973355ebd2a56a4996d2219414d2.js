
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = this.Intl.DurationFormat;
FuzzerInjectionPoint(2);
const v4 = new t0();
FuzzerInjectionPoint(3);
Object.defineProperty(v4, "hours", { enumerable: true, value: -9007199254740991 });
FuzzerInjectionPoint(4);
try { v4.format(v4); } catch (e) {}
FuzzerInjectionPoint(5);