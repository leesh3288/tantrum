
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2() {
FuzzerInjectionPoint(2);
    let v3 = -163530867;
FuzzerInjectionPoint(3);
    const v4 = v3--;
FuzzerInjectionPoint(4);
    v4 * v4;
FuzzerInjectionPoint(5);
    function f6(a7, a8, a9) {
FuzzerInjectionPoint(6);
        a7 % a7;
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    f6(0.6605149937330983);
FuzzerInjectionPoint(9);
    f6();
FuzzerInjectionPoint(10);
    class C13 {

        static [Float32Array] = f2;

    }
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
f2();
FuzzerInjectionPoint(15);
f2();
FuzzerInjectionPoint(16);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(17);
f2();