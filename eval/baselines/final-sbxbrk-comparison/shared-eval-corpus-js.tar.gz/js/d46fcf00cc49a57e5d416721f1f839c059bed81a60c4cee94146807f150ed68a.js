
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
/a\DB[x\dz]S\P{Any}?/v;
FuzzerInjectionPoint(2);
/p(\2)(\1)+/ugi;
FuzzerInjectionPoint(3);
const v12 = new Uint8ClampedArray(257);
FuzzerInjectionPoint(4);
v12.set(Uint8Array);
FuzzerInjectionPoint(5);
const v15 = new Uint8ClampedArray(1);
FuzzerInjectionPoint(6);
v15[0] = v15;
FuzzerInjectionPoint(7);