
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
async function f4(a5, a6, a7) {

    const v12 = {

        [Symbol]() {

        },

    };

    await using v13 = v12;

    return f4;

}

const v14 = f4();

const v16 = d8.FastCAPI;

const v18 = [4,-61572,9,1957989437,1073741824,128,-2];

d8[Symbol];

const v28 = Math.expm1();

v28 % v28;

const v30 = `

`;

const v35 = new Int16Array();

v35.join(v16);

function f37(a38, a39, a40) {

    return 2940;

}

v14.catch(f37);

[Int16Array,v18];