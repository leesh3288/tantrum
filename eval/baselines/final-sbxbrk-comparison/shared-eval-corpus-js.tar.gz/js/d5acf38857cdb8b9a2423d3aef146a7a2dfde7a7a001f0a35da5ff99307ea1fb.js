
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F3(a5, a6, a7, a8) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    this.f = a6;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
const v9 = new F3(2.2250738585072014e-308, 1783888990, 1783888990, -9223372036854775808);
FuzzerInjectionPoint(6);
new F3(v9, 1783888990, v9, 1783888990);
FuzzerInjectionPoint(7);
function f11() {
FuzzerInjectionPoint(8);
    const v14 = undefined >>> undefined;
FuzzerInjectionPoint(9);
    __proto__.constructor;
FuzzerInjectionPoint(10);
    function f16(a17, a18, a19) {
FuzzerInjectionPoint(11);
        return __proto__;
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    f16(v14);
FuzzerInjectionPoint(14);
    return f11;
FuzzerInjectionPoint(15);
}
FuzzerInjectionPoint(16);
const t15 = f11();
FuzzerInjectionPoint(17);
t15();
FuzzerInjectionPoint(18);
function f24() {
FuzzerInjectionPoint(19);
    for (let v26 = 0; v26 < 5; v26++) {
FuzzerInjectionPoint(20);
        const v28 = new WeakSet();
FuzzerInjectionPoint(21);
        function F29(a31, a32) {
FuzzerInjectionPoint(22);
            if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(23);
            this.c = WeakSet;
FuzzerInjectionPoint(24);
        }
FuzzerInjectionPoint(25);
        function f33() {
FuzzerInjectionPoint(26);
            const v35 = ("function").slice();
FuzzerInjectionPoint(27);
            v35[0];
FuzzerInjectionPoint(28);
            try { v35(); } catch (e) {}
FuzzerInjectionPoint(29);
            v35[2];
FuzzerInjectionPoint(30);
            return "function";
FuzzerInjectionPoint(31);
        }
FuzzerInjectionPoint(32);
        const v39 = f33();
FuzzerInjectionPoint(33);
        new F29(F29, v28);
FuzzerInjectionPoint(34);
        new F29();
FuzzerInjectionPoint(35);
        new F29();
FuzzerInjectionPoint(36);
        new Uint16Array();
FuzzerInjectionPoint(37);
        new BigInt64Array(3097);
FuzzerInjectionPoint(38);
        new Uint8Array(10);
FuzzerInjectionPoint(39);
        function f55() {
FuzzerInjectionPoint(40);
            return f55;
FuzzerInjectionPoint(41);
        }
FuzzerInjectionPoint(42);
        function f56() {
FuzzerInjectionPoint(43);
            const v68 = {

                p(a58, a59) {
FuzzerInjectionPoint(45);
                    let v60 = new WebAssembly.Global({ value: "f64", mutable: false }, 4.319357700079234e+307);
FuzzerInjectionPoint(46);
                    function f61(a62) {
FuzzerInjectionPoint(47);
                        ([-596992.2717851705,1.3656356845740762e+308]).concat();
FuzzerInjectionPoint(48);
                        const v66 = [-596992.2717851705,1.3656356845740762e+308];
FuzzerInjectionPoint(49);
                        try { v66.every(); } catch (e) {}
FuzzerInjectionPoint(50);
                        v66[94] = Float32Array;
FuzzerInjectionPoint(51);
                        return a58;
FuzzerInjectionPoint(52);
                    }
FuzzerInjectionPoint(53);
                    v60.constructor = f61;
FuzzerInjectionPoint(54);
                    return v60;
FuzzerInjectionPoint(55);
                },

                f: -8,

                type: v39,

                a: 10,

                maxByteLength: 256,

                e: 256,

            };
FuzzerInjectionPoint(62);
            for (let v69 = 0; v69 < 32; v69++) {
FuzzerInjectionPoint(63);
                const v71 = "p" + v69;
FuzzerInjectionPoint(64);
                const v73 = this.setTimeout;
FuzzerInjectionPoint(65);
                new v73(v73, v73, this);
FuzzerInjectionPoint(66);
                v28[v71] = v69;
FuzzerInjectionPoint(67);
            }
FuzzerInjectionPoint(68);
            const v76 = v68["p"]();
FuzzerInjectionPoint(69);
            v76.constructor = f55;
FuzzerInjectionPoint(70);
            v76.constructor;
FuzzerInjectionPoint(71);
            return f56;
FuzzerInjectionPoint(72);
        }
FuzzerInjectionPoint(73);
        const v78 = f56();
FuzzerInjectionPoint(74);
        f56();
FuzzerInjectionPoint(75);
        const v81 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(76);
        function f82(a83, a84) {
FuzzerInjectionPoint(77);
            v78();
FuzzerInjectionPoint(78);
        }
FuzzerInjectionPoint(79);
        v81.toString = f82;
FuzzerInjectionPoint(80);
        class C86 extends Set {

            [v81] = v81;

        }
FuzzerInjectionPoint(83);
        const t82 = {};
FuzzerInjectionPoint(84);
        t82.a = -163530867;
FuzzerInjectionPoint(85);
        const t84 = {};
FuzzerInjectionPoint(86);
        t84.e = v26;
FuzzerInjectionPoint(87);
    }
FuzzerInjectionPoint(88);
}
FuzzerInjectionPoint(89);
f24();