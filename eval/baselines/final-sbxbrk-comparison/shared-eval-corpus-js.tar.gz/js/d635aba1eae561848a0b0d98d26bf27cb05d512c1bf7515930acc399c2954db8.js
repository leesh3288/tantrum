
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v1 = "bigint";
FuzzerInjectionPoint(2);
function f6(a7) {
FuzzerInjectionPoint(3);
    const v17 = {

        3: a7,

        ..."eTr",

        __proto__: a7,

        g: "pop",

        valueOf(a9, a10) {
FuzzerInjectionPoint(9);
            super.a;
FuzzerInjectionPoint(10);
            %VerifyType(a7);
FuzzerInjectionPoint(11);
            return this;
FuzzerInjectionPoint(12);
        },

        e: v1,

        o(a13, a14) {
FuzzerInjectionPoint(15);
            return f6;
FuzzerInjectionPoint(16);
        },

        [255](a16) {
FuzzerInjectionPoint(18);
            v1 &= v1;
FuzzerInjectionPoint(19);
        },

        c: "pop",

        f: "pop",

        b: v1,

    };
FuzzerInjectionPoint(24);
    return 255;
FuzzerInjectionPoint(25);
}
FuzzerInjectionPoint(26);
f6(255);
FuzzerInjectionPoint(27);
const v19 = ("pop").__proto__;
FuzzerInjectionPoint(28);
const v20 = f6(Math);
FuzzerInjectionPoint(29);
v19[3] ^= "W";
FuzzerInjectionPoint(30);
%OptimizeFunctionOnNextCall(f6);
FuzzerInjectionPoint(31);
f6(v20);