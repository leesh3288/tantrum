
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v1 = [10000];
FuzzerInjectionPoint(3);
    for (let v2 = 0; v2 < 5; v2++) {
FuzzerInjectionPoint(4);
        let v3 = v1[v2];
FuzzerInjectionPoint(5);
        v3--;
FuzzerInjectionPoint(6);
        [v3];
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    return f0;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v6 = f0();
FuzzerInjectionPoint(11);
f0();
FuzzerInjectionPoint(12);
const v9 = /\u{12345}\u{23456}/dvi;
FuzzerInjectionPoint(13);
function f10(a11, a12) {
FuzzerInjectionPoint(14);
    %OptimizeFunctionOnNextCall(v6);
FuzzerInjectionPoint(15);
    v6();
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
v9.toString = f10;
FuzzerInjectionPoint(18);
class C14 extends Set {

    [v9] = v9;

}