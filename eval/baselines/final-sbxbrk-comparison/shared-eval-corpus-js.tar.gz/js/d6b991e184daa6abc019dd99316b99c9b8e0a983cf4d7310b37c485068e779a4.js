
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new ArrayBuffer(128, { maxByteLength: 1073741823 });
FuzzerInjectionPoint(2);
const v6 = new Uint32Array(v4);
FuzzerInjectionPoint(3);
v6.fill(128);
FuzzerInjectionPoint(4);