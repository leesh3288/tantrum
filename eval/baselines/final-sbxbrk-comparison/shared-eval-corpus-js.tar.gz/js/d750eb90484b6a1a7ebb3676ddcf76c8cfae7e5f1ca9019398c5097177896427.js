
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = 9;
FuzzerInjectionPoint(2);
v0--;
FuzzerInjectionPoint(3);
let v2 = 4294967296;
FuzzerInjectionPoint(4);
v2--;
FuzzerInjectionPoint(5);
v2.toExponential(v0);
FuzzerInjectionPoint(6);