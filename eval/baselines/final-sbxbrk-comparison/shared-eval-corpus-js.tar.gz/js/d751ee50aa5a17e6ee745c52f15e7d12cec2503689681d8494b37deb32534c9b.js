
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F3(a5, a6, a7, a8) {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    this.c = a8;
FuzzerInjectionPoint(4);
    try {
FuzzerInjectionPoint(5);
        new F3(/K(x)(x)(x)\3/msg, a8, a6, a7);
FuzzerInjectionPoint(6);
    } catch(e11) {
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    this.a = a6;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
new F3(-799.6885588042572, -8.017748701115145e+307, -799.6885588042572, 127);
FuzzerInjectionPoint(11);