
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v1 = [4,-61572,9,1957989437,1073741824,128,-2];
FuzzerInjectionPoint(3);
    for (let v2 = 0; v2 < 5; v2++) {
FuzzerInjectionPoint(4);
        const v3 = v1[v2];
FuzzerInjectionPoint(5);
        const v4 = v3 <= v3;
FuzzerInjectionPoint(6);
        v1 ** undefined;
FuzzerInjectionPoint(7);
        v4 || v4;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    return v1;
FuzzerInjectionPoint(10);
}
FuzzerInjectionPoint(11);
f0();
FuzzerInjectionPoint(12);
f0();
FuzzerInjectionPoint(13);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(14);
f0();
FuzzerInjectionPoint(15);