
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [302239.4961433639,1.7866653180962744e+308,0.39596782819888043,1000000000000.0,-4.0,Infinity,-3.0];
FuzzerInjectionPoint(2);
function f2() {
FuzzerInjectionPoint(3);
    return 536870888;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
Object.defineProperty(v1, 1310, { get: f2 });
FuzzerInjectionPoint(6);
const v4 = new Int16Array(v1);
FuzzerInjectionPoint(7);
v4.toSorted();
FuzzerInjectionPoint(8);