
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    gc();
FuzzerInjectionPoint(3);
    return f1;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
([Date,-2.2250738585072014e-308]).toSorted(f1);
FuzzerInjectionPoint(6);