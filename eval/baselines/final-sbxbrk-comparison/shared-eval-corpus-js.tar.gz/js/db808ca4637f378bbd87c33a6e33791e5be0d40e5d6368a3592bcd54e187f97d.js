
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {

    const v4 = `

        function f5() {

            return a1;

        }

        %PrepareFunctionForOptimization(f5);

    `;

    return eval(v4);

}

const v11 = new Worker(f0, { type: "function" });

v11.getMessage();