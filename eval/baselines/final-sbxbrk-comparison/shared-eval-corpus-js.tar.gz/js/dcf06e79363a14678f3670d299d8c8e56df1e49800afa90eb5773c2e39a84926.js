
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
({}).constructor.getOwnPropertyDescriptors(2147483647);
FuzzerInjectionPoint(2);