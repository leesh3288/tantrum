
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [0.08744074730537432,1.7976931348623157e+308,-4.0,-4.9042441963048855,0.0];
FuzzerInjectionPoint(2);
const v5 = new SharedArrayBuffer(127, { maxByteLength: 512 });
FuzzerInjectionPoint(3);
const v7 = new Float32Array(v5);
FuzzerInjectionPoint(4);
v7.set(v0);
FuzzerInjectionPoint(5);