
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
[-9007199254740991,-5,-65537,-57542];
FuzzerInjectionPoint(2);
[-778966321,1216758298,65535,-9007199254740990,-16,1073741824,57336];
FuzzerInjectionPoint(3);
[-1024,508813755,-1731993800,-18078];
FuzzerInjectionPoint(4);
const v13 = new Set();
FuzzerInjectionPoint(5);
const v14 = [0.5093363633504279,-2.220446049250313e-16,-770140.2550840684,-1.6419775390635512e+308,-1e-15,1.0,-3.0,-1.7435584940026449e+308];
FuzzerInjectionPoint(6);
const v15 = [348.8277428642059];
FuzzerInjectionPoint(7);
const v16 = [-1000000.0,1.0,NaN,-1.7976931348623157e+308,1e-15,-566.6526311815971,-1000000000.0];
FuzzerInjectionPoint(8);
function F17(a19, a20) {
FuzzerInjectionPoint(9);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(10);
    this.b = a20;
FuzzerInjectionPoint(11);
    this.a = a20;
FuzzerInjectionPoint(12);
    this.g = a20;
FuzzerInjectionPoint(13);
}
FuzzerInjectionPoint(14);
const v21 = new F17(v16, v15);
FuzzerInjectionPoint(15);
const v22 = new F17(v13, v15);
FuzzerInjectionPoint(16);
const v23 = new F17(v22, v16);
FuzzerInjectionPoint(17);
function f24(a25, a26, a27, a28) {
FuzzerInjectionPoint(18);
    const v51 = {

        ...a26,

        g: Set,

        ...v13,

        [v16]: a26,

        a: Set,

        toString(a30, a31, a32, a33) {
FuzzerInjectionPoint(25);
            a26.valueOf = a28;
FuzzerInjectionPoint(26);
            function f36(a37) {
FuzzerInjectionPoint(27);
                const v41 = {

                    g: a37,

                    toString(a39, a40) {
FuzzerInjectionPoint(30);
                        return a37;
FuzzerInjectionPoint(31);
                    },

                    ["d"]: "length",

                    6: a37,

                    65537: a37,

                    h: a37,

                };
FuzzerInjectionPoint(37);
                return v41;
FuzzerInjectionPoint(38);
            }
FuzzerInjectionPoint(39);
            const v42 = f36();
FuzzerInjectionPoint(40);
            const v43 = f36(v42);
FuzzerInjectionPoint(41);
            function f44(a45, a46, a47, a48) {
FuzzerInjectionPoint(42);
                return { ...v42, __proto__: v43, 3050677988: a45 };
FuzzerInjectionPoint(43);
            }
FuzzerInjectionPoint(44);
            f44(v43, v43, "length", "length");
FuzzerInjectionPoint(45);
            return a33;
FuzzerInjectionPoint(46);
        },

        ...a28,

        [a28]: a26,

        e: Set,

        [a27]: v13,

        __proto__: v15,

        h: a25,

    };
FuzzerInjectionPoint(54);
    return v51;
FuzzerInjectionPoint(55);
}
FuzzerInjectionPoint(56);
f24(v16, v23, v15, v21);
FuzzerInjectionPoint(57);
f24(v14, v23, v16, v21);
FuzzerInjectionPoint(58);
f24(v14, v21, v15, v22);
FuzzerInjectionPoint(59);
const v58 = [4,129,4294967295,127,536870888,65537,-34973,-2147483648,-58606,-2147483647];
FuzzerInjectionPoint(60);
const v59 = [-16787,-1098236850];
FuzzerInjectionPoint(61);
const v60 = [1073741824,36407,-29042,-10,-39735];
FuzzerInjectionPoint(62);
function F61(a63, a64) {
FuzzerInjectionPoint(63);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(64);
    this.f = a63;
FuzzerInjectionPoint(65);
    this.g = a63;
FuzzerInjectionPoint(66);
}
FuzzerInjectionPoint(67);
new F61(v59, v58);
FuzzerInjectionPoint(68);
new F61(v58, v58);
FuzzerInjectionPoint(69);
const v67 = new F61(v58, v58);
FuzzerInjectionPoint(70);
[v67,v59,[v58,1e-15,0.7445986454425726,v59,-207.33561035990272],-207.33561035990272,v60];
FuzzerInjectionPoint(71);
[-207.33561035990272,v59];
FuzzerInjectionPoint(72);
const v77 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

    0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x0E,

    0x02, 0x60, 0x06, 0x7D, 0x7E, 0x7E, 0x7E, 0x7D, 0x7E, 0x00,

    0x60, 0x01, 0x7C, 0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00,

    0x05, 0x03, 0x01, 0x04, 0x07, 0x0D, 0x05, 0x02, 0x00, 0x00,

    0x00, 0x01, 0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01,

    0x00, 0x0A, 0x01, 0x00,

])));
FuzzerInjectionPoint(80);
("-65537").exports;
FuzzerInjectionPoint(81);
let v82 = new WebAssembly.Tag({parameters: ["i32", "f32", "f64", "f64"]});
FuzzerInjectionPoint(82);
("multiline").length;
FuzzerInjectionPoint(83);
("message").length;
FuzzerInjectionPoint(84);
gc();