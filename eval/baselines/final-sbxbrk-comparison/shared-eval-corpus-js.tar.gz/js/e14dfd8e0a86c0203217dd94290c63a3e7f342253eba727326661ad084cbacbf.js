
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    try {
FuzzerInjectionPoint(3);
        f0();
FuzzerInjectionPoint(4);
    } catch(e5) {
FuzzerInjectionPoint(5);
        const v6 = [65536,65535,1500388643,16,38993,13,65537];
FuzzerInjectionPoint(6);
        const v7 = [268435456,536870889,-8,-1843,5,-9007199254740990,1750688647];
FuzzerInjectionPoint(7);
        function f8() {
FuzzerInjectionPoint(8);
            return a3;
FuzzerInjectionPoint(9);
        }
FuzzerInjectionPoint(10);
        function f9(a10) {
FuzzerInjectionPoint(11);
            return f0;
FuzzerInjectionPoint(12);
        }
FuzzerInjectionPoint(13);
        Object.defineProperty(v7, "ignorePunctuation", { get: f8, set: f9 });
FuzzerInjectionPoint(14);
        ("R1").localeCompare(v6, "symbol", v7);
FuzzerInjectionPoint(15);
    }
FuzzerInjectionPoint(16);
    return f0;
FuzzerInjectionPoint(17);
}
FuzzerInjectionPoint(18);
f0(f0, f0, f0);
FuzzerInjectionPoint(19);