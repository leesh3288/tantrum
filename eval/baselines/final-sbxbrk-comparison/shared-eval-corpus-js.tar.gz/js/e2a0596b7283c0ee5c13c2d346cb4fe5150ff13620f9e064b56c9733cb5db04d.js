
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3) {
FuzzerInjectionPoint(2);
    return Symbol.dispose;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f6(a7, a8) {
FuzzerInjectionPoint(5);
    const v10 = Symbol.prototype;
FuzzerInjectionPoint(6);
    try { v10.valueOf(); } catch (e) {}
FuzzerInjectionPoint(7);
    const v12 = { [WeakSet]: a8 };
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
const v15 = new Uint8Array(255);
FuzzerInjectionPoint(10);
v15.find(f6);
FuzzerInjectionPoint(11);