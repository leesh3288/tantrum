
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C0 {

}

function f1(a2, a3) {

    function f4(a5) {

        const v7 = { maxByteLength: 257 };

        class C9 {

            constructor(a11, a12) {

            }

            static name = "-9223372036854775807";

        }

        C9[0] = "-9223372036854775807";

        function f13() {

        }

        function f14() {

            [536870912,4] >> 45324;

        }

        f14();

        function F19() {

            if (!new.target) { throw 'must be called with new'; }

            this.b = -28079;

        }

        F19();

        function F23(a25) {

            if (!new.target) { throw 'must be called with new'; }

            const v26 = {};

            function f27(a28) {

            }

        }

    }

    C0.onmessage = f4;

    function F29(a31, a32) {

        if (!new.target) { throw 'must be called with new'; }

    }

    function f33() {

        function f34(a35) {

            return f33;

        }

        const v37 = f34 && 23588;

        v37 && v37;

    }

    function f39() {

        for (let v40 = 0; v40 < 5; v40++) {

        }

    }

}

new Worker(f1, { type: "function" });

gc();