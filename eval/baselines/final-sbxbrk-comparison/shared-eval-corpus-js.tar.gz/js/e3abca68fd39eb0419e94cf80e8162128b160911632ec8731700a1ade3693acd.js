
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Float32Array(512);
FuzzerInjectionPoint(2);
const v4 = { 3735770665: -663532.7850352083, ...v2 };
FuzzerInjectionPoint(3);
const v5 = { ...v4 };
FuzzerInjectionPoint(4);