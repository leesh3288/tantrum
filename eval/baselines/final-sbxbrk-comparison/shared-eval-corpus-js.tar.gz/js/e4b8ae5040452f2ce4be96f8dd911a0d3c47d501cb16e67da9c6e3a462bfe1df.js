
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = [2.220446049250313e-16,-1.0];
FuzzerInjectionPoint(2);
const v3 = constructor();
FuzzerInjectionPoint(3);
function f4(a5, a6, a7) {
FuzzerInjectionPoint(4);
    a5.g = Uint8Array;
FuzzerInjectionPoint(5);
    a5.g = a5;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
f4.g = Uint8Array;
FuzzerInjectionPoint(8);
f4(v1);
FuzzerInjectionPoint(9);
f4(f4);
FuzzerInjectionPoint(10);
f4(v3);
FuzzerInjectionPoint(11);
const v11 = {};
FuzzerInjectionPoint(12);
v11[Symbol.toPrimitive] = f4;
FuzzerInjectionPoint(13);
Uint32Array.toString().codePointAt(v11);
FuzzerInjectionPoint(14);