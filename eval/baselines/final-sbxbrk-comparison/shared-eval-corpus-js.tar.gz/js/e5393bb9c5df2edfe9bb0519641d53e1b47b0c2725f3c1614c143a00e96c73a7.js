
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new SharedArrayBuffer(2459, { maxByteLength: 2459 });
FuzzerInjectionPoint(2);
const v6 = new Uint8Array(v4);
FuzzerInjectionPoint(3);
const t2 = v6.constructor;
FuzzerInjectionPoint(4);
new t2(v6);
FuzzerInjectionPoint(5);