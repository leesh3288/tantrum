
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C1 extends Map {

}
FuzzerInjectionPoint(3);
const v2 = C1 + C1;
FuzzerInjectionPoint(4);
function f3(a4) {
FuzzerInjectionPoint(5);
    return a4;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v5 = f3.constructor;
FuzzerInjectionPoint(8);
try { v5(v2); } catch (e) {}