
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint8ClampedArray();
FuzzerInjectionPoint(2);
v2.filter(Uint16Array);
FuzzerInjectionPoint(3);