
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
class C2 {

}
FuzzerInjectionPoint(6);
function f3() {
FuzzerInjectionPoint(7);
    const v4 = { 257: F0 };
FuzzerInjectionPoint(8);
    v4[257];
FuzzerInjectionPoint(9);
    const v6 = v4[257];
FuzzerInjectionPoint(10);
    v6.name = v6;
FuzzerInjectionPoint(11);
    const v7 = v4[257];
FuzzerInjectionPoint(12);
    const v8 = v7?.apply;
FuzzerInjectionPoint(13);
    try { v8(C2, C2); } catch (e) {}
FuzzerInjectionPoint(14);
    v7.prototype = v7;
FuzzerInjectionPoint(15);
    return v7;
FuzzerInjectionPoint(16);
}
FuzzerInjectionPoint(17);
function f10() {
FuzzerInjectionPoint(18);
    const v11 = new f3();
FuzzerInjectionPoint(19);
    new v11();
FuzzerInjectionPoint(20);
    return f10;
FuzzerInjectionPoint(21);
}
FuzzerInjectionPoint(22);
f10();
FuzzerInjectionPoint(23);
f10();
FuzzerInjectionPoint(24);
%OptimizeMaglevOnNextCall(f10);
FuzzerInjectionPoint(25);
f10();