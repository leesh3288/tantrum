
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {
FuzzerInjectionPoint(2);
    return 4294967297;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v3 = [-256,1024,4294967296];
FuzzerInjectionPoint(5);
v3[Symbol.toPrimitive] = f0;
FuzzerInjectionPoint(6);
let v6 = new WebAssembly.Global({ value: "i32", mutable: true }, -401581884);
FuzzerInjectionPoint(7);
v6.value = v3;
FuzzerInjectionPoint(8);