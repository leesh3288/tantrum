
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

}

class C1 extends f0 {

}

const v2 = new C1();

try { v2.constructor(); } catch (e) {}

const v4 = [4,-61572,9,1957989437,1073741824,128,-2];

const v8 = constructor().AsyncDisposableStack;

function f9(a10) {

    return constructor;

}

const v11 = new v8();

v11.defer(Float64Array);

v11.adopt(v4, f9);

v11.disposeAsync().then(Float64Array, constructor);

new Int16Array(268435456);