
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = constructor().Float16Array;

const v7 = new SharedArrayBuffer(9, { maxByteLength: 1024 });

const v8 = new v2(v7);

v8[0] = v8;

const v10 = new Uint16Array(v8);

const t5 = v10.constructor;

new t5(v8);