
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

    for (let i3 = 0, i4 = 10;

        i3 < i4;

        (() => {

            const v8 = `

                class C9 {

                }

                function f10() {

                }

                try { C9(); } catch (e) {}

            `;

            eval(v8);

            i3++;

        })()) {

    }

}

const v20 = new Worker(f0, { type: "function" });

v20.getMessage();