
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    return f0;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
const v1 = [-1.7976931348623157e+308,-2.0];
FuzzerInjectionPoint(5);
v1.numeric = f0;
FuzzerInjectionPoint(6);
("toString").localeCompare("8", "toString", v1);
FuzzerInjectionPoint(7);