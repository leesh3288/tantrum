
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = Math.expm1();

const v2 = {};

const v3 = {};

function f7() {

    return f7;

}

class C8 {

}

function f9(a10, a11) {

    for (let v12 in C8) {

        let v13 = --v12;

        [,v12,...v13] = a11;

        const v15 = gc(a11);

        Math.E **= 2490;

        v3[1821579245];

        function F17(a19, a20, a21) {

            if (!new.target) { throw 'must be called with new'; }

            this.c = v15;

        }

        F17(2, v2);

        F17(v1);

        F17(4096, f7);

        Math.sinh();

        Math.abs();

        f9();

    }

    return a11;

}

new Worker(f9, { type: "function" });