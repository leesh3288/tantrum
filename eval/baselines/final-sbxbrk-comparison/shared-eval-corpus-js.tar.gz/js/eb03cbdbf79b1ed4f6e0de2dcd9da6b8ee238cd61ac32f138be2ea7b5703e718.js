
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = /abc?/musg;
FuzzerInjectionPoint(2);
const v1 = /W/dsgi;
FuzzerInjectionPoint(3);
function f2(a3, a4) {
FuzzerInjectionPoint(4);
    a3.flags;
FuzzerInjectionPoint(5);
    function F6(a8, a9, a10) {
FuzzerInjectionPoint(6);
        if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(7);
    }
FuzzerInjectionPoint(8);
    F6.constructor;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f2(v1);
FuzzerInjectionPoint(11);
const v13 = v0.__proto__;
FuzzerInjectionPoint(12);
f2(v13);
FuzzerInjectionPoint(13);
%OptimizeMaglevOnNextCall(f2);
FuzzerInjectionPoint(14);
f2(v1);
FuzzerInjectionPoint(15);
try { ("execution").replaceAll(v13); } catch (e) {}
FuzzerInjectionPoint(16);