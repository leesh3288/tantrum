
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function F0() {
FuzzerInjectionPoint(2);
    if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(3);
    this.d = 4;
FuzzerInjectionPoint(4);
    this.f = 4;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
new F0();
FuzzerInjectionPoint(7);
function f5() {
FuzzerInjectionPoint(8);
    return "TEXAH";
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
class C6 extends F0 {

    m(a8, a9, a10) {
FuzzerInjectionPoint(12);
        super.e = f5;
FuzzerInjectionPoint(13);
        [0.9687634614107532,918.2791635452265,476.29725593065245,-2.0,4.0,1000000000.0,448115.349048499,0.03316018248125818,2.220446049250313e-16,-5.721080061582893e+307];
FuzzerInjectionPoint(14);
        [-4.0,7.379760841446739,3.8012310346284135,2.220446049250313e-16,Infinity,0.07129954393205962];
FuzzerInjectionPoint(15);
    }

    p(a14, a15, a16, a17) {
FuzzerInjectionPoint(17);
        return a15 ? a15 : F0;
FuzzerInjectionPoint(18);
    }

}
FuzzerInjectionPoint(20);
function f19() {
FuzzerInjectionPoint(21);
}
FuzzerInjectionPoint(22);
function f20() {
FuzzerInjectionPoint(23);
    return f19;
FuzzerInjectionPoint(24);
}
FuzzerInjectionPoint(25);
class C23 {

    g;

    h = "object";

    123;

    c = -4.221877022850638;

}
FuzzerInjectionPoint(31);
new C23();
FuzzerInjectionPoint(32);
const v25 = [f19];
FuzzerInjectionPoint(33);
const v26 = [v25];
FuzzerInjectionPoint(34);
[v25,v25,f19];
FuzzerInjectionPoint(35);
class C28 extends f20 {

    static 268435441 = v26;

}
FuzzerInjectionPoint(38);
const v29 = new C28();
FuzzerInjectionPoint(39);
const v32 = new Int8Array(f19, Int8Array, Int8Array);
FuzzerInjectionPoint(40);
const v35 = new WeakSet();
FuzzerInjectionPoint(41);
function f36(a37, a38) {
FuzzerInjectionPoint(42);
    const v39 = {

        f: WeakSet,

        [a37]: a37,

        d: WeakSet,

        [v35]: a38,

        c: v35,

        h: a37,

        [a38]: v35,

        g: a37,

        ...a38,

    };
FuzzerInjectionPoint(53);
    return v39;
FuzzerInjectionPoint(54);
}
FuzzerInjectionPoint(55);
const v41 = new Uint32Array(3127);
FuzzerInjectionPoint(56);
const v44 = new BigInt64Array(f20);
FuzzerInjectionPoint(57);
function f45() {
FuzzerInjectionPoint(58);
    return v41;
FuzzerInjectionPoint(59);
}
FuzzerInjectionPoint(60);
function f46(a47, a48, a49, a50) {
FuzzerInjectionPoint(61);
    const v68 = {

        get g() {
FuzzerInjectionPoint(63);
            const t0 = [];
FuzzerInjectionPoint(64);
            t0.length %= 2455;
FuzzerInjectionPoint(65);
            function f58(a59, a60, a61) {
FuzzerInjectionPoint(66);
                const v62 = {

                    3947: a59,

                    [1467691842n]: a59,

                    68: a60,

                    256: -65536n,

                    [a59]: "exec",

                };
FuzzerInjectionPoint(73);
            }
FuzzerInjectionPoint(74);
            !3;
FuzzerInjectionPoint(75);
            Math.min(Uint32Array);
FuzzerInjectionPoint(76);
            Math.log(6);
FuzzerInjectionPoint(77);
            return 3 || 3;
FuzzerInjectionPoint(78);
        },

    };
FuzzerInjectionPoint(80);
    return a50;
FuzzerInjectionPoint(81);
}
FuzzerInjectionPoint(82);
-4 | 256;
FuzzerInjectionPoint(83);
Math.log1p(v44);
FuzzerInjectionPoint(84);
~v29;
FuzzerInjectionPoint(85);
~v32;
FuzzerInjectionPoint(86);
Math.cbrt(-9.33170269049412e+307);
FuzzerInjectionPoint(87);
Math.cbrt();
FuzzerInjectionPoint(88);
let v79 = f46(256, 256, v44, v41);
FuzzerInjectionPoint(89);
function f82(a83, a84, a85) {
FuzzerInjectionPoint(90);
    const v86 = { 3947: a83, [1467691842n]: a83, 68: a84, [a83]: "exec" };
FuzzerInjectionPoint(91);
}
FuzzerInjectionPoint(92);
f46(2455, 3127, BigInt64Array, v79);
FuzzerInjectionPoint(93);
f46(3127, 256, f46, 2455);
FuzzerInjectionPoint(94);
const v89 = f45();
FuzzerInjectionPoint(95);
%PrepareFunctionForOptimization(f45);
FuzzerInjectionPoint(96);
f45();
FuzzerInjectionPoint(97);
const v91 = f45();
FuzzerInjectionPoint(98);
%OptimizeMaglevOnNextCall(f45);
FuzzerInjectionPoint(99);
let v92 = f45();
FuzzerInjectionPoint(100);
[v79,v92,...BigInt64Array] = v89;
FuzzerInjectionPoint(101);
new Uint32Array(v91, 2455, v92);
FuzzerInjectionPoint(102);
new Date();