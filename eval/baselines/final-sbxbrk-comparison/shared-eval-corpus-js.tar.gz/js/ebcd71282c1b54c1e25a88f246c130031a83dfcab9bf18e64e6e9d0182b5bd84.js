
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    class C4 {

    }
FuzzerInjectionPoint(4);
    const v6 = new WeakMap(a1);
FuzzerInjectionPoint(5);
    v6.set(C4);
FuzzerInjectionPoint(6);
    return a3;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);
f0();
FuzzerInjectionPoint(10);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(11);
f0();