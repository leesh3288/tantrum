
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = constructor().Float16Array;

const v9 = new ArrayBuffer(1024, { maxByteLength: 268435441 });

const v10 = new v4(v9);

function f11() {

    return v10;

}

const v12 = new Float64Array(Float32Array);

function f14() {

    return constructor;

}

Object.defineProperty(f14, Symbol.species, { enumerable: true, value: f11 });

Object.defineProperty(v12, "constructor", { enumerable: true, value: f14 });

v12.slice();