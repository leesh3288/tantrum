
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [NaN,-641.5037993560936,1e-15,-8.26870512515824,0.9309964234437436,-1.1437375993998172e+308,NaN];
FuzzerInjectionPoint(2);
const v1 = [1,-2147483649,5,-10,23818,0,2147483649];
FuzzerInjectionPoint(3);
Reflect.preventExtensions(v1);
FuzzerInjectionPoint(4);
Reflect.apply(v0.indexOf, v1, v0);
FuzzerInjectionPoint(5);
for (let i8 = 0, i9 = 10; i9; i9--) {
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);