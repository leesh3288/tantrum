
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    let v7 = -BigInt(-0.0);
FuzzerInjectionPoint(3);
    v7++;
FuzzerInjectionPoint(4);
    return f0;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
const v9 = f0(f0, f0, f0);
FuzzerInjectionPoint(7);
f0(v9, v9, f0);
FuzzerInjectionPoint(8);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(9);
f0(v9, v9, f0);
FuzzerInjectionPoint(10);