
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f10() {
FuzzerInjectionPoint(2);
    class C21 extends Date("filter") {

    }
FuzzerInjectionPoint(4);
    return Uint8ClampedArray;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
function f24(a25, a26) {
FuzzerInjectionPoint(7);
    [{ 1073741825: -1.6992212676582271e+308 }];
FuzzerInjectionPoint(8);
    return f24;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f24("-5", Uint8ClampedArray);
FuzzerInjectionPoint(11);
class C31 {

    constructor(a33, a34) {
FuzzerInjectionPoint(13);
        this.e();
FuzzerInjectionPoint(14);
        %OptimizeFunctionOnNextCall(f24);
FuzzerInjectionPoint(15);
    }

    e = f24;

}
FuzzerInjectionPoint(18);
const v36 = new C31();
FuzzerInjectionPoint(19);
v36.e();