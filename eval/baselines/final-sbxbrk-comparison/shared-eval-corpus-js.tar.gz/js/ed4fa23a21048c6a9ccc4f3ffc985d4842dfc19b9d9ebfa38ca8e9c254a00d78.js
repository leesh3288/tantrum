
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = this.TypeError;
FuzzerInjectionPoint(2);
const v2 = t0();
FuzzerInjectionPoint(3);
let v4 = "minor";
FuzzerInjectionPoint(4);
v4 += v2;
FuzzerInjectionPoint(5);
const v5 = { type: v4 };
FuzzerInjectionPoint(6);
v5.type.normalize();
FuzzerInjectionPoint(7);
gc(v5);
FuzzerInjectionPoint(8);