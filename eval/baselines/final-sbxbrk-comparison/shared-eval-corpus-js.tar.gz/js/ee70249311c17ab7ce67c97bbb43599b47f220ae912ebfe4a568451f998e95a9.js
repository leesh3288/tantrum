
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = Array(122);
FuzzerInjectionPoint(2);
const v3 = [1000000000.0,185453.66805808875,887.1083108101639,-Infinity,2.2250738585072014e-308,-9.96501636426367e+307];
FuzzerInjectionPoint(3);
const v4 = { __proto__: v2, ...v3 };
FuzzerInjectionPoint(4);
v4[83] = Array;
FuzzerInjectionPoint(5);
v4.toLocaleString().toLocaleUpperCase();
FuzzerInjectionPoint(6);