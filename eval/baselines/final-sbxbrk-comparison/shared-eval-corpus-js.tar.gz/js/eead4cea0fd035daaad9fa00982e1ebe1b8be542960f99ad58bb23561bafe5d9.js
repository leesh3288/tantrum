
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1, a2, a3) {
FuzzerInjectionPoint(2);
    function f4(a5, a6, a7) {
FuzzerInjectionPoint(3);
        return f4;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    f4(f0, a3, a2);
FuzzerInjectionPoint(6);
    const v12 = {

        [a1](a10, a11) {
FuzzerInjectionPoint(8);
        },

    };
FuzzerInjectionPoint(10);
    v12.undefined(v12, f0);
FuzzerInjectionPoint(11);
    return f4;
FuzzerInjectionPoint(12);
}
FuzzerInjectionPoint(13);
f0();
FuzzerInjectionPoint(14);
f0();
FuzzerInjectionPoint(15);
%OptimizeFunctionOnNextCall(f0);
FuzzerInjectionPoint(16);
f0();