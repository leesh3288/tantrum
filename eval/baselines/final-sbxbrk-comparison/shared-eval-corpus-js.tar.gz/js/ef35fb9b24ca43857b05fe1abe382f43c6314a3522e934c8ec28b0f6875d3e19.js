
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v5 = new Uint32Array(a3);
FuzzerInjectionPoint(3);
    v5[121] = v5;
FuzzerInjectionPoint(4);
    function f6() {
FuzzerInjectionPoint(5);
        return v5;
FuzzerInjectionPoint(6);
    }
FuzzerInjectionPoint(7);
    return a2;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
f1(Uint32Array, Uint32Array, f1);
FuzzerInjectionPoint(10);
f1(Uint32Array, f1, Uint32Array);
FuzzerInjectionPoint(11);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(12);
f1();
FuzzerInjectionPoint(13);