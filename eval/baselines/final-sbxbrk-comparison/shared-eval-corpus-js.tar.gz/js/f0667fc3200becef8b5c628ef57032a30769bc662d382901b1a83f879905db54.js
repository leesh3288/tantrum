
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = [9007199254740990,-9007199254740990,256];
FuzzerInjectionPoint(2);
const v3 = {};
FuzzerInjectionPoint(3);
v3.defineProperty = v3;
FuzzerInjectionPoint(4);
const v5 = new Proxy(v2, v3);
FuzzerInjectionPoint(5);
function f6(a7, a8, a9) {
FuzzerInjectionPoint(6);
    ({}).constructor.freeze(a9);
FuzzerInjectionPoint(7);
    return v5;
FuzzerInjectionPoint(8);
}
FuzzerInjectionPoint(9);
try { f6(Uint8ClampedArray, Uint8ClampedArray, v5); } catch (e) {}
FuzzerInjectionPoint(10);
v2.includes(Uint8ClampedArray, -2147483649);
FuzzerInjectionPoint(11);