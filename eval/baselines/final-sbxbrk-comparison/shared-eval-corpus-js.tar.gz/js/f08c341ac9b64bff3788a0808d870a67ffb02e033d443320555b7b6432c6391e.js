
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [4096,13,1024,129,1199911847,10,-11,9];
FuzzerInjectionPoint(2);
const v3 = new Proxy(v0, {});
FuzzerInjectionPoint(3);
v3[2];
FuzzerInjectionPoint(4);