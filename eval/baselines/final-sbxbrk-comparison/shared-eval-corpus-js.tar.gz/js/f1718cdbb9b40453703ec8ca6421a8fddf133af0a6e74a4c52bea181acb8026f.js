
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {

    const v1 = `

        function f2(a3, a4, a5) {

            class C7 extends Array {

            }

            class C8 extends C7 {

                #n(a10, a11) {

                }

            }

            return f0;

        }

        f2();

    `;

    eval(v1);

    return v1;

}

const v17 = { type: "function" };

const v18 = new Worker(f0, v17);

v18.getMessage(f0, v17, "function");