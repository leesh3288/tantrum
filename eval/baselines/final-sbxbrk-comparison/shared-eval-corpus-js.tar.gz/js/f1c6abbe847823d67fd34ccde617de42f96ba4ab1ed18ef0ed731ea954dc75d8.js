
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const t1 = 13;
FuzzerInjectionPoint(3);
    t1.b = (4.0 / (4096 & a2)) << a2;
FuzzerInjectionPoint(4);
    return 13;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
f1();
FuzzerInjectionPoint(7);
f1();
FuzzerInjectionPoint(8);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(9);
f1();
FuzzerInjectionPoint(10);