
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0(a1) {

    return a1;

}

const v2 = `

    function f3(a4, a5, a6) {

        let v7 = "ius";

        v7 < v7;

        let v9 = [-3.0,0.3502022582451323,-4.0,992175.4466351527,0.7687161343105167,-7.372569994031326];

        function f10() {

            const v11 = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([

                0x00, 0x61, 0x73, 0x6D, 0x01, 0x00, 0x00, 0x00, 0x01, 0x01,

                0x00, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x05, 0x01, 0x00,

                0x06, 0x01, 0x00, 0x07, 0x01, 0x00, 0x09, 0x01, 0x00, 0x0A,

                0x01, 0x00,

            ])));

            v11.constructor;

            function f13(a14, a15, a16) {

                for (let i19 = 15, i20 = 0; i20--, i20 % i20;) {

                }

                return 15;

            }

            f13(f13, f13, f13);

            v9--;

            const v30 = Symbol.toPrimitive;

            function f31() {

                return f31;

            }

            [f31,f0,Symbol];

            Set();

            const v42 = {

                m(a36, a37, a38) {

                    function f39() {

                        return v30;

                    }

                    function f40(a41) {

                        return f3;

                    }

                    Object.defineProperty(v30, "g", { enumerable: true, get: f39, set: f40 });

                    return f3;

                },

            };

            [1000000000.0,1000000000000.0,-1.6262575246699304e+308,-0.0,0.9853739248924984,-1000.0,1000000000000.0,-5927.62077511067,1.4423988569664292];

            function f44() {

                const v45 = [536870912,4];

                v45.flat();

                const v48 = 0 !== 0;

                const v49 = !v48;

                const v50 = v49 || v49;

                v48 && v48;

                v45 ?? v45;

                return v50;

            }

            return f10;

        }

        class C53 {

            static {

            }

        }

        v7 = v9;

        /h\ud808\udf45*/mdy;

        const t62 = Float32Array.subarray;

        t62();

        532 ?? 532;

        class C61 {

        }

        function F62(a64) {

            if (!new.target) { throw 'must be called with new'; }

        }

        Float32Array();

        return f3;

    }

    new Worker(f3, { type: "function" });

`;

eval(v2).getMessage();