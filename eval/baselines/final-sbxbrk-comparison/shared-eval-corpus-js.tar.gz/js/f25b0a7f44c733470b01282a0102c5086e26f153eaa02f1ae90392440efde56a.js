
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
JSON.stringify([Infinity,1000.0,-997.36945870996,31912.744156542816,388814.7845805213,3.661727352743814e+307,-5.0,0.5921061467989669]);
FuzzerInjectionPoint(2);