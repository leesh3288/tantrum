
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = Array(30321);
FuzzerInjectionPoint(2);
class C5 {

}
FuzzerInjectionPoint(4);
function f6() {
FuzzerInjectionPoint(5);
    return 30321;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
C5[Symbol.toPrimitive] = f6;
FuzzerInjectionPoint(8);
Reflect.preventExtensions(v3);
FuzzerInjectionPoint(9);
const v10 = [2334,C5];
FuzzerInjectionPoint(10);
Reflect.apply(v10.indexOf, v3, v10);