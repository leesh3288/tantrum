
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v6 = new SharedArrayBuffer(21, { maxByteLength: 21 });
FuzzerInjectionPoint(2);
const v8 = new Float32Array(v6);
FuzzerInjectionPoint(3);
function f9(a10) {
FuzzerInjectionPoint(4);
    return 4294967295;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
v8[Symbol.toPrimitive] = f9;
FuzzerInjectionPoint(7);
v8[2] = v8;
FuzzerInjectionPoint(8);
v8.constructor = Uint8Array;
FuzzerInjectionPoint(9);
v8.slice();
FuzzerInjectionPoint(10);