
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2) {
FuzzerInjectionPoint(2);
    Int8Array(a2, a2, a2);
FuzzerInjectionPoint(3);
    return Uint16Array;
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
Uint16Array[Symbol.toPrimitive] = f1;
FuzzerInjectionPoint(6);
const v8 = constructor();
FuzzerInjectionPoint(7);
try { v8.encodeURI(Uint16Array); } catch (e) {}
FuzzerInjectionPoint(8);