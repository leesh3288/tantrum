
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = new Int16Array(127);
FuzzerInjectionPoint(2);
const v7 = new ArrayBuffer(127, { maxByteLength: 2147483649 });
FuzzerInjectionPoint(3);
const v8 = new Int8Array(v7);
FuzzerInjectionPoint(4);
function f9() {
FuzzerInjectionPoint(5);
    return v8;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
Object.defineProperty(f9, Symbol.species, { enumerable: true, value: f9 });
FuzzerInjectionPoint(8);
v3.constructor = f9;
FuzzerInjectionPoint(9);
v3.slice();
FuzzerInjectionPoint(10);