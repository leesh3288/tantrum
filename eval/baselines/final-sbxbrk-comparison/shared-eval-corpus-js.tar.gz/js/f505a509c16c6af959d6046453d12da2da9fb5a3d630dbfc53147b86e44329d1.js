
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v4 = new SharedArrayBuffer(256, { maxByteLength: 256 });
FuzzerInjectionPoint(2);
const v6 = new BigUint64Array(v4);
FuzzerInjectionPoint(3);
const v8 = new BigInt64Array(v6);
FuzzerInjectionPoint(4);
const t3 = v8.constructor;
FuzzerInjectionPoint(5);
new t3(v6);
FuzzerInjectionPoint(6);