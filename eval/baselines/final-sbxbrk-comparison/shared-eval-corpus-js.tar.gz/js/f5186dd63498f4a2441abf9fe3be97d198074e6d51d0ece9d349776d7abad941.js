
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
for (const v5 in Object.seal(Array(122))) {
FuzzerInjectionPoint(2);
}
FuzzerInjectionPoint(3);