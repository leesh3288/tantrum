
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Float32Array([764.6705457763169,-3.0,-836638.6906058344,-1000000.0,-Infinity,-1.0,-469.325540616407,-2.220446049250313e-16,-2.2250738585072014e-308,1000000000000.0]);
FuzzerInjectionPoint(2);
new Uint32Array(v2);
FuzzerInjectionPoint(3);