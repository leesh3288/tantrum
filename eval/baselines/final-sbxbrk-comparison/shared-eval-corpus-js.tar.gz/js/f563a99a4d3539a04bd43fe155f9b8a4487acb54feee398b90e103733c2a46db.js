
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [1000.0,-1000.0];
FuzzerInjectionPoint(2);
Object.defineProperty(v0, "g", { writable: true, configurable: true, enumerable: true, value: v0 });
FuzzerInjectionPoint(3);