
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f2() {
FuzzerInjectionPoint(2);
    return Date;
FuzzerInjectionPoint(3);
}
FuzzerInjectionPoint(4);
function f3(a4) {
FuzzerInjectionPoint(5);
    return f3;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
Object.defineProperty(JSON, "toJSON", { configurable: true, get: f2, set: f3 });
FuzzerInjectionPoint(8);
JSON.parse(JSON.stringify(JSON));
FuzzerInjectionPoint(9);