
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C2 extends Float64Array {

}
FuzzerInjectionPoint(3);
const v3 = new C2();
FuzzerInjectionPoint(4);
function f4() {
FuzzerInjectionPoint(5);
    v3.length &&= 1;
FuzzerInjectionPoint(6);
    return C2;
FuzzerInjectionPoint(7);
}
FuzzerInjectionPoint(8);
f4();
FuzzerInjectionPoint(9);
f4();
FuzzerInjectionPoint(10);
%OptimizeMaglevOnNextCall(f4);
FuzzerInjectionPoint(11);
f4();