
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v7 = Math.sign(a4 ^ Int32Array);
FuzzerInjectionPoint(3);
    const v8 = v7 - v7;
FuzzerInjectionPoint(4);
    for (let v9 = 0; v9 < 5; v9++) {
FuzzerInjectionPoint(5);
    }
FuzzerInjectionPoint(6);
    const v10 = v8 >>> v8;
FuzzerInjectionPoint(7);
    v10 * v10;
FuzzerInjectionPoint(8);
    return f1;
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
const v12 = f1(f1, f1, Int32Array);
FuzzerInjectionPoint(11);
f1(Int32Array, v12, v12);
FuzzerInjectionPoint(12);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(13);
f1();
FuzzerInjectionPoint(14);