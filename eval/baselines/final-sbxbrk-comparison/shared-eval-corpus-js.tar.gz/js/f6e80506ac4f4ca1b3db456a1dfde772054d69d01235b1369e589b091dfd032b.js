
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    const v6 = 4.0 << a2;
FuzzerInjectionPoint(3);
    const v7 = v6 >> v6;
FuzzerInjectionPoint(4);
    const v8 = { [-65537]: v7 };
FuzzerInjectionPoint(5);
    return -65537;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
const v9 = f1();
FuzzerInjectionPoint(8);
f1(v9, v9, v9);
FuzzerInjectionPoint(9);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(10);
f1();
FuzzerInjectionPoint(11);