
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = -Infinity;
FuzzerInjectionPoint(2);
Math.atan2(v2 ** 8, v2);
FuzzerInjectionPoint(3);