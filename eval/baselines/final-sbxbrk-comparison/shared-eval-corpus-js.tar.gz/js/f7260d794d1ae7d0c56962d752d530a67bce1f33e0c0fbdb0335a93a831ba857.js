
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v3 = new Date(-1024);
FuzzerInjectionPoint(2);
v3.setDate(128);
FuzzerInjectionPoint(3);
v3.setFullYear(-1024);
FuzzerInjectionPoint(4);
v3.setSeconds();
FuzzerInjectionPoint(5);