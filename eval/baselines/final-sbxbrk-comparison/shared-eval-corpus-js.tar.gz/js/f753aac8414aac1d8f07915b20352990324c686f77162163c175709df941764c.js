
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1(a2, a3, a4) {
FuzzerInjectionPoint(2);
    function f5(a6) {
FuzzerInjectionPoint(3);
        return f5;
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    for (let i = 0; i < 100; i++) {
FuzzerInjectionPoint(6);
        f5();
FuzzerInjectionPoint(7);
        %OptimizeMaglevOnNextCall(f5);
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
}
FuzzerInjectionPoint(10);
f1();
FuzzerInjectionPoint(11);
f1();
FuzzerInjectionPoint(12);