
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [-58776,256,-9223372036854775807,-17481415,-52170,1,0,-65536];

const v2 = new Uint16Array();

const v3 = [-3.809585762245657,4.0,3.0,-826429.2771385903,-5.330604268919695,0.19582151462234287,2.0,-2.0,-2.2250738585072014e-308,-0.0];

function* f4(a5, a6, a7) {

    const v8 = {};

    function f9(a10, a11) {

        return a10;

    }

    yield* v2;

    v8[Symbol.dispose] = f9;

    let [v14,v15,v16] = v0;

    using v17 = v8;

    function F18() {

        if (!new.target) { throw 'must be called with new'; }

    }

    function f20(a21) {

        return f9;

    }

    f20(F18);

    return v16;

}

const v24 = v3.splice(...f4(v3, v3, v0));

%OptimizeMaglevOnNextCall(f4);

f4(v24, v24, v2);