
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
let v0 = 2;
FuzzerInjectionPoint(2);
const v1 = v0--;
FuzzerInjectionPoint(3);
function f2(a3) {
FuzzerInjectionPoint(4);
    for (let i5 = 0, i6 = v1;

        i6;

        (() => {
FuzzerInjectionPoint(7);
            const v9 = v0 % i6;
FuzzerInjectionPoint(8);
            --i6 | v9;
FuzzerInjectionPoint(9);
            const v13 = new Int32Array(v1, v0, v0);
FuzzerInjectionPoint(10);
            v13[1073741823] = v13;
FuzzerInjectionPoint(11);
        })()) {
FuzzerInjectionPoint(12);
    }
FuzzerInjectionPoint(13);
    return a3;
FuzzerInjectionPoint(14);
}
FuzzerInjectionPoint(15);
f2();
FuzzerInjectionPoint(16);
f2(v0);
FuzzerInjectionPoint(17);
%OptimizeFunctionOnNextCall(f2);
FuzzerInjectionPoint(18);
f2();