
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v2 = /\P{gc=Decimal_Number}abc|def|ghixabc?/mvsy.compile();
FuzzerInjectionPoint(3);
    v2.f = v2;
FuzzerInjectionPoint(4);
    return v2;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
f0();
FuzzerInjectionPoint(7);
f0();
FuzzerInjectionPoint(8);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(9);
f0();
FuzzerInjectionPoint(10);