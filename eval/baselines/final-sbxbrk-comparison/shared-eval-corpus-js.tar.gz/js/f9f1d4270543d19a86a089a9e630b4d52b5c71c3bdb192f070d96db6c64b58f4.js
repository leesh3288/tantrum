
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f0() {
FuzzerInjectionPoint(2);
    const v3 = new Float64Array(504);
FuzzerInjectionPoint(3);
    return v3[188];
FuzzerInjectionPoint(4);
}
FuzzerInjectionPoint(5);
f0();
FuzzerInjectionPoint(6);
%PrepareFunctionForOptimization(f0);
FuzzerInjectionPoint(7);
%OptimizeMaglevOnNextCall(f0);
FuzzerInjectionPoint(8);
f0();
FuzzerInjectionPoint(9);