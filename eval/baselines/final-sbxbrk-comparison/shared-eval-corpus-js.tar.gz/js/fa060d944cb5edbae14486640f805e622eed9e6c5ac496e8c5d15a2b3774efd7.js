
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {

    for (let v2 = 0; v2 < 5; v2++) {

        v2 >>> v2;

        -(v2 & v2);

    }

}

f1();

class C9 {

    #h = -9007199254740990;

    static set f(a11) {

        Math.imul(32465);

        let v15 = this + 32465;

        !C9;

        Math.log1p();

        Math.floor();

        Math.acosh();

        v15++;

    }

}

const v21 = new C9();

function F22(a24, a25, a26, a27) {

    if (!new.target) { throw 'must be called with new'; }

    this.c = a26;

}

const v28 = new F22(C9, C9, v21, v21);

new F22(C9, v28);

new F22(v28, v28, v21);

new BigUint64Array(579);

new Int8Array(2063);

new Uint32Array();

new Int8Array();

const v45 = /qh8h/vs;

function f50() {

    function f52(a53) {

        class C55 {

        }

        new C55(NaN);

        class C61 {

        }

        C61.b = C61;

        const v62 = { [-8.667501055480269]: "1073741823", 2147483649: -8.667501055480269, b: -8.667501055480269 };

        Int8Array();

        class C70 {

            constructor(a72, a73, a74) {

                this[a74] <<= 0.4290329618895984;

            }

        }

        class C78 {

            static get h() {

                super.c |= C70;

            }

        }

        function f80() {

        }

        function f81(a82, a83, a84, a85) {

        }

        f81();

        f80();

        f80();

        [f81,f80,...BigInt64Array] = f80;

        const v89 = Uint32Array();

        v89[69] = v89;

        const v91 = {};

        function f94() {

            const v97 = {

                3735770665: -663532.7850352083,

                [1]: 8,

                get a() {

                    return -663532.7850352083;

                },

            };

            return v97;

        }

        const v102 = {

            n(a99, a100, a101) {

                f94.__proto__ = f50;

                return 1;

            },

        };

        Date.length = Date;

        [536870888,697999288,4,-16,1000,6,127];

        v28.reduceRight();

        class C106 {

        }

        C106.prototype = C106;

        for (let v107 = 0; v107 < 5; v107++) {

            C106[v107] = v107;

        }

        2147483648n === 2147483648n;

        function f111(a112, a113, a114) {

        }

        f111.arguments = f111;

        const v115 = /()7/dvsgi;

        v115.h = v115;

        function f118(a119, a120) {

            return {};

        }

        4294967295n - 4294967295n;

        ([536870912,1979792005,-1024]).concat();

        const v125 = [43680,-536870912,4294967297,9332,9223372036854775807,-9223372036854775808,-9,43727,1175231882];

        const v126 = [-58284,14,-1073741824,7947,-1,255];

        class C127 {

            static 9 = v126;

        }

        for (let i = 0; i < 5; i++) {

            let v130 = 9 != 9;

            0 < 9;

            try { v126.flat(C127, v125, 4294967295n); } catch (e) {}

            v130++;

            function F135(a137, a138, a139) {

                if (!new.target) { throw 'must be called with new'; }

            }

            new F135();

            F135++;

        }

        v115[9] += 8;

        [-12,127,-9007199254740992,1000,19700,-256,0,17757];

        new WeakMap();

        class C144 {

        }

        class C145 extends C9 {

        }

        ("1073741823")["lastIndexOf"]("lastIndexOf", 11);

        function f149() {

            return f149;

        }

        f149();

        Math.cos();

        class C153 {

        }

    }

    this.onmessage = f52;

}

const v156 = { type: "function" };

Object.defineProperty(v156, "flushDenormals", { writable: true, configurable: true, value: v45 });

new Worker(f50, v156);