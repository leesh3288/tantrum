
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = new Uint16Array();
FuzzerInjectionPoint(2);
try { v2.toSorted(); } catch (e) {}
FuzzerInjectionPoint(3);
new Float64Array();
FuzzerInjectionPoint(4);
[];
FuzzerInjectionPoint(5);
[2,16,-8,0,3,-10,165397064];
FuzzerInjectionPoint(6);
[-6,1740790832,-268435456,-4096,1000,65537,9007199254740991,1024,64];
FuzzerInjectionPoint(7);
[13];
FuzzerInjectionPoint(8);
class C10 {

    p(a12, a13) {
FuzzerInjectionPoint(10);
    }

}
FuzzerInjectionPoint(12);
new Int8Array(10);
FuzzerInjectionPoint(13);
const v17 = [255,8,-4,1,1318086974];
FuzzerInjectionPoint(14);
for (let v18 = 0; v18 < 100; v18++) {
FuzzerInjectionPoint(15);
    const v31 = {

        valueOf() {
FuzzerInjectionPoint(17);
            this.valueOf;
FuzzerInjectionPoint(18);
            const v22 = {};
FuzzerInjectionPoint(19);
            const t1 = "dNd";
FuzzerInjectionPoint(20);
            t1[2699094064] -= v17;
FuzzerInjectionPoint(21);
            function F23() {
FuzzerInjectionPoint(22);
                if (!new.target) { throw 'must be called with new'; }
FuzzerInjectionPoint(23);
            }
FuzzerInjectionPoint(24);
            const v25 = [4294967297,1,9007199254740992,10,268435456,526699605];
FuzzerInjectionPoint(25);
            const v26 = [840523928,1,127,1465286919,35559,372682955,-2061987146,4294967295,256,129];
FuzzerInjectionPoint(26);
            let v28 = undefined;
FuzzerInjectionPoint(27);
            v26[2];
FuzzerInjectionPoint(28);
            try { v26.some(v26); } catch (e) {}
FuzzerInjectionPoint(29);
            v26.g = v26;
FuzzerInjectionPoint(30);
            v28 = v25;
FuzzerInjectionPoint(31);
        },

    };
FuzzerInjectionPoint(33);
    v31.valueOf();
FuzzerInjectionPoint(34);
}