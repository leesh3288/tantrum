
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v0 = [1.0];
FuzzerInjectionPoint(2);
function f1(a2) {
FuzzerInjectionPoint(3);
    const v3 = [-15,-9007199254740990,-22017,4,-7206,-9];
FuzzerInjectionPoint(4);
    function f4(a5, a6, a7) {
FuzzerInjectionPoint(5);
        a6.g = a6;
FuzzerInjectionPoint(6);
        v3.push(-916.5476529919076);
FuzzerInjectionPoint(7);
        return f4;
FuzzerInjectionPoint(8);
    }
FuzzerInjectionPoint(9);
    const t8 = f4(f1, f1);
FuzzerInjectionPoint(10);
    return t8(v0, v3);
FuzzerInjectionPoint(11);
}
FuzzerInjectionPoint(12);
const v12 = f1();
FuzzerInjectionPoint(13);
f1(v12);
FuzzerInjectionPoint(14);
%OptimizeFunctionOnNextCall(f1);
FuzzerInjectionPoint(15);
f1(v12);
FuzzerInjectionPoint(16);