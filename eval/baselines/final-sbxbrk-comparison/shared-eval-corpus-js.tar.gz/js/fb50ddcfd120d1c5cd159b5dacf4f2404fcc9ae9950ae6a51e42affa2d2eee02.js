
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const t0 = constructor(Int32Array, constructor).Float16Array;

const v5 = new t0(Int32Array);

v5.includes(13);