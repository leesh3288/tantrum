
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v1 = new Int32Array();
FuzzerInjectionPoint(2);
const v2 = /Fxa\nb\bcLGd(?!\1(a\1)\1)\1/sgiy;
FuzzerInjectionPoint(3);
function f3(a4, a5) {
FuzzerInjectionPoint(4);
    return a4;
FuzzerInjectionPoint(5);
}
FuzzerInjectionPoint(6);
v2[Symbol.toPrimitive] = f3;
FuzzerInjectionPoint(7);
const v10 = constructor().Intl;
FuzzerInjectionPoint(8);
v10.firstDayOfWeek = v1;
FuzzerInjectionPoint(9);
const v11 = v10.Locale;
FuzzerInjectionPoint(10);
try { new v11(v2, v10); } catch (e) {}
FuzzerInjectionPoint(11);