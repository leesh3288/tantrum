
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
function f1() {
FuzzerInjectionPoint(2);
    function f2(a3) {
FuzzerInjectionPoint(3);
        ("getPrototypeOf").split(([2.0,0.10902179727929118,-9.453220237815431e+307,1.158932377720401e+307,4.0,839426.2335999038,-2.220446049250313e-16,0.17422560225957207,Infinity]).toLocaleString());
FuzzerInjectionPoint(4);
    }
FuzzerInjectionPoint(5);
    return f2;
FuzzerInjectionPoint(6);
}
FuzzerInjectionPoint(7);
Object.defineProperty(Int32Array, Symbol.toPrimitive, { get: f1 });
FuzzerInjectionPoint(8);
new Date(34.91011343412788, 34.91011343412788, 2.0, Int32Array);
FuzzerInjectionPoint(9);