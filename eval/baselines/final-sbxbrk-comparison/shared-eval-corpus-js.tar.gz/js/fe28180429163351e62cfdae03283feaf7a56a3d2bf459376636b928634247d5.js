
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
class C3 extends Array {

    2 = C3;

}
FuzzerInjectionPoint(4);
const v4 = new C3();
FuzzerInjectionPoint(5);
v4.push(431);
FuzzerInjectionPoint(6);
v4.includes(-0.0);