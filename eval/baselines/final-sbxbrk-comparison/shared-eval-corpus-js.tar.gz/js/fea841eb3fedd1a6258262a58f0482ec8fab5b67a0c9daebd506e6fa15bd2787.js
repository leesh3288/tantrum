
// ############ INJECTION START MARKER ############
// Notify the fuzzer that we had control and we can start to mutated loads.
FuzzerInjectionPoint(1);
const v2 = this.WebAssembly;
FuzzerInjectionPoint(2);
try { v2.promising(65535); } catch (e) {}
FuzzerInjectionPoint(3);